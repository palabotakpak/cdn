// Vercel Serverless Function - gabungan profil user + riwayat download
// Digabung dari api/profile.js + api/history.js supaya jumlah total
// Serverless Function tetap di bawah limit 12 (Vercel Hobby plan).
//
// Routing:
//   GET  /api/profile                                         -> (langsung) profil user
//   POST /api/profile {username}                               -> set/ganti username (maks 1x / 7 hari)
//   POST /api/profile {avatarEmoji, avatarColor}                -> ganti avatar (emoji+warna dari daftar yang diizinkan)
//   POST /api/profile {username, avatarEmoji, avatarColor}      -> ganti keduanya sekaligus
//   POST /api/history {action:'list'|'delete'|'clear'}          -> (rewrite) target=history
//   POST /api/profile?target=history {...}                      -> akses langsung juga bisa
//
// Wajib header Authorization: Bearer <idToken>. Semua data dibaca/ditulis lewat
// Firebase Admin SDK; client tidak punya akses langsung ke Firestore.

import {
  getRoleFromRequest, prepareDb, getAdminServices, getAdminInitError,
  getUsage, LIMITS, explainError, effectiveRoleData,
  listDownloads, deleteDownload, clearDownloads
} from './_firebaseAdmin.js';
import { consumeCaptcha } from './_captcha.js';
import { generateApiKey, revokeApiKey, apiKeyInfo, requestApiAccess, apiAccessOk } from './_apikey.js';
import { FieldValue } from 'firebase-admin/firestore';

const USERNAME_RE = /^[a-z0-9_]{3,20}$/;
const USERNAME_COOLDOWN_MS = 7 * 24 * 60 * 60 * 1000; // username cuma bisa diganti sekali tiap 7 hari
// Daftar emoji & warna avatar yang diizinkan (dicek di server biar gak bisa diisi sembarangan dari client).
// Kalau nambah/ubah daftar ini, samakan juga dengan AVATAR_EMOJIS/AVATAR_COLORS di public/index.html.
const ALLOWED_AVATAR_EMOJI = ['😀','😎','🐱','🐶','🦊','🐼','🐧','🐸','🐵','🦁','🐯','🐨','🦄','🐙','🍕','⚡','🔥','🌈','💎','👾','🤖','👻','🎮','⭐'];
const ALLOWED_AVATAR_COLOR = ['#ff5c9a','#3fa9ff','#8c5cff','#3ddc97','#ff3b3b','#ffb23f'];
// Foto profil dikirim client sebagai data URL base64 (sudah dikompres ke 320x320 JPEG di browser).
// Batas di server dilonggarkan sedikit dari batas client (3MB file asli -> base64 lebih besar ~33%).
const AVATAR_PHOTO_RE = /^data:image\/(png|jpe?g|webp);base64,[A-Za-z0-9+/]+=*$/;
const AVATAR_PHOTO_MAX_LEN = 600 * 1024; // ~600KB string base64, cukup untuk JPEG 320x320 kualitas 0.85
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '';
const BOT_UA_RE = /(curl|wget|python-requests|python-urllib|scrapy|axios\/|node-fetch|go-http-client|libwww-perl|httpclient|aiohttp|okhttp|postman|insomnia|headlesschrome|phantomjs|puppeteer|playwright|bot|crawler|spider|scraper)/i;
const ID_RE = /^(music|tiktok|instagram)_[a-f0-9]{20}$/;

function profileResponse(uid, email, data, usage) {
  const eff = effectiveRoleData(data); // self-heal expiry sudah terjadi di getRoleFromRequest sebelum snap ini dibaca
  const limit = eff.role === 'owner' ? null : LIMITS[eff.role];
  return {
    uid,
    email: email || data.email || '',
    role: eff.role,
    roleExpiresAt: eff.roleExpiresAt,
    username: data.username || null,
    avatarEmoji: data.avatarEmoji || null,
    avatarColor: data.avatarColor || null,
    avatarPhoto: data.avatarPhoto || null,
    usage: { count: limit === null ? 0 : usage.count, limit }
  };
}

async function handleProfile(req, res) {
  await prepareDb();
  const admin = getAdminServices();
  if (!admin) {
    return res.status(500).json({ error: 'Firebase Admin belum dikonfigurasi: ' + (getAdminInitError() || 'env var kosong') });
  }

  const { uid, email, error: authError, dbError, otpPending } = await getRoleFromRequest(req, { allowPending: true });
  if (!uid) {
    return res.status(401).json({ error: authError ? 'Verifikasi login gagal di server: ' + authError : 'Login dulu.' });
  }

  if (dbError) return res.status(500).json({ error: dbError });

  // Akun Google baru wajib verifikasi OTP dulu (lihat api/otp.js action=gsend/gverify).
  if (otpPending) {
    if (req.method === 'GET') return res.status(200).json({ otpPending: true, uid, email: email || '' });
    return res.status(403).json({ error: 'Verifikasi email (OTP) dulu sebelum lanjut.', otpPending: true });
  }

  const userRef = admin.db.collection('users').doc(uid);

  if (req.method === 'GET') {
    try {
      let snap = await userRef.get();
      if (!snap.exists) {
        await userRef.set({ role: 'free', email: email || '' });
        snap = await userRef.get();
      }
      const usage = await getUsage(uid);
      const out = profileResponse(uid, email, snap.data(), usage);
      out.api = await apiKeyInfo(uid, snap.data(), out.role);
      return res.status(200).json(out);
    } catch (e) {
      return res.status(500).json({ error: 'Gagal membaca profil: ' + explainError(e) });
    }
  }

  if (req.method === 'POST') {
    const body = typeof req.body === 'string' ? safeParse(req.body) : (req.body || {});
    // Kelola API key (khusus PREMIUM/OWNER): {apiKey:'generate'} -> key baru (tampil sekali), {apiKey:'revoke'} -> cabut.
    if (body.apiKey === 'generate' || body.apiKey === 'revoke' || body.apiKey === 'request') {
      // Anti-robot: tolak UA otomatis, honeypot terisi, dan (untuk buat key / ajukan akses) captcha gambar sekali pakai.
      const ua0 = req.headers['user-agent'] || '';
      if (!ua0 || BOT_UA_RE.test(ua0) || (body.hp !== undefined && String(body.hp) !== '')) {
        return res.status(403).json({ error: 'Akses ditolak.' });
      }
      if (body.apiKey !== 'revoke') {
        const capErr = await consumeCaptcha(admin, body);
        if (capErr) return res.status(400).json({ error: capErr, captcha: true });
      }
      try {
        const snap0 = await userRef.get();
        const data0 = snap0.exists ? snap0.data() : {};
        const role0 = effectiveRoleData(data0).role;
        if (body.apiKey === 'generate' && data0.apiKeyCreatedAt && Date.now() - data0.apiKeyCreatedAt < 60000) {
          const wait = Math.ceil((60000 - (Date.now() - data0.apiKeyCreatedAt)) / 1000);
          return res.status(429).json({ error: 'Tunggu ' + wait + ' detik sebelum membuat key lagi.' });
        }
        if (body.apiKey === 'request') {
          const rq = await requestApiAccess(uid, role0, data0);
          if (rq.err) return res.status(400).json({ error: rq.err });
        } else if (!apiAccessOk(role0, data0)) {
          return res.status(403).json({ error: 'Akses API belum disetujui admin. Ajukan dulu di halaman /apidocs.' });
        }
        if (body.apiKey === 'generate' && snap0.exists && snap0.data().apiBanned) {
          return res.status(403).json({ error: 'API key kamu diblokir admin, tidak bisa membuat key baru.' });
        }
        let newKey = null;
        if (body.apiKey === 'generate') newKey = await generateApiKey(uid);
        else if (body.apiKey === 'revoke') await revokeApiKey(uid);
        const snap1 = await userRef.get();
        const out = profileResponse(uid, email, snap1.data(), await getUsage(uid));
        out.api = await apiKeyInfo(uid, snap1.data(), out.role);
        if (newKey) out.newApiKey = newKey;
        return res.status(200).json(out);
      } catch (e) {
        return res.status(500).json({ error: 'Gagal mengelola API key: ' + explainError(e) });
      }
    }

    const wantsUsername = typeof body.username === 'string';
    const wantsAvatar = typeof body.avatarEmoji === 'string' || typeof body.avatarColor === 'string';
    // avatarPhoto string -> set foto baru; avatarPhoto null (eksplisit, bukan undefined) -> hapus foto, balik ke emoji.
    const wantsPhotoSet = typeof body.avatarPhoto === 'string';
    const wantsPhotoClear = Object.prototype.hasOwnProperty.call(body, 'avatarPhoto') && body.avatarPhoto === null;

    if (!wantsUsername && !wantsAvatar && !wantsPhotoSet && !wantsPhotoClear) {
      return res.status(400).json({ error: 'Tidak ada perubahan yang dikirim.' });
    }

    let username = null;
    if (wantsUsername) {
      username = String(body.username || '').trim().toLowerCase();
      if (!USERNAME_RE.test(username)) {
        return res.status(400).json({ error: 'Username 3-20 karakter, hanya huruf kecil, angka, dan underscore (_).' });
      }
    }

    let avatarEmoji = null, avatarColor = null;
    if (wantsAvatar) {
      avatarEmoji = String(body.avatarEmoji || '');
      avatarColor = String(body.avatarColor || '');
      if (!ALLOWED_AVATAR_EMOJI.includes(avatarEmoji)) {
        return res.status(400).json({ error: 'Pilihan emoji avatar tidak valid.' });
      }
      if (!ALLOWED_AVATAR_COLOR.includes(avatarColor)) {
        return res.status(400).json({ error: 'Pilihan warna avatar tidak valid.' });
      }
    }

    let avatarPhoto = null;
    if (wantsPhotoSet) {
      avatarPhoto = String(body.avatarPhoto || '');
      if (avatarPhoto.length > AVATAR_PHOTO_MAX_LEN) {
        return res.status(400).json({ error: 'Ukuran foto terlalu besar, maksimal sekitar 3MB.' });
      }
      if (!AVATAR_PHOTO_RE.test(avatarPhoto)) {
        return res.status(400).json({ error: 'Format foto tidak valid. Hanya JPG, PNG, atau WEBP.' });
      }
    }

    try {
      await admin.db.runTransaction(async (t) => {
        const uSnap = await t.get(userRef);
        const existing = uSnap.exists ? uSnap.data() : null;
        const updates = {};

        if (wantsAvatar) {
          updates.avatarEmoji = avatarEmoji;
          updates.avatarColor = avatarColor;
        }

        if (wantsPhotoSet) {
          updates.avatarPhoto = avatarPhoto;
        } else if (wantsPhotoClear) {
          updates.avatarPhoto = FieldValue.delete();
        }

        if (wantsUsername) {
          const currentUsername = existing && existing.username;
          if (currentUsername !== username) {
            const lastChange = (existing && existing.usernameChangedAt) || 0;
            if (currentUsername && (Date.now() - lastChange) < USERNAME_COOLDOWN_MS) {
              const err = new Error('cooldown'); err.code = 'cooldown'; throw err;
            }
            const nameRef = admin.db.collection('usernames').doc(username);
            const nSnap = await t.get(nameRef); // semua read sebelum write, wajib buat transaction Firestore
            if (nSnap.exists) {
              const err = new Error('taken'); err.code = 'taken'; throw err;
            }
            if (currentUsername) {
              t.delete(admin.db.collection('usernames').doc(currentUsername));
            }
            t.set(nameRef, { uid });
            updates.username = username;
            updates.usernameChangedAt = Date.now();
          }
        }

        if (existing) t.set(userRef, updates, { merge: true });
        else t.set(userRef, Object.assign({ role: 'free', email: email || '' }, updates), { merge: true });
      });

      const snap = await userRef.get();
      const usage = await getUsage(uid);
      return res.status(200).json(profileResponse(uid, email, snap.data(), usage));
    } catch (e) {
      if (e.code === 'taken') return res.status(409).json({ error: 'Username sudah dipakai, pilih yang lain.' });
      if (e.code === 'cooldown') return res.status(429).json({ error: 'Username cuma bisa diganti maksimal sekali tiap 7 hari.' });
      return res.status(500).json({ error: 'Gagal menyimpan profil: ' + explainError(e) });
    }
  }

  return res.status(405).json({ error: 'Method not allowed' });
}

async function handleHistory(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const ua = req.headers['user-agent'] || '';
  if (!ua || BOT_UA_RE.test(ua)) {
    return res.status(403).json({ error: 'Akses ditolak' });
  }
  if (ALLOWED_ORIGIN) {
    const origin = req.headers['origin'] || req.headers['referer'] || '';
    if (!origin.startsWith(ALLOWED_ORIGIN)) {
      return res.status(403).json({ error: 'Akses ditolak' });
    }
  }

  const { uid, provider, error: authError, dbError } = await getRoleFromRequest(req);
  if (!uid) {
    return res.status(401).json({ error: authError ? 'Verifikasi login gagal: ' + authError : 'Login dulu.' });
  }
  if (dbError) return res.status(500).json({ error: dbError });
  if (provider !== 'google.com' && provider !== 'password') {
    return res.status(401).json({ error: 'Metode login tidak didukung.' });
  }
  if (!getAdminServices()) {
    return res.status(500).json({ error: 'Firebase Admin belum dikonfigurasi.' });
  }

  const body = typeof req.body === 'string' ? safeParse(req.body) : (req.body || {});
  const action = String(body.action || '');

  try {
    if (action === 'list') {
      return res.status(200).json({ success: true, items: await listDownloads(uid) });
    }
    if (action === 'delete') {
      const id = String(body.id || '');
      if (!ID_RE.test(id)) return res.status(400).json({ error: 'ID riwayat tidak valid.' });
      await deleteDownload(uid, id);
      return res.status(200).json({ success: true });
    }
    if (action === 'clear') {
      await clearDownloads(uid);
      return res.status(200).json({ success: true });
    }
    return res.status(400).json({ error: 'action harus "list", "delete", atau "clear".' });
  } catch (e) {
    return res.status(500).json({ error: 'Gagal memproses riwayat: ' + explainError(e) });
  }
}

export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');

  const target = (req.query && req.query.target) || 'profile';

  if (target === 'history') {
    return handleHistory(req, res);
  }
  return handleProfile(req, res);
}

function safeParse(s) {
  try { return JSON.parse(s); } catch { return {}; }
}
