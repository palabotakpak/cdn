// Vercel Serverless Function - AM Premium (Alight Motion Premium via SATRIAM API)
//
// POST /api/amprem
//   body: { action: 'magic', email }
//   body: { action: 'apply', email, link }
//   body: { action: 'history' }                 -> riwayat magic/apply milik akun sendiri (maks 20 terbaru)
//
// Wajib header Authorization: Bearer <idToken> (sama seperti api/rch.js).
// Limit harian: FREE 2x/hari (disimpan di Firestore, collection 'amprem_usage',
// per akun), PREMIUM & OWNER unlimited. Role selalu diverifikasi ulang ke
// Firestore lewat Firebase Admin SDK, tidak pernah dipercaya dari client.
// Riwayat disimpan di users/{uid}/amprem_history/{autoId}, hanya bisa dibaca
// oleh pemilik akun itu sendiri (lewat endpoint ini, bukan langsung ke client).
//
// SATRIAM_BASE adalah endpoint publik, tidak butuh API key / env var tambahan.

import { getRoleFromRequest, reserveUsage, refundUsage, explainError, prepareDb, getAdminServices, getAdminInitError, logFeature } from './_firebaseAdmin.js';
import { maintenanceBlock } from './_firebaseAdmin.js';

const HISTORY_LIMIT = 20;

const SATRIAM_BASE = 'https://satriam.satriadeveloperz.workers.dev/api/satriam';
const FREE_LIMIT = 2;
const USAGE_COLLECTION = 'amprem_usage';
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '';
const BOT_UA_RE = /(curl|wget|python-requests|python-urllib|scrapy|axios\/|node-fetch|go-http-client|libwww-perl|httpclient|aiohttp|okhttp|postman|insomnia|headlesschrome|phantomjs|puppeteer|playwright|bot|crawler|spider|scraper)/i;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export const AMPREM_EMAIL_RE = EMAIL_RE;

export function extractLink(rawLink) {
  let finalLink = String(rawLink || '').trim();

  const matchParam = finalLink.match(/link=([^&]+)/);
  if (matchParam) finalLink = decodeURIComponent(matchParam[1]);

  const urlMatch = finalLink.match(/(https?:\/\/[^\s]+)/);
  if (urlMatch && !matchParam) finalLink = urlMatch[0];

  if (finalLink.includes('?link=')) {
    const parts = finalLink.split('?link=');
    finalLink = decodeURIComponent(parts[1]);
    const ampIndex = finalLink.indexOf('&');
    if (ampIndex !== -1) finalLink = finalLink.substring(0, ampIndex);
  }

  return finalLink;
}

const SATRIAM_TIMEOUT_MS = 15000;

export async function sendMagicLink(targetEmail) {
  let res;
  try {
    res = await fetch(`${SATRIAM_BASE}/send-link`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: targetEmail }),
      signal: AbortSignal.timeout(SATRIAM_TIMEOUT_MS)
    });
  } catch (e) {
    throw new Error(e && e.name === 'TimeoutError' ? 'Server AM Premium terlalu lama merespons, coba lagi.' : 'Gagal menghubungi server AM Premium.');
  }
  const text = await res.text();
  let data;
  try { data = JSON.parse(text); } catch { data = { raw: text }; }
  if (!res.ok || data.success !== true) {
    throw new Error((data && data.message) || `API error: ${res.status}`);
  }
  return { message: data.message || 'Magic link terkirim' };
}

export async function applyPremium(targetEmail, magicLink) {
  let res;
  try {
    res = await fetch(`${SATRIAM_BASE}/verify-link`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: targetEmail, magicLink }),
      signal: AbortSignal.timeout(SATRIAM_TIMEOUT_MS)
    });
  } catch (e) {
    throw new Error(e && e.name === 'TimeoutError' ? 'Server AM Premium terlalu lama merespons, coba lagi.' : 'Gagal menghubungi server AM Premium.');
  }
  const text = await res.text();
  let data;
  try { data = JSON.parse(text); } catch { data = { raw: text }; }
  if (!res.ok || data.success !== true) {
    throw new Error((data && data.message) || `API error: ${res.status}`);
  }
  const expiry = data.validUntil
    ? new Date(data.validUntil).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })
    : 'N/A';
  return {
    expiry,
    membershipStatus: data.membershipStatus || 'PREMIUM_ACTIVE',
    planName: data.planName || 'Alight Motion Premium',
    uid: data.uid || 'N/A'
  };
}

export async function logHistory(db, uid, entry) {
  try {
    await db.collection('users').doc(uid).collection('amprem_history').add({
      ...entry,
      createdAt: Date.now()
    });
  } catch { /* riwayat gagal ditulis gak boleh bikin request utama gagal */ }
}

export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // --- Anti-scraping, sama seperti api/rch.js ---
  const ua = req.headers['user-agent'] || '';
  if (!ua || BOT_UA_RE.test(ua)) {
    return res.status(403).json({ error: 'Akses ditolak' });
  }
  if (ALLOWED_ORIGIN) {
    const origin = req.headers['origin'] || req.headers['referer'] || '';
    if (!origin.startsWith(ALLOWED_ORIGIN)) {
      return res.status(403).json({ error: 'Akses ditolak' });
    }
  }
  // --- end anti-scraping ---

  // Role & login diverifikasi ulang di server, bukan percaya klaim dari frontend.
  const { role, uid, provider, error: authError, dbError } = await getRoleFromRequest(req);
  if (!uid) {
    return res.status(401).json({ error: authError ? 'Verifikasi login gagal: ' + authError : 'Login dulu.' });
  }
  if (dbError) return res.status(500).json({ error: dbError });
  if (provider !== 'google.com' && provider !== 'password') {
    return res.status(401).json({ error: 'Metode login tidak didukung.' });
  }

  { // mode maintenance (diatur dari panel admin; OWNER tetap bisa akses)
    const mb = await maintenanceBlock('amprem', role);
    if (mb) return res.status(503).json(mb);
  }

  const body = typeof req.body === 'string' ? safeParse(req.body) : (req.body || {});
  const action = String(body.action || '').toLowerCase();

  await prepareDb();
  const admin = getAdminServices();
  if (!admin) {
    return res.status(500).json({ error: 'Firebase Admin belum dikonfigurasi: ' + (getAdminInitError() || 'env var kosong') });
  }

  if (action === 'history') {
    try {
      const snap = await admin.db.collection('users').doc(uid).collection('amprem_history')
        .orderBy('createdAt', 'desc').limit(HISTORY_LIMIT).get();
      const items = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      return res.status(200).json({ success: true, items });
    } catch (e) {
      return res.status(500).json({ error: 'Gagal memuat riwayat: ' + explainError(e) });
    }
  }

  const email = String(body.email || '').trim();

  if (!EMAIL_RE.test(email)) {
    return res.status(400).json({ error: 'Email target tidak valid.' });
  }
  if (action !== 'magic' && action !== 'apply') {
    return res.status(400).json({ error: 'action harus "magic", "apply", atau "history".' });
  }

  let rawLink = '';
  if (action === 'apply') {
    rawLink = String(body.link || '').trim();
    if (!rawLink || !rawLink.includes('http')) {
      return res.status(400).json({ error: 'Link tidak valid. Pastikan link dari email Alight Motion.' });
    }
  }

  await logFeature(uid, 'amprem');

  const unlimited = role === 'premium' || role === 'owner';

  // Limit harian per akun (server-side, Firestore, terpisah dari limit ZeeReact).
  let reserved = null;
  if (!unlimited) {
    try {
      const r = await reserveUsage(uid, FREE_LIMIT, USAGE_COLLECTION);
      if (!r.ok) {
        return res.status(429).json({
          error: 'Limit harian habis. Reset otomatis jam 00:00 WIB, atau upgrade ke premium.',
          _usage: { count: r.count, limit: FREE_LIMIT }
        });
      }
      reserved = r;
    } catch (e) {
      return res.status(500).json({ error: 'Gagal mengecek limit harian: ' + explainError(e) });
    }
  }

  const usageOut = (failed) => reserved
    ? { count: Math.max(0, reserved.count - (failed ? 1 : 0)), limit: FREE_LIMIT }
    : { count: 0, limit: null };

  try {
    if (action === 'magic') {
      const result = await sendMagicLink(email);
      await logHistory(admin.db, uid, { type: 'magic', email, message: result.message });
      return res.status(200).json({ success: true, message: result.message, _usage: usageOut(false) });
    } else {
      const finalLink = extractLink(rawLink);
      const result = await applyPremium(email, finalLink);
      await logHistory(admin.db, uid, { type: 'apply', email, planName: result.planName, expiry: result.expiry, membershipStatus: result.membershipStatus });
      return res.status(200).json({ success: true, ...result, _usage: usageOut(false) });
    }
  } catch (e) {
    if (reserved) {
      try { await refundUsage(uid, USAGE_COLLECTION); } catch { /* best-effort */ }
    }
    return res.status(502).json({ error: e.message || 'Gagal menghubungi API SATRIAM', _usage: usageOut(true) });
  }
}

function safeParse(s) {
  try { return JSON.parse(s); } catch { return {}; }
}
