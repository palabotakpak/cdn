// Helper Kickbox — deteksi email sementara (disposable / temp mail).
//
// Dua mode:
//  1) KICKBOX_API_KEY diisi  → pakai Verify API (https://api.kickbox.com/v2/verify), baca field `disposable`.
//     Tiap panggilan memakai 1 kredit Kickbox.
//  2) KICKBOX_API_KEY kosong → pakai endpoint gratis https://open.kickbox.com/v1/disposable/<domain> (tanpa kunci).
//
// Domain Google (gmail.com / googlemail.com) dilewati: bukan email sementara, jadi hemat kredit.
// Kalau Kickbox error / timeout → FAIL-OPEN (user asli tidak ikut terkunci); OTP tetap wajib diverifikasi.
// Underscore di nama file = helper, bukan Serverless Function (tidak menambah hitungan limit Vercel).

const TIMEOUT_MS = 4000;
const SKIP_DOMAINS = new Set(['gmail.com', 'googlemail.com']);

export async function kickboxCheck(email, fetchImpl = globalThis.fetch) {
  const addr = String(email || '').trim().toLowerCase();
  const domain = addr.split('@')[1] || '';
  if (!domain) return { ok: false, reason: 'invalid' };
  if (SKIP_DOMAINS.has(domain)) return { ok: true, skipped: true };

  const key = process.env.KICKBOX_API_KEY;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  try {
    if (key) {
      const url = 'https://api.kickbox.com/v2/verify?email=' + encodeURIComponent(addr) +
                  '&timeout=' + (TIMEOUT_MS - 500) + '&apikey=' + encodeURIComponent(key);
      const r = await fetchImpl(url, { signal: ctrl.signal });
      const j = await r.json().catch(() => null);
      if (!r.ok || !j || j.success === false) throw new Error('kickbox verify: ' + (j && j.message || r.status));
      return j.disposable === true ? { ok: false, reason: 'disposable' } : { ok: true };
    }
    const r = await fetchImpl('https://open.kickbox.com/v1/disposable/' + encodeURIComponent(domain), { signal: ctrl.signal });
    const j = await r.json().catch(() => null);
    if (!r.ok || !j || typeof j.disposable !== 'boolean') throw new Error('kickbox open: ' + r.status);
    return j.disposable ? { ok: false, reason: 'disposable' } : { ok: true };
  } catch (e) {
    console.error('[kickbox]', e && e.message);
    return { ok: true, error: true }; // fail-open
  } finally {
    clearTimeout(timer);
  }
}
