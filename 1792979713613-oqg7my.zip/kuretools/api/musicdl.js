// Vercel Serverless Function - Music Downloader (ketik judul lagu -> download MP3)
//
// POST /api/musicdl
//   body: { action: 'search',   query: '<judul lagu / artis>' }
//   body: { action: 'download', id: '<spotify track id>' }
//
// Alur:
//   1. search   -> daftar hasil lagu (judul, artis, durasi, thumbnail). Gak makan limit.
//   2. download -> ambil link MP3 untuk 1 hasil yang dipilih. Ini yang makan limit.
//
// Sumber: API nexray (api.nexray.eu.cc), gratis tanpa API key:
//   search   -> GET /search/spotify?q=<judul>
//   download -> GET /downloader/aio?url=<link track Spotify>  (result.medias[] -> mp3)
// Daftar provider ada di SEARCH_PROVIDERS & DOWNLOAD_PROVIDERS di bawah, gampang
// ditambah/diganti kalau ada yang mati.
//
// Wajib header Authorization: Bearer <idToken>, sama pola dengan endpoint lain.
// Tanpa limit untuk semua role (FREE/PREMIUM/OWNER), tetap wajib login.

import { getRoleFromRequest, reserveUsage, refundUsage, explainError, logDownload, logFeature } from './_firebaseAdmin.js';
import { maintenanceBlock } from './_firebaseAdmin.js';

const FREE_LIMIT = 10;
const USAGE_COLLECTION = 'musicdl_usage';
const MAX_RESULTS = 6;
const MAX_SECONDS = 15 * 60; // buang hasil > 15 menit (podcast, mix, live stream)
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '';
const BOT_UA_RE = /(curl|wget|python-requests|python-urllib|scrapy|axios\/|node-fetch|go-http-client|libwww-perl|httpclient|aiohttp|okhttp|postman|insomnia|headlesschrome|phantomjs|puppeteer|playwright|bot|crawler|spider|scraper)/i;
const BROWSER_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
const NEXRAY = 'https://api.nexray.eu.cc';
const TRACK_ID_RE = /^[A-Za-z0-9]{22}$/; // ID track Spotify

// ---------- helper umum ----------

async function getJson(url, timeoutMs = 9000, extraHeaders = {}) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      method: 'GET',
      signal: ctrl.signal,
      headers: { 'Accept': 'application/json', 'User-Agent': BROWSER_UA, ...extraHeaders }
    });
    const text = await res.text();
    let payload;
    try { payload = JSON.parse(text); } catch { throw new Error('Respons server tidak terbaca.'); }
    if (!res.ok) throw new Error(payload?.message || payload?.msg || payload?.error || `HTTP ${res.status}`);
    return payload;
  } finally {
    clearTimeout(timer);
  }
}

function durationToSeconds(d) {
  if (d == null || d === '') return null;
  if (typeof d === 'number') return d;
  if (typeof d === 'object') return durationToSeconds(d.seconds ?? d.timestamp ?? null);
  const s = String(d).trim();
  if (/^\d+$/.test(s)) return Number(s);
  const parts = s.split(':').map(Number);
  if (parts.some(Number.isNaN)) return null;
  return parts.reduce((acc, n) => acc * 60 + n, 0);
}

function fmtDuration(sec) {
  if (sec == null) return '';
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  const pad = n => String(n).padStart(2, '0');
  return h ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
}

function trackIdFromUrl(u) {
  const m = String(u || '').match(/open\.spotify\.com\/(?:intl-[a-z]+\/)?track\/([A-Za-z0-9]{22})/);
  return m ? m[1] : null;
}

function cleanTrack({ id, title, author, seconds, thumbnail }) {
  if (!id || !TRACK_ID_RE.test(id) || !title) return null;
  return {
    id,
    title: String(title).trim().slice(0, 200),
    author: author ? String(author).trim().slice(0, 100) : '',
    seconds: seconds ?? null,
    duration: fmtDuration(seconds),
    thumbnail: thumbnail && /^https:\/\//.test(thumbnail) ? thumbnail : ''
  };
}

function finalizeTracks(list) {
  const seen = new Set();
  const uniq = list.filter(t => t && !seen.has(t.id) && seen.add(t.id));
  // lagu = durasi diketahui dan <= batas. Kalau semua hasil kepanjangan, tetap tampilkan apa adanya.
  const songs = uniq.filter(t => t.seconds != null && t.seconds > 0 && t.seconds <= MAX_SECONDS);
  return (songs.length ? songs : uniq).slice(0, MAX_RESULTS);
}

// ---------- provider PENCARIAN ----------
// Tiap provider: async (query) => array track (boleh kosong). Lempar error kalau gagal.

// nexray: { status, result:[{ title, artist, duration:'2:13', thumbnail, popularity, album, release_date, url }] }
async function searchNexray(query) {
  const payload = await getJson(`${NEXRAY}/search/spotify?q=${encodeURIComponent(query)}`);
  if (payload?.status === false) throw new Error(payload.message || payload.error || 'Pencarian ditolak.');
  const arr = Array.isArray(payload?.result) ? payload.result : [];
  return arr.map(v => cleanTrack({
    id: trackIdFromUrl(v.url),
    title: v.title,
    author: v.artist,
    seconds: durationToSeconds(v.duration),
    thumbnail: v.thumbnail
  }));
}

const SEARCH_PROVIDERS = [searchNexray];

// ---------- provider DOWNLOAD (Spotify track id -> link MP3) ----------
// Tiap provider: async (trackUrl) => { url, title? }. Lempar error kalau gagal.

// nexray aio: { status, result:{ title, author, medias:[{ url, quality:'HQ', extension:'mp3', type:'audio' }], error } }
async function downloadNexray(trackUrl) {
  const payload = await getJson(`${NEXRAY}/downloader/aio?url=${encodeURIComponent(trackUrl)}`, 20000);
  const r = payload?.result;
  if (payload?.status === false || !r || r.error === true) {
    throw new Error(payload?.message || payload?.error || 'Provider menolak permintaan.');
  }
  const medias = Array.isArray(r.medias) ? r.medias : [];
  const mp3 = medias.find(m => m?.url && (m.extension === 'mp3' || m.type === 'audio')) || medias.find(m => m?.url);
  if (!mp3) throw new Error('Link MP3 tidak ditemukan di respons.');
  const title = [r.author, r.title].filter(Boolean).join(' - ') || null;
  return { url: mp3.url, title };
}

const DOWNLOAD_PROVIDERS = [downloadNexray];

async function firstSuccess(providers, arg, { acceptEmpty = false } = {}) {
  const errors = [];
  for (const p of providers) {
    try {
      const r = await p(arg);
      if (acceptEmpty || (Array.isArray(r) ? r.length : r)) return r;
      errors.push('hasil kosong');
    } catch (e) {
      errors.push(e.name === 'AbortError' ? 'timeout' : (e.message || 'error'));
    }
  }
  const err = new Error('Semua server sedang bermasalah. Coba lagi sebentar.');
  err.details = errors;
  throw err;
}

// ---------- handler ----------

export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // --- Anti-scraping, sama seperti endpoint lain ---
  const ua = req.headers['user-agent'] || '';
  if (!ua || BOT_UA_RE.test(ua)) {
    return res.status(403).json({ error: 'Akses ditolak' });
  }
  if (ALLOWED_ORIGIN) {
    const origin = req.headers['origin'] || req.headers['referer'] || '';
    if (!origin.startsWith(ALLOWED_ORIGIN)) {
      return res.status(403).json({ error: 'Akses ditolak' });
    }
  }
  // --- end anti-scraping ---

  const { role, uid, provider, error: authError, dbError } = await getRoleFromRequest(req);
  if (!uid) {
    return res.status(401).json({ error: authError ? 'Verifikasi login gagal: ' + authError : 'Login dulu.' });
  }
  if (dbError) return res.status(500).json({ error: dbError });
  if (provider !== 'google.com' && provider !== 'password') {
    return res.status(401).json({ error: 'Metode login tidak didukung.' });
  }

  { // mode maintenance (diatur dari panel admin; OWNER tetap bisa akses)
    const mb = await maintenanceBlock('musicdl', role);
    if (mb) return res.status(503).json(mb);
  }

  const body = typeof req.body === 'string' ? safeParse(req.body) : (req.body || {});
  const action = String(body.action || '');

  // ===== CARI LAGU (gak makan limit) =====
  if (action === 'search') {
    const query = String(body.query || '').trim().replace(/\s+/g, ' ');
    if (!query) return res.status(400).json({ error: 'Ketik judul lagunya dulu.' });
    if (query.length > 120) return res.status(400).json({ error: 'Judul kepanjangan (maks 120 karakter).' });
    try {
      const raw = await firstSuccess(SEARCH_PROVIDERS, query);
      const results = finalizeTracks(raw);
      if (!results.length) return res.status(404).json({ error: 'Lagu tidak ketemu. Coba judul + nama artis.' });
      return res.status(200).json({ success: true, results });
    } catch (e) {
      return res.status(502).json({ error: e.message || 'Gagal mencari lagu.' });
    }
  }

  // ===== DOWNLOAD (makan 1 jatah, dikembalikan kalau gagal) =====
  if (action === 'download') {
    const id = String(body.id || '').trim();
    if (!TRACK_ID_RE.test(id)) return res.status(400).json({ error: 'ID lagu tidak valid.' });
    await logFeature(uid, 'musicdl');
    const trackUrl = `https://open.spotify.com/track/${id}`; // dibangun ulang di server, bukan percaya URL dari client

    const unlimited = true; // semua tool di Tools Hub tanpa limit untuk semua role (FREE_LIMIT dibiarkan, tidak terpakai)
    let reserved = null;
    if (!unlimited) {
      try {
        const r = await reserveUsage(uid, FREE_LIMIT, USAGE_COLLECTION);
        if (!r.ok) {
          return res.status(429).json({
            error: 'Limit harian habis. Reset otomatis jam 00:00 WIB, atau upgrade ke premium.',
            _usage: { count: r.count, limit: FREE_LIMIT }
          });
        }
        reserved = r;
      } catch (e) {
        return res.status(500).json({ error: 'Gagal mengecek limit harian: ' + explainError(e) });
      }
    }
    const usageOut = (failed) => reserved
      ? { count: Math.max(0, reserved.count - (failed ? 1 : 0)), limit: FREE_LIMIT }
      : { count: 0, limit: null };

    try {
      const r = await firstSuccess(DOWNLOAD_PROVIDERS, trackUrl);
      // Riwayat (best-effort). Judul/artis/cover dari client hanya buat tampilan, jadi dibatasi panjang & hanya https.
      await logDownload(uid, {
        type: 'music', key: id, ref: id,
        title: r.title || body.title,
        subtitle: body.author,
        thumbnail: body.thumbnail
      });
      return res.status(200).json({ success: true, id, title: r.title, url: r.url, _usage: usageOut(false) });
    } catch (e) {
      if (reserved) {
        try { await refundUsage(uid, USAGE_COLLECTION); } catch { /* best-effort */ }
      }
      return res.status(502).json({ error: e.message || 'Gagal mengambil MP3.', _usage: usageOut(true) });
    }
  }

  return res.status(400).json({ error: 'Action tidak dikenal.' });
}

function safeParse(s) {
  try { return JSON.parse(s); } catch { return {}; }
}
