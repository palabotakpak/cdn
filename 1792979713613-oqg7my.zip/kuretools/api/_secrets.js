// Rahasia untuk tanda tangan HMAC (captcha, OTP). Pakai env kalau ada. Kalau env kosong, JANGAN pakai string tetap
// yang ada di source code (bisa ditebak siapa saja → token captcha/OTP bisa dipalsukan). Sebagai gantinya diturunkan
// dari rahasia lain yang sudah ada di server (service account / OWNER_CODE), atau acak per-instance sebagai pilihan terakhir.
import crypto from 'crypto';

const seed = process.env.FIREBASE_SERVICE_ACCOUNT || process.env.OWNER_CODE || process.env.GMAIL_APP_PASS || '';
const lastResort = crypto.randomBytes(32).toString('hex');

export function secretFor(envName, label) {
  const v = process.env[envName];
  if (v) return v;
  return crypto.createHash('sha256').update(label + ':' + (seed || lastResort)).digest('hex');
}
