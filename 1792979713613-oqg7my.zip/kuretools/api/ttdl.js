// Vercel Serverless Function - TikTok Downloader (tanpa watermark)
//
// POST /api/ttdl
//   body: { link: '<url video/foto TikTok>' }
//
// Lewat API publik tikwm.com (gratis, tanpa API key). Ambil link download
// video tanpa watermark (biasa & HD), link versi watermark, musik asli, dan
// (kalau post-nya foto/slideshow) daftar link gambarnya.
//
// Catatan: endpoint ini juga melayani Fake Lobby FF (body { action:'fakelobyff', game:'ff'|'ffduo'|'ml', nickname, nickname2?, avatar? })
// IQC Maker (body { action:'iqc', style, text, time, imgurl })
// Gambar ke URL (body { action:'imgurl', mime, data })
// Fake Spotify (body { action:'fakespotify' }, cuma catat statistik; gambarnya digambar di browser)
// dan proxy download file (body { action:'dl', url, filename })
// supaya jumlah Serverless Function tetap di bawah limit 12 (Vercel Hobby plan).
//
// Wajib header Authorization: Bearer <idToken>, sama pola dengan endpoint lain.
// Tanpa limit untuk semua role (FREE/PREMIUM/OWNER), tetap wajib login.

import { getRoleFromRequest, reserveUsage, refundUsage, explainError, logDownload, logFeature } from './_firebaseAdmin.js';
import { fetchLobby, fetchMakerImage, buildLobbyMlUrl, buildLobbyDuoUrl, MAX_NICK } from './_fakelobyff.js';
import { buildIqcUrl } from './_iqc.js';
import { prepareImage, uploadImage } from './_imgurl.js';
import { streamDownload } from './_dlproxy.js';
import { maintenanceBlock } from './_firebaseAdmin.js';

const TIKWM_API = 'https://www.tikwm.com/api/';
const FREE_LIMIT = 15;
const USAGE_COLLECTION = 'ttdl_usage';
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '';
const BOT_UA_RE = /(curl|wget|python-requests|python-urllib|scrapy|axios\/|node-fetch|go-http-client|libwww-perl|httpclient|aiohttp|okhttp|postman|insomnia|headlesschrome|phantomjs|puppeteer|playwright|bot|crawler|spider|scraper)/i;
const TIKTOK_RE = /(tiktok\.com|vt\.tiktok\.com|vm\.tiktok\.com|douyin\.com)/i;

function absolutize(u) {
  if (!u) return null;
  return u.startsWith('http') ? u : `https://www.tikwm.com${u}`;
}

async function fetchTikTok(link) {
  const url = `${TIKWM_API}?url=${encodeURIComponent(link)}&hd=1`;
  const res = await fetch(url, {
    method: 'GET',
    headers: {
      'Accept': 'application/json',
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Origin': 'https://www.tikwm.com',
      'Referer': 'https://www.tikwm.com/'
    }
  });

  const text = await res.text();
  let payload;
  try { payload = JSON.parse(text); } catch { throw new Error('Respons server tidak terbaca.'); }

  if (!res.ok || payload.code !== 0 || !payload.data) {
    throw new Error(payload.msg || `Gagal mengambil data (${res.status}).`);
  }

  const d = payload.data;
  const images = Array.isArray(d.images) ? d.images.map(absolutize).filter(Boolean) : [];

  return {
    id: d.id || null,
    title: (d.title || '').trim(),
    cover: absolutize(d.cover || d.origin_cover),
    duration: d.duration || null,
    author: {
      nickname: d.author?.nickname || null,
      uniqueId: d.author?.unique_id || null,
      avatar: absolutize(d.author?.avatar)
    },
    stats: {
      plays: d.play_count ?? null,
      likes: d.digg_count ?? null,
      comments: d.comment_count ?? null,
      shares: d.share_count ?? null
    },
    video: images.length ? null : {
      noWatermark: absolutize(d.play),
      noWatermarkHD: absolutize(d.hdplay),
      watermark: absolutize(d.wmplay)
    },
    music: d.music ? { url: absolutize(d.music), title: d.music_info?.title || null } : null,
    images // kosong kalau postingannya video biasa, keisi kalau postingan foto/slideshow
  };
}

export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // --- Anti-scraping, sama seperti endpoint lain ---
  const ua = req.headers['user-agent'] || '';
  if (!ua || BOT_UA_RE.test(ua)) {
    return res.status(403).json({ error: 'Akses ditolak' });
  }
  if (ALLOWED_ORIGIN) {
    const origin = req.headers['origin'] || req.headers['referer'] || '';
    if (!origin.startsWith(ALLOWED_ORIGIN)) {
      return res.status(403).json({ error: 'Akses ditolak' });
    }
  }
  // --- end anti-scraping ---

  const { role, uid, provider, error: authError, dbError } = await getRoleFromRequest(req);
  if (!uid) {
    return res.status(401).json({ error: authError ? 'Verifikasi login gagal: ' + authError : 'Login dulu.' });
  }
  if (dbError) return res.status(500).json({ error: dbError });
  if (provider !== 'google.com' && provider !== 'password') {
    return res.status(401).json({ error: 'Metode login tidak didukung.' });
  }

  const body = typeof req.body === 'string' ? safeParse(req.body) : (req.body || {});

  { // mode maintenance (diatur dari panel admin; OWNER tetap bisa akses). 'dl' = proxy download file, tetap jalan.
    const mKey = { fakelobyff: 'fakelobyff', iqc: 'iqc', imgurl: 'imgurl', fakespotify: 'fakespotify' }[body.action] || (body.action === 'dl' ? null : 'ttdl');
    const mb = mKey ? await maintenanceBlock(mKey, role) : null;
    if (mb) return res.status(503).json(mb);
  }

  { // statistik: 'dl' = stream file hasil download, gak dihitung lagi
    const feat = { fakelobyff: 'fakelobyff', iqc: 'iqc', imgurl: 'imgurl', fakespotify: 'fakespotify' }[body.action] || (body.action === 'dl' ? null : 'ttdl');
    if (feat) await logFeature(uid, feat);
  }

  // --- Cabang Fake Lobby FF (digabung ke sini, hemat 1 Serverless Function) ---
  if (body.action === 'fakelobyff') {
    if (body.game === 'ml') {
      const built = buildLobbyMlUrl(body);
      if (built.error) return res.status(400).json({ error: built.error });
      try {
        const result = await fetchMakerImage(built.url);
        return res.status(200).json({ success: true, nickname: String(body.nickname).trim(), ...result });
      } catch (e) {
        return res.status(502).json({ error: e.message || 'Gagal memproses lobby ML.' });
      }
    }
    if (body.game === 'ffduo') {
      const built = buildLobbyDuoUrl(body);
      if (built.error) return res.status(400).json({ error: built.error });
      try {
        const result = await fetchMakerImage(built.url);
        return res.status(200).json({ success: true, nickname: String(body.nickname).trim(), ...result });
      } catch (e) {
        return res.status(502).json({ error: e.message || 'Gagal memproses lobby duo.' });
      }
    }
    const nickname = String(body.nickname || '').trim();
    if (!nickname) return res.status(400).json({ error: 'Nickname belum diisi.' });
    if (nickname.length > MAX_NICK) return res.status(400).json({ error: `Nickname maksimal ${MAX_NICK} karakter.` });
    try {
      const result = await fetchLobby(nickname);
      return res.status(200).json({ success: true, nickname, ...result });
    } catch (e) {
      return res.status(502).json({ error: e.message || 'Gagal memproses nickname ini.' });
    }
  }

  // --- Cabang IQC Maker (digabung ke sini, hemat 1 Serverless Function) ---
  if (body.action === 'iqc') {
    const built = buildIqcUrl(body);
    if (built.error) return res.status(400).json({ error: built.error });
    try {
      const result = await fetchMakerImage(built.url);
      return res.status(200).json({ success: true, ...result });
    } catch (e) {
      return res.status(502).json({ error: e.message || 'Gagal membuat gambar IQC.' });
    }
  }

  // --- Cabang Fake Spotify: gambar digambar di browser (canvas), server cuma verifikasi login + catat statistik ---
  if (body.action === 'fakespotify') {
    return res.status(200).json({ success: true });
  }

  // --- Cabang proxy download: file di-stream lewat server ini, jadi download tetap di web sendiri ---
  if (body.action === 'dl') {
    try {
      await streamDownload(res, { url: body.url, filename: body.filename });
      return;
    } catch (e) {
      if (res.headersSent) { try { res.end(); } catch { /* abaikan */ } return; }
      return res.status(400).json({ error: e.message || 'Gagal mengunduh file.' });
    }
  }

  // --- Cabang Gambar ke URL (digabung ke sini, hemat 1 Serverless Function) ---
  if (body.action === 'imgurl') {
    const prep = prepareImage(body);
    if (prep.error) return res.status(400).json({ error: prep.error });
    try {
      const result = await uploadImage(prep);
      return res.status(200).json({ success: true, ...result, size: prep.buffer.length });
    } catch (e) {
      return res.status(502).json({ error: e.message || 'Gagal upload gambar.' });
    }
  }

  const link = String(body.link || '').trim();
  if (!link) return res.status(400).json({ error: 'Link video TikTok belum diisi.' });
  if (!TIKTOK_RE.test(link)) return res.status(400).json({ error: 'Link itu bukan dari TikTok. Paste link video/postingan TikTok dulu.' });

  const unlimited = true; // semua tool di Tools Hub tanpa limit untuk semua role (FREE_LIMIT dibiarkan, tidak terpakai)

  let reserved = null;
  if (!unlimited) {
    try {
      const r = await reserveUsage(uid, FREE_LIMIT, USAGE_COLLECTION);
      if (!r.ok) {
        return res.status(429).json({
          error: 'Limit harian habis. Reset otomatis jam 00:00 WIB, atau upgrade ke premium.',
          _usage: { count: r.count, limit: FREE_LIMIT }
        });
      }
      reserved = r;
    } catch (e) {
      return res.status(500).json({ error: 'Gagal mengecek limit harian: ' + explainError(e) });
    }
  }

  const usageOut = (failed) => reserved
    ? { count: Math.max(0, reserved.count - (failed ? 1 : 0)), limit: FREE_LIMIT }
    : { count: 0, limit: null };

  try {
    const result = await fetchTikTok(link);
    await logDownload(uid, {
      type: 'tiktok', key: result.id || link, ref: link,
      title: result.title || result.author?.nickname,
      subtitle: result.author?.uniqueId ? '@' + result.author.uniqueId : '',
      thumbnail: result.cover
    });
    return res.status(200).json({ success: true, ...result, _usage: usageOut(false) });
  } catch (e) {
    if (reserved) {
      try { await refundUsage(uid, USAGE_COLLECTION); } catch { /* best-effort */ }
    }
    return res.status(502).json({ error: e.message || 'Gagal memproses link ini.', _usage: usageOut(true) });
  }
}

function safeParse(s) {
  try { return JSON.parse(s); } catch { return {}; }
}
