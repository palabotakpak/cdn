// Helper IQC Maker (BUKAN serverless function: prefix underscore = tidak dihitung Vercel).
// Dipanggil dari api/ttdl.js lewat body { action:'iqc', style, text, time, imgurl }
// supaya jumlah Serverless Function tetap di bawah limit 12 (Vercel Hobby plan).
//
// Endpoint upstream (api-moondrowend.web.id/api/maker/...):
//   iqc      ?text=
//   iqc2     ?text=&time=
//   iqcpink  ?text=&time=
//   iqc3     ?text=&time=&imgurl=
//   igqc     ?txt=&imgUrl=        (nama parameter beda, dipetakan lewat `map`)

const BASE = 'https://api-moondrowend.web.id/api/maker/';
const MAX_TEXT = 300;
const TIME_RE = /^\d{1,2}[:.]\d{2}$/;

const STYLES = {
  iqc:     { params: ['text'] },
  iqc2:    { params: ['text', 'time'] },
  iqcpink: { params: ['text', 'time'] },
  iqc3:    { params: ['text', 'time', 'imgurl'] },
  igqc:    { params: ['text', 'imgurl'], map: { text: 'txt', imgurl: 'imgUrl' } }
};

// Validasi input, lalu bangun URL upstream. Return { error } atau { url }.
export function buildIqcUrl({ style, text, time, imgurl }) {
  const cfg = STYLES[style];
  if (!cfg) return { error: 'Gaya IQC tidak dikenal.' };

  text = String(text || '').trim();
  if (!text) return { error: 'Teks belum diisi.' };
  if (text.length > MAX_TEXT) return { error: `Teks maksimal ${MAX_TEXT} karakter.` };

  const q = new URLSearchParams();
  const key = (k) => (cfg.map && cfg.map[k]) || k; // nama parameter upstream
  q.set(key('text'), text);

  if (cfg.params.includes('time')) {
    time = String(time || '').trim();
    if (!TIME_RE.test(time)) return { error: 'Format jam harus seperti 09:41.' };
    q.set(key('time'), time);
  }

  if (cfg.params.includes('imgurl')) {
    imgurl = String(imgurl || '').trim();
    if (!imgurl) return { error: 'Link gambar belum diisi.' };
    if (imgurl.length > 500 || !/^https?:\/\//i.test(imgurl)) {
      return { error: 'Link gambar harus diawali http:// atau https://.' };
    }
    q.set(key('imgurl'), imgurl);
  }

  return { url: `${BASE}${style}?${q.toString()}` };
}
