// Vercel Serverless Function — OTP pra-registrasi
//
// POST /api/otp?action=send     { email }                    → kirim OTP (HANYA @gmail.com), return { ok }
// POST /api/otp?action=verify   { email, otp }               → verifikasi OTP, return { ok, ticket }
// POST /api/otp?action=register { email, password, ticket }  → buat akun (server-side, wajib ticket valid)
//
// Akun Google BARU (wajib header Authorization: Bearer <idToken>; email diambil dari token, bukan dari body):
// POST /api/otp?action=gsend    {}                           → cek Kickbox (email sementara ditolak + akun dihapus), kirim OTP
// POST /api/otp?action=gverify  { otp }                      → verifikasi OTP, tandai users/{uid}.otpVerified = true
//
// Semua action KIRIM OTP (send & gsend) wajib body { captchaToken, captchaAnswer } dari GET /api/captcha?type=img.
// Captcha sekali pakai (id dicatat di Firestore koleksi 'captcha_used', field exp bisa dipasang TTL policy).
//
// Env var opsional: KICKBOX_API_KEY (kosong = pakai endpoint gratis open.kickbox.com, cek domain saja)
//
// "ticket" adalah HMAC token 10 menit yang harus dikirim ke frontend.
// Frontend pakai ticket ini untuk createUserWithEmailAndPassword di Firebase,
// TAPI hanya setelah server mengonfirmasi OTP-nya benar.
// Akun Firebase TIDAK dibuat di sini — tetap dibuat oleh Firebase Auth di client.
// Bedanya: tanpa ticket valid, endpoint /api/otp/verify tidak akan mengembalikan
// konfirmasi, sehingga logika signup di frontend tidak akan dilanjutkan.
//
// Env vars yang perlu ditambahkan di Vercel:
//   GMAIL_USER       → email Gmail pengirim OTP
//   GMAIL_APP_PASS   → App Password 16 karakter dari Google
//   OTP_SECRET       → string acak bebas, untuk tanda tangan HMAC ticket
//
// Cara dapat App Password Gmail:
//   myaccount.google.com → Security → 2-Step Verification → App passwords

import crypto from 'crypto';
import { createTransport } from 'nodemailer';
import { prepareDb, getAdminServices, getRoleFromRequest } from './_firebaseAdmin.js';
import { kickboxCheck } from './_kickbox.js';
import { secretFor } from './_secrets.js';
import { consumeCaptcha, captchaHandler } from './_captcha.js';

// ── Konfigurasi ───────────────────────────────────────────────────────────────
const OTP_TTL_MS    = 5 * 60 * 1000;   // OTP valid 5 menit
const TICKET_TTL_MS = 10 * 60 * 1000;  // Ticket valid 10 menit (buat createUser)
const MAX_ATTEMPTS  = 5;
const RESEND_COOLDOWN_MS = 60 * 1000;  // Cooldown kirim ulang 60 detik

// ── Penyimpanan OTP di Firestore (collection 'otp_codes') ─────────────────────
// Serverless Vercel bisa jalan di banyak instance, jadi OTP TIDAK boleh disimpan di memori
// (kirim & verifikasi bisa mendarat di instance berbeda). Yang disimpan cuma HASH-nya.
const SEND_LIMIT_PER_IP = 5;            // maks 5 kirim OTP / 10 menit / IP (per instance, sekadar anti-spam)
const SEND_WINDOW_MS = 10 * 60 * 1000;
const ipHits = new Map();
function ipLimited(ip) {
  const now = Date.now();
  const arr = (ipHits.get(ip) || []).filter(t => now - t < SEND_WINDOW_MS);
  if (arr.length >= SEND_LIMIT_PER_IP) { ipHits.set(ip, arr); return true; }
  arr.push(now); ipHits.set(ip, arr);
  return false;
}
function docId(email) { return crypto.createHash('sha256').update(email).digest('hex'); }
function otpSecret() { return secretFor('OTP_SECRET', 'otp'); }
function hashOtp(email, otp) { return crypto.createHmac('sha256', otpSecret()).update(email + ':' + otp).digest('hex'); }
function safeEq(a, b) {
  const x = Buffer.from(String(a)), y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

// ── Nodemailer ────────────────────────────────────────────────────────────────
function getTransporter() {
  return createTransport({
    service: 'gmail',
    auth: {
      user: String(process.env.GMAIL_USER || '').trim(),
      pass: String(process.env.GMAIL_APP_PASS || '').replace(/\s+/g, ''), // App Password dari Google ditampilkan berspasi
    },
  });
}

// ── HMAC ticket (bukti OTP sudah diverifikasi) ────────────────────────────────
function makeTicket(email) {
  const secret = otpSecret();
  const payload = Buffer.from(JSON.stringify({ email, exp: Date.now() + TICKET_TTL_MS })).toString('base64url');
  const sig = crypto.createHmac('sha256', secret).update(payload).digest('base64url');
  return payload + '.' + sig;
}

export function verifyTicket(ticketStr, email) {
  try {
    const secret = otpSecret();
    const [payload, sig] = (ticketStr || '').split('.');
    if (!payload || !sig) return false;
    const expected = crypto.createHmac('sha256', secret).update(payload).digest('base64url');
    const sigBuf = Buffer.from(sig);
    const expBuf = Buffer.from(expected);
    if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) return false;
    const data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    if (!data.exp || Date.now() > data.exp) return false;
    if (data.email !== email) return false;
    return true;
  } catch {
    return false;
  }
}

// ── Helper ────────────────────────────────────────────────────────────────────
function genOTP() {
  return crypto.randomInt(100000, 999999).toString();
}

// OTP khusus Gmail. '+alias' ditolak supaya 1 inbox gak bisa bikin akun tak terbatas.
function validGmail(e) {
  return typeof e === 'string' && /^[a-z0-9._]{6,40}@gmail\.com$/.test(e.trim().toLowerCase());
}

function validEmail(e) {
  return typeof e === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e.trim());
}

function readBody(req) {
  return new Promise(resolve => {
    if (req.body && typeof req.body === 'object') return resolve(req.body);
    let raw = '';
    req.on('data', c => { raw += c; });
    req.on('end', () => { try { resolve(JSON.parse(raw || '{}')); } catch { resolve({}); } });
  });
}

// ── Email template ────────────────────────────────────────────────────────────
function emailHTML(otp) {
  return `<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"></head>
<body style="font-family:Arial,sans-serif;background:#0d0d1a;padding:30px;">
  <div style="max-width:460px;margin:auto;background:#13131f;border:1px solid #22223a;border-radius:14px;padding:32px;">
    <h2 style="color:#e2e2f0;margin:0 0 8px">Kode Verifikasi Kuretools</h2>
    <p style="color:#6b6b8a;margin:0 0 24px;font-size:14px;">Masukkan kode berikut untuk menyelesaikan pendaftaran:</p>
    <div style="background:#1a1a2e;border-radius:10px;padding:22px;text-align:center;margin-bottom:24px;">
      <span style="font-size:40px;font-weight:700;letter-spacing:12px;color:#6366f1;">${otp}</span>
    </div>
    <p style="color:#6b6b8a;font-size:13px;margin:0 0 6px;">Kode berlaku <strong style="color:#e2e2f0;">5 menit</strong>.</p>
    <p style="color:#6b6b8a;font-size:13px;margin:0;">Jika kamu tidak mendaftar, abaikan email ini.</p>
    <hr style="border:none;border-top:1px solid #22223a;margin:24px 0 12px">
    <p style="color:#3a3a5a;font-size:11px;text-align:center;margin:0;">Kuretools &copy; ${new Date().getFullYear()}</p>
  </div>
</body>
</html>`;
}

// ── Handler utama ─────────────────────────────────────────────────────────────
export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');

  // /api/captcha di-rewrite ke sini (vercel.json) supaya tidak memakai slot Serverless Function sendiri (limit 12 di Hobby).
  if (String((req.query && req.query.action) || '').toLowerCase() === 'captcha') return captchaHandler(req, res);

  if (req.method !== 'POST') {
    return res.status(405).json({ ok: false, error: 'Method not allowed' });
  }

  const body = await readBody(req);
  const action = (req.query.action || '').toLowerCase();

  await prepareDb();
  const admin = getAdminServices();
  if (!admin) {
    return res.status(500).json({ ok: false, error: 'Firebase Admin belum dikonfigurasi di server.' });
  }
  const col = admin.db.collection('otp_codes');

  // ── POST /api/otp?action=send ─────────────────────────────────────────────
  if (action === 'send') {
    const email = (body.email || '').trim().toLowerCase();
    if (!validEmail(email)) {
      return res.status(400).json({ ok: false, error: 'Format email tidak valid.' });
    }
    if (!validGmail(email)) {
      return res.status(400).json({ ok: false, error: 'Daftar dengan OTP hanya untuk email @gmail.com (tanpa tanda +).' });
    }
    const ip = String(req.headers['x-forwarded-for'] || req.socket?.remoteAddress || '').split(',')[0].trim();
    if (ipLimited(ip)) {
      return res.status(429).json({ ok: false, error: 'Terlalu banyak permintaan OTP, coba lagi beberapa menit lagi.' });
    }

    if (!process.env.GMAIL_USER || !process.env.GMAIL_APP_PASS) {
      return res.status(500).json({ ok: false, error: 'Konfigurasi email belum diset di Vercel.' });
    }

    const capErr = await consumeCaptcha(admin, body);
    if (capErr) return res.status(400).json({ ok: false, captcha: true, error: capErr });

    // Email sudah terdaftar? Jangan buang kuota kirim email.
    try {
      await admin.auth.getUserByEmail(email);
      return res.status(409).json({ ok: false, error: 'Email ini sudah terdaftar. Silakan MASUK (atau pakai tombol Google).' });
    } catch (e) {
      if (!(e && e.code === 'auth/user-not-found')) {
        return res.status(500).json({ ok: false, error: 'Gagal mengecek email, coba lagi.' });
      }
    }

    const now = Date.now();
    const ref = col.doc(docId(email));
    try {
      const snap = await ref.get();
      const last = snap.exists ? (snap.data().lastSentAt || 0) : 0;
      if (now - last < RESEND_COOLDOWN_MS) {
        const wait = Math.ceil((RESEND_COOLDOWN_MS - (now - last)) / 1000);
        return res.status(429).json({ ok: false, error: `Tunggu ${wait} detik sebelum kirim ulang OTP.` });
      }
      const otp = genOTP();
      await ref.set({ otpHash: hashOtp(email, otp), expiresAt: now + OTP_TTL_MS, attempts: 0, lastSentAt: now });
      try {
        await getTransporter().sendMail({
          from: `"Kuretools" <${process.env.GMAIL_USER}>`,
          to: email,
          subject: 'Kode Verifikasi Pendaftaran Kuretools',
          html: emailHTML(otp),
        });
      } catch (err) {
        await ref.delete().catch(() => {});
        console.error('[OTP send error]', err.message);
        return res.status(500).json({ ok: false, error: 'Gagal mengirim email. Cek konfigurasi Gmail.' });
      }
      return res.status(200).json({ ok: true });
    } catch (err) {
      console.error('[OTP store error]', err.message);
      return res.status(500).json({ ok: false, error: 'Gagal menyimpan OTP, coba lagi.' });
    }
  }

  // ── POST /api/otp?action=verify ───────────────────────────────────────────
  if (action === 'verify') {
    const email = (body.email || '').trim().toLowerCase();
    const otp   = String(body.otp || '').trim();

    if (!validGmail(email) || !otp) {
      return res.status(400).json({ ok: false, error: 'Email (@gmail.com) atau OTP kosong.' });
    }

    const ref = col.doc(docId(email));
    let result;
    try {
      result = await admin.db.runTransaction(async (t) => {
        const snap = await t.get(ref);
        if (!snap.exists) return { err: 'OTP tidak ditemukan. Minta kode baru.' };
        const r = snap.data();
        if (Date.now() > r.expiresAt) { t.delete(ref); return { err: 'OTP sudah kedaluwarsa. Minta kode baru.' }; }
        if ((r.attempts || 0) >= MAX_ATTEMPTS) { t.delete(ref); return { err: 'Terlalu banyak percobaan salah. Minta kode baru.' }; }
        if (!safeEq(r.otpHash, hashOtp(email, otp))) {
          t.update(ref, { attempts: (r.attempts || 0) + 1 });
          return { err: `OTP salah. Sisa percobaan: ${MAX_ATTEMPTS - (r.attempts || 0) - 1}.` };
        }
        t.delete(ref); // sekali pakai
        return { ok: true };
      });
    } catch (err) {
      console.error('[OTP verify error]', err.message);
      return res.status(500).json({ ok: false, error: 'Gagal memverifikasi OTP, coba lagi.' });
    }
    if (!result.ok) return res.status(400).json({ ok: false, error: result.err });
    return res.status(200).json({ ok: true, ticket: makeTicket(email) });
  }

  // ── POST /api/otp?action=register ─────────────────────────────────────────
  // Akun dibuat DI SERVER (Admin SDK) dan hanya kalau ticket hasil verifikasi OTP valid,
  // jadi syarat "OTP + @gmail.com" ditegakkan server, bukan cuma tampilan.
  if (action === 'register') {
    const email = (body.email || '').trim().toLowerCase();
    const password = String(body.password || '');
    if (!validGmail(email)) {
      return res.status(400).json({ ok: false, error: 'Daftar dengan OTP hanya untuk email @gmail.com.' });
    }
    if (password.length < 8 || password.length > 64) {
      return res.status(400).json({ ok: false, error: 'Password 8-64 karakter.' });
    }
    if (!verifyTicket(body.ticket, email)) {
      return res.status(403).json({ ok: false, error: 'Verifikasi OTP tidak valid atau kedaluwarsa. Ulangi dari awal.' });
    }
    try {
      const created = await admin.auth.createUser({ email, password, emailVerified: true });
      // Tandai sudah lolos OTP, supaya gerbang di getRoleFromRequest tidak minta OTP lagi.
      try {
        await admin.db.collection('users').doc(created.uid).set({ role: 'free', email, otpVerified: true, otpVerifiedAt: Date.now() }, { merge: true });
      } catch (e) {
        console.error('[OTP register mark error]', e && e.message);
        await admin.auth.deleteUser(created.uid).catch(() => {});
        return res.status(500).json({ ok: false, error: 'Gagal menyimpan akun, coba lagi.' });
      }
      return res.status(200).json({ ok: true });
    } catch (e) {
      if (e && e.code === 'auth/email-already-exists') {
        return res.status(409).json({ ok: false, error: 'Email ini sudah terdaftar. Silakan MASUK.' });
      }
      if (e && e.code === 'auth/invalid-password') {
        return res.status(400).json({ ok: false, error: 'Password tidak valid.' });
      }
      console.error('[OTP register error]', e && e.message);
      return res.status(500).json({ ok: false, error: 'Gagal membuat akun, coba lagi.' });
    }
  }

  // ── Akun Google baru: gsend / gverify ─────────────────────────────────────
  if (action === 'gsend' || action === 'gverify') {
    const who = await getRoleFromRequest(req, { allowPending: true });
    if (!who.uid) {
      return res.status(401).json({ ok: false, error: who.error ? ('Verifikasi login gagal: ' + who.error) : 'Login dulu.' });
    }
    if (!who.otpPending) {
      return res.status(400).json({ ok: false, error: 'Akun ini tidak perlu verifikasi OTP.' });
    }
    const email = String(who.email || '').trim().toLowerCase();
    if (!validEmail(email)) {
      return res.status(400).json({ ok: false, error: 'Akun Google ini tidak punya email yang valid.' });
    }
    const ref = col.doc(docId('g:' + who.uid));
    const key = who.uid + ':' + email; // OTP terikat ke uid + email, tidak bisa dipakai akun lain

    if (action === 'gsend') {
      const ip = String(req.headers['x-forwarded-for'] || req.socket?.remoteAddress || '').split(',')[0].trim();
      if (ipLimited(ip)) {
        return res.status(429).json({ ok: false, error: 'Terlalu banyak permintaan OTP, coba lagi beberapa menit lagi.' });
      }
      if (!process.env.GMAIL_USER || !process.env.GMAIL_APP_PASS) {
        return res.status(500).json({ ok: false, error: 'Konfigurasi email belum diset di Vercel.' });
      }

      const capErr = await consumeCaptcha(admin, body);
      if (capErr) return res.status(400).json({ ok: false, captcha: true, error: capErr });

      // Kickbox: tolak email sementara. Akun barunya dihapus supaya tidak numpuk di Firebase Auth.
      const kb = await kickboxCheck(email);
      if (!kb.ok) {
        try { await admin.auth.deleteUser(who.uid); } catch (e) { console.error('[OTP gsend deleteUser]', e && e.message); }
        try { await admin.db.collection('users').doc(who.uid).delete(); } catch { /* belum ada dokumen, aman */ }
        return res.status(403).json({ ok: false, blocked: true, error: 'Email sementara (temp mail) tidak diizinkan. Daftar pakai email asli ya.' });
      }

      const now = Date.now();
      try {
        const snap = await ref.get();
        const last = snap.exists ? (snap.data().lastSentAt || 0) : 0;
        if (now - last < RESEND_COOLDOWN_MS) {
          const wait = Math.ceil((RESEND_COOLDOWN_MS - (now - last)) / 1000);
          return res.status(429).json({ ok: false, error: `Tunggu ${wait} detik sebelum kirim ulang OTP.` });
        }
        const otp = genOTP();
        await ref.set({ otpHash: hashOtp(key, otp), expiresAt: now + OTP_TTL_MS, attempts: 0, lastSentAt: now });
        try {
          await getTransporter().sendMail({
            from: `"Kuretools" <${process.env.GMAIL_USER}>`,
            to: email,
            subject: 'Kode Verifikasi Pendaftaran Kuretools',
            html: emailHTML(otp),
          });
        } catch (err) {
          await ref.delete().catch(() => {});
          console.error('[OTP gsend mail error]', err.code, err.responseCode, err.response || err.message);
          return res.status(500).json({ ok: false, error: 'Gagal mengirim email. Cek konfigurasi Gmail.' });
        }
        return res.status(200).json({ ok: true, email });
      } catch (err) {
        console.error('[OTP gsend store error]', err.message);
        return res.status(500).json({ ok: false, error: 'Gagal menyimpan OTP, coba lagi.' });
      }
    }

    // gverify
    const otp = String(body.otp || '').trim();
    if (!/^\d{6}$/.test(otp)) {
      return res.status(400).json({ ok: false, error: 'Kode OTP harus 6 digit.' });
    }
    let result;
    try {
      result = await admin.db.runTransaction(async (t) => {
        const snap = await t.get(ref);
        if (!snap.exists) return { err: 'OTP tidak ditemukan. Minta kode baru.' };
        const r = snap.data();
        if (Date.now() > r.expiresAt) { t.delete(ref); return { err: 'OTP sudah kedaluwarsa. Minta kode baru.' }; }
        if ((r.attempts || 0) >= MAX_ATTEMPTS) { t.delete(ref); return { err: 'Terlalu banyak percobaan salah. Minta kode baru.' }; }
        if (!safeEq(r.otpHash, hashOtp(key, otp))) {
          t.update(ref, { attempts: (r.attempts || 0) + 1 });
          return { err: `OTP salah. Sisa percobaan: ${MAX_ATTEMPTS - (r.attempts || 0) - 1}.` };
        }
        t.delete(ref); // sekali pakai
        return { ok: true };
      });
    } catch (err) {
      console.error('[OTP gverify error]', err.message);
      return res.status(500).json({ ok: false, error: 'Gagal memverifikasi OTP, coba lagi.' });
    }
    if (!result.ok) return res.status(400).json({ ok: false, error: result.err });
    try {
      const uref = admin.db.collection('users').doc(who.uid);
      const usnap = await uref.get();
      if (usnap.exists) await uref.set({ otpVerified: true, otpVerifiedAt: Date.now() }, { merge: true });
      else await uref.set({ role: 'free', email, otpVerified: true, otpVerifiedAt: Date.now() });
    } catch (err) {
      console.error('[OTP gverify mark error]', err.message);
      return res.status(500).json({ ok: false, error: 'OTP benar, tapi gagal menyimpan status. Coba lagi.' });
    }
    return res.status(200).json({ ok: true });
  }

  return res.status(400).json({ ok: false, error: 'Action tidak dikenali. Gunakan ?action=send, ?action=verify, ?action=register, ?action=gsend, atau ?action=gverify' });
}
