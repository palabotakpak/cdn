// Vercel Serverless Function - gabungan beberapa proxy ke API NexaDev, dibedakan
// lewat query param ?tool=, supaya jumlah total Serverless Function tetap di
// bawah limit 12 (Vercel Hobby plan).
//
// Routing:
//   GET /api/rch?tool=react&url=...&reaction=...
//       -> (perilaku lama, default kalau ?tool= tidak dikirim) react ke postingan
//          channel WhatsApp. Butuh env NEXADEV_KEY, proxy ke api.nexadev.my.id.
//
//   GET /api/rch?tool=vote&url=...&pesan=...
//       -> (KHUSUS PREMIUM/OWNER, dicek di server) Vote/polling otomatis ke link apapun (polling, voting kontes, dll).
//          pesan opsional (catatan/isian form kalau pollingnya minta nama/komentar).
//          Pakai env NEXADEV_KEY yang sama, proxy ke api.nexadev.my.id/api/vote/.
//
//   GET /api/rch?tool=wmp2&text=baris1|baris2|baris3
//       -> WA Story Quote Maker. text dipisah "|" per baris oleh si API NexaDev.
//
//   GET /api/rch?tool=fakecall&ppurl=<url foto>&name=<nama>&duration=<detik>
//       -> Fake Call WA Maker (gambar layar panggilan masuk WhatsApp palsu).
//          ppurl wajib link gambar publik (pakai tool "Gambar ke URL" kalau
//          fotonya masih di galeri HP).
//
//   GET /api/rch?tool=qcwa&usn=<nama pengirim>&phone=<nomor>&pp=<url foto>&text=<isi>&mode=light|dark&tag=<label>&img=<url gambar opsional>
//       -> Quote Chat WA Maker (gambar bubble chat WhatsApp palsu).
//
// 3 tool baru (wmp2/fakecall/qcwa) proxy ke apii.nexadev.my.id, endpoint publik
// NexaDev yang tidak butuh API key.
//
// Semua tool diproteksi dengan cara yang SAMA seperti sebelumnya:
// - Cek header Origin/Referer harus dari domain sendiri (ALLOWED_ORIGIN).
// - Blokir User-Agent bot/scraper/HTTP client umum.
// - Rate limit kasar per IP (in-memory, reset tiap cold start).
// - Wajib login (Google atau email/password, ID token diverifikasi server).
// - Captcha wajib untuk role 'free' (lihat api/_captcha.js).
// - Limit harian per akun lewat Firestore (role free/premium, owner unlimited).

import { verifyToken, consumeMathToken } from './_captcha.js';
import { publicReact, publicAmprem } from './_apikey.js';
import { getRoleFromRequest, LIMITS, reserveUsage, refundUsage, explainError, logFeature } from './_firebaseAdmin.js';
import { maintenanceBlock, getAdminServices } from './_firebaseAdmin.js';

const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '';
const BOT_UA_RE = /(curl|wget|python-requests|python-urllib|scrapy|axios\/|node-fetch|go-http-client|libwww-perl|httpclient|aiohttp|okhttp|postman|insomnia|headlesschrome|phantomjs|puppeteer|playwright|bot|crawler|spider|scraper)/i;

const RATE_LIMIT_MAX = 20;       // request
const RATE_LIMIT_WINDOW_MS = 60 * 1000; // per menit, per IP
const rateBucket = new Map();

const WA_MAKER_BASE = 'https://apii.nexadev.my.id';
const URL_RE = /^https?:\/\/.+/i;

function getClientIp(req) {
  const fwd = req.headers['x-forwarded-for'];
  if (fwd) return String(fwd).split(',')[0].trim();
  return req.socket?.remoteAddress || 'unknown';
}

function isRateLimited(ip) {
  const now = Date.now();
  const entry = rateBucket.get(ip);
  if (!entry || now - entry.start > RATE_LIMIT_WINDOW_MS) {
    rateBucket.set(ip, { start: now, count: 1 });
    return false;
  }
  entry.count += 1;
  return entry.count > RATE_LIMIT_MAX;
}

// Validasi + susun query param tiap tool maker baru. Semua pesan error dalam
// Bahasa Indonesia supaya langsung bisa ditampilkan ke user di frontend.
const MAKER_TOOLS = {
  wmp2: {
    label: 'WA Story Quote Maker',
    build(q) {
      const text = String(q.text || '').trim();
      if (!text) return { error: 'Parameter text wajib diisi.' };
      if (text.length > 300) return { error: 'Teks kepanjangan, maksimal 300 karakter.' };
      return { params: { text } };
    }
  },
  fakecall: {
    label: 'Fake Call WA Maker',
    build(q) {
      const ppurl = String(q.ppurl || '').trim();
      const name = String(q.name || '').trim();
      const duration = String(q.duration || '').trim();
      if (!URL_RE.test(ppurl)) return { error: 'Link foto profil (ppurl) harus URL gambar yang valid (upload dulu lewat tool Gambar ke URL).' };
      if (!name) return { error: 'Parameter name wajib diisi.' };
      if (name.length > 30) return { error: 'Nama kepanjangan, maksimal 30 karakter.' };
      const durNum = Number(duration);
      if (!duration || !Number.isFinite(durNum) || durNum <= 0 || durNum > 3600) {
        return { error: 'Parameter duration harus angka detik (1-3600).' };
      }
      return { params: { ppurl, name, duration: String(durNum) } };
    }
  },
  qcwa: {
    label: 'Quote Chat WA Maker',
    build(q) {
      const usn = String(q.usn || '').trim();
      const phone = String(q.phone || '').trim();
      const pp = String(q.pp || '').trim();
      const text = String(q.text || '').trim();
      const mode = String(q.mode || 'light').trim().toLowerCase();
      const tag = String(q.tag || '').trim();
      const img = String(q.img || '').trim();

      if (!usn) return { error: 'Parameter usn (nama pengirim) wajib diisi.' };
      if (usn.length > 30) return { error: 'Nama pengirim kepanjangan, maksimal 30 karakter.' };
      if (!/^\d{8,15}$/.test(phone)) return { error: 'Parameter phone harus nomor WA valid: angka saja, 8-15 digit, pakai kode negara tanpa tanda +.' };
      if (!URL_RE.test(pp)) return { error: 'Link foto profil (pp) harus URL gambar yang valid (upload dulu lewat tool Gambar ke URL).' };
      if (!text) return { error: 'Parameter text wajib diisi.' };
      if (text.length > 200) return { error: 'Teks kepanjangan, maksimal 200 karakter.' };
      if (!['light', 'dark'].includes(mode)) return { error: 'Parameter mode harus "light" atau "dark".' };

      const params = { usn, phone, pp, text, mode };
      if (tag) params.tag = tag.slice(0, 30);
      if (img && URL_RE.test(img)) params.img = img;
      return { params };
    }
  }
};

export default async function handler(req, res) {
  // REST API publik pakai API key (khusus premium) — /api/v1/rch di-rewrite ke sini (vercel.json). Tanpa login Firebase & tanpa cek UA.
  if (req.query && req.query.tool === 'apirch') return publicReact(req, res);
  // REST API publik AM Premium — /api/v1/amprem di-rewrite ke sini (vercel.json). Tanpa login Firebase & tanpa cek UA.
  if (req.query && req.query.tool === 'apiamprem') return publicAmprem(req, res);

  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // --- Anti-scraping checks (sama seperti sebelumnya) ---
  const ua = req.headers['user-agent'] || '';
  if (!ua || BOT_UA_RE.test(ua)) {
    return res.status(403).json({ error: 'Akses ditolak' });
  }
  if (ALLOWED_ORIGIN) {
    const origin = req.headers['origin'] || req.headers['referer'] || '';
    if (!origin.startsWith(ALLOWED_ORIGIN)) {
      return res.status(403).json({ error: 'Akses ditolak' });
    }
  }
  const ip = getClientIp(req);
  if (isRateLimited(ip)) {
    return res.status(429).json({ error: 'Terlalu banyak permintaan, coba lagi sebentar' });
  }
  // --- end anti-scraping checks ---

  const toolName = String((req.query && req.query.tool) || 'react').toLowerCase();

  // Role dicek ulang di server (bukan percaya klaim dari frontend).
  const { role, uid, provider, error: authError, dbError } = await getRoleFromRequest(req);
  if (!uid) {
    return res.status(401).json({ error: authError ? 'Verifikasi login gagal: ' + authError : 'Login dulu.' });
  }
  if (dbError) {
    return res.status(500).json({ error: dbError });
  }
  if (provider !== 'google.com' && provider !== 'password') {
    return res.status(401).json({ error: 'Metode login tidak didukung.' });
  }

  { // mode maintenance (diatur dari panel admin; OWNER tetap bisa akses)
    const mKey = (toolName === 'react' ? 'zeereact' : toolName === 'vote' ? 'vote' : MAKER_TOOLS[toolName] ? 'wamaker' : null);
    const mb = mKey ? await maintenanceBlock(mKey, role) : null;
    if (mb) return res.status(503).json(mb);
  }

  const unlimited = role === 'premium' || role === 'owner';

  // Vote Polling khusus PREMIUM/OWNER (dicek di server, bukan cuma disembunyiin di UI).
  if (toolName === 'vote' && !unlimited) {
    return res.status(403).json({ error: 'Vote Polling khusus PREMIUM/OWNER. Upgrade dulu lewat fitur AM Premium.' });
  }
  const { captchaToken, captchaAnswer } = req.query;
  if (!unlimited) {
    const captchaCheck = verifyToken(captchaToken, captchaAnswer);
    if (!captchaCheck.ok) {
      return res.status(403).json({ error: 'Verifikasi captcha gagal, coba lagi', reason: captchaCheck.reason });
    }
    const adm0 = getAdminServices();
    if (adm0) {
      const usedErr = await consumeMathToken(adm0, captchaToken);
      if (usedErr) return res.status(403).json({ error: usedErr, reason: 'used' });
    }
  }

  if (toolName === 'react' || toolName === 'vote' || MAKER_TOOLS[toolName]) await logFeature(uid, toolName);

  // Limit harian per akun (server-side, Firestore). Owner = unlimited.
  let reserved = null;
  if (role !== 'owner') {
    const limit = LIMITS[role] ?? LIMITS.free;
    try {
      const r = await reserveUsage(uid, limit);
      if (!r.ok) {
        return res.status(429).json({
          error: 'Limit harian habis. Reset otomatis jam 00:00 WIB.',
          _usage: { count: r.count, limit }
        });
      }
      reserved = r;
    } catch (e) {
      return res.status(500).json({ error: 'Gagal mengecek limit harian: ' + explainError(e) });
    }
  }

  const usageOut = (failed) => reserved
    ? { count: Math.max(0, reserved.count - (failed ? 1 : 0)), limit: reserved.limit }
    : { count: 0, limit: null };

  const fail = async (status, body) => {
    if (reserved) { try { await refundUsage(uid); } catch { /* best-effort */ } }
    return res.status(status).json({ ...body, _usage: usageOut(true) });
  };

  // ---------- Tool lama: react ke channel WhatsApp ----------
  if (toolName === 'react') {
    const apiKey = process.env.NEXADEV_KEY;
    if (!apiKey) {
      return fail(500, { error: 'NEXADEV_KEY belum diset di environment variables Vercel' });
    }

    const { url, reaction } = req.query;
    if (!url || !reaction) {
      return fail(400, { error: 'Parameter url dan reaction wajib diisi' });
    }

    const CHANNEL_RE = /^https?:\/\/(www\.)?whatsapp\.com\/channel\/[A-Za-z0-9_-]+\/\d+/i;
    if (!CHANNEL_RE.test(url)) {
      return fail(400, { error: 'Link bukan link postingan saluran WhatsApp yang valid' });
    }
    if (String(reaction).length > 16) {
      return fail(400, { error: 'Reaksi kepanjangan, pakai emoji saja' });
    }

    try {
      const apiUrl = `https://api.nexadev.my.id/api/rch?key=${encodeURIComponent(apiKey)}&url=${encodeURIComponent(url)}&reaction=${encodeURIComponent(reaction)}`;

      // Timeout per percobaan 12 detik + retry 1x kalau upstream 5xx/timeout/network error,
      // supaya gangguan sementara di NexaDev gak langsung bikin user gagal & gak nge-hang server kita.
      let upstream, text;
      let lastErr = null;
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          upstream = await fetch(apiUrl, {
            method: 'GET',
            headers: { Accept: 'application/json' },
            signal: AbortSignal.timeout(12000)
          });
          if (upstream.status >= 500 && attempt === 0) { lastErr = new Error('upstream ' + upstream.status); continue; }
          text = await upstream.text();
          lastErr = null;
          break;
        } catch (e) {
          lastErr = e;
          if (attempt === 0) continue;
        }
      }
      if (lastErr) throw lastErr;

      let data;
      try { data = JSON.parse(text); } catch { data = { raw: text }; }
      if (!data || typeof data !== 'object' || Array.isArray(data)) data = { data };

      const failed = !upstream.ok ||
        data.status === false || data.success === false || data.ok === false ||
        ['error', 'failed', 'fail'].includes(String(data.status).toLowerCase()) ||
        !!data.error;

      if (failed && reserved) {
        try { await refundUsage(uid); } catch { /* best-effort */ }
      }
      // Rebrand: upstream ngasih "author": "NexaDev" di field result, ganti jadi KUREZA.
      if (data.result && typeof data.result === 'object' && data.result.author) {
        data.result.author = 'KUREZA';
      }
      return res.status(upstream.ok ? 200 : upstream.status).json({ ...data, _usage: usageOut(failed) });
    } catch (e) {
      const timeoutMsg = e && e.name === 'TimeoutError' ? 'Server react terlalu lama merespons, coba lagi.' : 'Gagal menghubungi server react, coba lagi.';
      return fail(502, { error: timeoutMsg });
    }
  }

  // ---------- Tool baru: vote/polling otomatis (proxy ke NexaDev) ----------
  // Khusus PREMIUM/OWNER. Kalau server NexaDev error (mis. HTTP 525 = SSL handshake
  // antara Cloudflare & server mereka gagal), dicoba ulang + coba alamat cadangan,
  // dan pesan errornya dijelasin ke user. Jatah harian selalu dikembalikan kalau gagal.
  // Alamat bisa di-override lewat env NEXADEV_VOTE_URL (dipisah koma kalau lebih dari satu).
  if (toolName === 'vote') {
    const apiKey = process.env.NEXADEV_KEY;
    if (!apiKey) {
      return fail(500, { error: 'NEXADEV_KEY belum diset di environment variables Vercel' });
    }

    const { url, pesan } = req.query;
    if (!url) {
      return fail(400, { error: 'Parameter url wajib diisi' });
    }
    if (!URL_RE.test(url)) {
      return fail(400, { error: 'Link polling/voting tidak valid, harus diawali http:// atau https://' });
    }
    const note = String(pesan || '').trim();
    if (note.length > 200) {
      return fail(400, { error: 'Pesan/catatan kepanjangan, maksimal 200 karakter' });
    }

    const bases = (process.env.NEXADEV_VOTE_URL
      ? process.env.NEXADEV_VOTE_URL.split(',').map((x) => x.trim()).filter(Boolean)
      : ['https://api.nexadev.my.id/api/vote/', 'https://apii.nexadev.my.id/api/vote/']);
    const qs = `key=${encodeURIComponent(apiKey)}&url=${encodeURIComponent(url)}&pesan=${encodeURIComponent(note)}`;

    let lastStatus = 0;
    let lastDetail = '';
    for (const base of bases) {
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          const upstream = await fetch(`${base}${base.includes('?') ? '&' : '?'}${qs}`, {
            method: 'GET',
            headers: { Accept: 'application/json' },
            signal: AbortSignal.timeout(20000)
          });
          const text = await upstream.text();
          let data;
          try { data = JSON.parse(text); } catch { data = null; }

          // Server upstream error (5xx, termasuk kode Cloudflare 520-527) atau balasan bukan JSON -> coba lagi / alamat lain.
          if (upstream.status >= 500 || (!data && !upstream.ok)) {
            lastStatus = upstream.status;
            lastDetail = '';
            continue;
          }
          if (!data || typeof data !== 'object' || Array.isArray(data)) data = { data: data ?? { raw: text.slice(0, 200) } };

          const failed = !upstream.ok ||
            data.status === false || data.success === false || data.ok === false ||
            ['error', 'failed', 'fail'].includes(String(data.status).toLowerCase()) ||
            !!data.error;

          if (failed && reserved) {
            try { await refundUsage(uid); } catch { /* best-effort */ }
          }
          return res.status(upstream.ok ? 200 : upstream.status).json({ ...data, _usage: usageOut(failed) });
        } catch (e) {
          lastStatus = 0;
          lastDetail = e && e.name === 'TimeoutError' ? 'timeout' : (e && e.message) || 'error';
        }
      }
    }

    const hint = lastStatus === 525 || lastStatus === 526 || lastStatus === 523 || lastStatus === 522 || lastStatus === 521 || lastStatus === 520
      ? ' (server penyedia API vote lagi bermasalah, bukan salah link kamu)'
      : '';
    return fail(502, {
      error: 'Server vote sedang gangguan' + (lastStatus ? ` (HTTP ${lastStatus})` : lastDetail ? ` (${lastDetail})` : '') + hint + '. Jatah kamu sudah dikembalikan, coba lagi beberapa menit lagi.'
    });
  }

  // ---------- Tool baru: wmp2 / fakecall / qcwa (proxy ke apii.nexadev.my.id) ----------
  const maker = MAKER_TOOLS[toolName];
  if (!maker) {
    return fail(400, { error: 'Parameter tool tidak dikenal.' });
  }

  const built = maker.build(req.query || {});
  if (built.error) {
    return fail(400, { error: built.error });
  }

  try {
    const qs = new URLSearchParams(built.params).toString();
    const apiUrl = `${WA_MAKER_BASE}/${toolName}?${qs}`;
    const upstream = await fetch(apiUrl, { method: 'GET', headers: { Accept: '*/*' } });
    const contentType = upstream.headers.get('content-type') || '';

    if (!upstream.ok) {
      const errText = await upstream.text().catch(() => '');
      return fail(502, {
        error: `Gagal membuat ${maker.label} (HTTP ${upstream.status})` + (errText ? ': ' + errText.replace(/\s+/g, ' ').trim().slice(0, 200) : '')
      });
    }

    // Kebanyakan "maker" NexaDev balas gambar langsung (content-type image/*).
    if (contentType.startsWith('image/')) {
      const buf = Buffer.from(await upstream.arrayBuffer());
      const usage = usageOut(false);
      res.setHeader('Content-Type', contentType);
      res.setHeader('Cache-Control', 'no-store');
      res.setHeader('X-Usage-Count', String(usage.count));
      res.setHeader('X-Usage-Limit', String(usage.limit));
      return res.status(200).send(buf);
    }

    // Fallback kalau upstream balas JSON (mis. { status:true, url:'https://...hasil.jpg' })
    const text = await upstream.text();
    let data;
    try { data = JSON.parse(text); } catch { data = { raw: text }; }
    if (!data || typeof data !== 'object' || Array.isArray(data)) data = { data };

    const failed = data.status === false || data.success === false || data.ok === false || !!data.error;
    if (failed && reserved) {
      try { await refundUsage(uid); } catch { /* best-effort */ }
    }
    return res.status(200).json({ ...data, _usage: usageOut(failed) });
  } catch (e) {
    return fail(502, { error: `Gagal menghubungi API ${maker.label}: ` + e.message });
  }
}
