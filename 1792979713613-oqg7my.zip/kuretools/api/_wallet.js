// Saldo & Store (bukan Serverless Function sendiri, file berawalan "_" cuma helper).
// Dipanggil dari api/system.js (action=wallet) supaya jumlah function tetap di bawah limit 12 Vercel Hobby.
//
// Data (semua lewat Admin SDK, client Firestore dikunci total):
//   wallets/{uid}   -> { balance, bonus_usage, bonus_amprem_usage, bonus_smm }
//   deposits/{invoiceId} -> { uid, amount, fee, total, qrisImage, expiredAt, status, credited, createdAt, paidAt }
//   purchases/{auto}     -> { uid, item, label, price, createdAt }
//
// Payment gateway: SairiPedia (https://api.sairibot.my.id/docs), tanpa webhook, jadi status dicek manual/polling.
// Env: SAIRIPEDIA_API_KEY (wajib), SAIRIPEDIA_API_BASE (opsional).

import { getRoleFromRequest, prepareDb, getAdminServices, explainError, effectiveRoleData } from './_firebaseAdmin.js';
import { maintenanceBlock } from './_firebaseAdmin.js';

export const MIN_DEPOSIT = 1000;
const MAX_DEPOSIT = 1000000;
const MAX_PENDING = 3;
const DAY = 24 * 60 * 60 * 1000;

// ---- Anti-spam bikin invoice QRIS ----
const DEPOSIT_COOLDOWN_MS = 20 * 1000;     // jarak minimal antar bikin invoice / user (Firestore, akurat di semua instance)
const IP_LIMIT = 10;                        // maks 10 invoice / 10 menit / IP (per instance, best-effort, lapis tambahan)
const IP_WINDOW_MS = 10 * 60 * 1000;
const ipHits = new Map();
function ipLimited(ip) {
  const now = Date.now();
  const arr = (ipHits.get(ip) || []).filter((t) => now - t < IP_WINDOW_MS);
  if (arr.length >= IP_LIMIT) { ipHits.set(ip, arr); return true; }
  arr.push(now); ipHits.set(ip, arr);
  return false;
}

// ---- Katalog Store (ubah harga/jumlah di sini) ----
export const STORE_PREMIUM = {
  premium_1d:   { label: 'Premium 1 Hari',   price: 1000,  days: 1 },
  premium_7d:   { label: 'Premium 7 Hari',   price: 10000, days: 7 },
  premium_30d:  { label: 'Premium 30 Hari',  price: 20000, days: 30 },
  premium_perm: { label: 'Premium Permanen', price: 50000, days: null }
};
// field = nama field di wallets/{uid}; 'bonus_' + nama collection limit di _firebaseAdmin.js
export const STORE_LIMIT = {
  react_10:  { label: '+10 limit ZeeReact',          price: 1000, amount: 10, field: 'bonus_usage',        forRole: 'free' },
  react_50:  { label: '+50 limit ZeeReact',          price: 4000, amount: 50, field: 'bonus_usage',        forRole: 'free' },
  amprem_5:  { label: '+5 limit AM Premium',         price: 1000, amount: 5,  field: 'bonus_amprem_usage', forRole: 'free' },
  amprem_20: { label: '+20 limit AM Premium',        price: 3000, amount: 20, field: 'bonus_amprem_usage', forRole: 'free' },
  smm_1:     { label: '+1 jatah Suntik Sosmed',      price: 2000, amount: 1,  field: 'bonus_smm',          forRole: 'premium' },
  smm_5:     { label: '+5 jatah Suntik Sosmed',      price: 8000, amount: 5,  field: 'bonus_smm',          forRole: 'premium' }
};

const PAID = ['paid', 'success', 'settlement', 'completed'];

// Cari field gambar QRIS di mana pun posisinya dalam respons (top-level ATAU dibungkus di
// dalam data/result/invoice/payload, dst). Gateway kadang membungkus hasil beda dari contoh
// di dokumentasi, jadi dicari rekursif daripada cuma baca 1 posisi tetap.
function findImageLike(obj, depth = 0) {
  if (!obj || typeof obj !== 'object' || depth > 4) return '';
  for (const [k, v] of Object.entries(obj)) {
    if (typeof v === 'string' && /qris|qrcode|qr_image|qrimage/i.test(k) &&
        (/^https?:\/\//i.test(v) || /^data:image\//i.test(v))) {
      return v;
    }
  }
  for (const v of Object.values(obj)) {
    if (v && typeof v === 'object') {
      const found = findImageLike(v, depth + 1);
      if (found) return found;
    }
  }
  return '';
}
function findStringLike(obj, re, depth = 0) {
  if (!obj || typeof obj !== 'object' || depth > 4) return '';
  for (const [k, v] of Object.entries(obj)) {
    if (typeof v === 'string' && v && re.test(k)) return v;
    if (typeof v === 'number' && re.test(k)) return String(v);
  }
  for (const v of Object.values(obj)) {
    if (v && typeof v === 'object') {
      const found = findStringLike(v, re, depth + 1);
      if (found) return found;
    }
  }
  return '';
}
const DEAD = ['expired', 'cancelled', 'canceled', 'failed'];

function gatewayBase() { return (process.env.SAIRIPEDIA_API_BASE || 'https://api.sairibot.my.id').replace(/\/+$/, ''); }

async function gatewayGet(path, params) {
  const qs = new URLSearchParams({ apikey: process.env.SAIRIPEDIA_API_KEY, ...params }).toString();
  const r = await fetch(`${gatewayBase()}${path}?${qs}`, { headers: { Accept: 'application/json' }, signal: AbortSignal.timeout(20000) });
  let data = null;
  try { data = await r.json(); } catch { /* bukan JSON */ }
  return { ok: r.ok, status: r.status, data };
}

function readBody(req) {
  const b = req.body;
  if (b && typeof b === 'object') return b;
  try { return JSON.parse(b || '{}'); } catch { return {}; }
}

const num = (v) => (typeof v === 'number' && Number.isFinite(v) ? v : 0);

// Riwayat mutasi saldo (semua kejadian yang nambah/motong saldo, dalam satu log urut waktu),
// dipakai juga dari api/system.js (Suntik Sosmed) lewat import biar satu ledger buat semua.
// amount: + buat nambah saldo, - buat motong saldo.
export async function logTransaction(db, uid, { type, amount, label }) {
  try {
    await db.collection('wallet_transactions').add({
      uid, type, amount: num(amount), label: String(label || ''), createdAt: Date.now()
    });
  } catch { /* best-effort, jangan sampai gagal log bikin transaksi utama ikut gagal */ }
}

export async function handleWallet(req, res) {
  const { role, uid, error: authError } = await getRoleFromRequest(req);
  if (!uid) return res.status(401).json({ error: authError || 'Belum login.' });

  try { await prepareDb(); } catch { /* getAdminServices yang menentukan */ }
  const admin = getAdminServices();
  if (!admin) return res.status(500).json({ error: 'Firebase Admin belum dikonfigurasi di server.' });
  const db = admin.db;
  const wref = db.collection('wallets').doc(uid);
  const uref = db.collection('users').doc(uid);

  // ───────────────────────── GET: ringkasan ─────────────────────────
  if (req.method === 'GET') {
    try {
      const [wsnap, usnap, dsnap, tsnap] = await Promise.all([
        wref.get(), uref.get(), db.collection('deposits').where('uid', '==', uid).limit(50).get(),
        db.collection('wallet_transactions').where('uid', '==', uid).limit(50).get()
      ]);
      const w = wsnap.exists ? wsnap.data() : {};
      const eff = effectiveRoleData(usnap.exists ? usnap.data() : {});
      const deposits = dsnap.docs.map(d => d.data()).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0)).slice(0, 10);
      // Riwayat mutasi saldo (deposit, belanja Store, Suntik Sosmed) digabung satu daftar urut waktu terbaru.
      const transactions = tsnap.docs.map(d => d.data())
        .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0))
        .slice(0, 30)
        .map(t => ({ type: t.type, amount: t.amount, label: t.label, createdAt: t.createdAt }));
      const cutoff = Date.now() - 60 * 60 * 1000;
      const pend = deposits.find(d => d.status === 'pending' && (d.createdAt || 0) > cutoff);
      deposits.forEach(d => { if (d.status === 'pending' && (d.createdAt || 0) <= cutoff) d.status = 'expired'; });
      return res.status(200).json({
        balance: num(w.balance),
        bonus: { react: num(w.bonus_usage), amprem: num(w.bonus_amprem_usage), smm: num(w.bonus_smm) },
        role: eff.role,
        roleExpiresAt: eff.roleExpiresAt,
        minDeposit: MIN_DEPOSIT,
        store: {
          premium: Object.entries(STORE_PREMIUM).map(([id, v]) => ({ id, label: v.label, price: v.price })),
          limits: Object.entries(STORE_LIMIT).map(([id, v]) => ({ id, label: v.label, price: v.price, forRole: v.forRole }))
        },
        pending: pend ? { invoiceId: pend.invoiceId, amount: pend.amount, fee: pend.fee, total: pend.total, qrisImage: pend.qrisImage, expiredAt: pend.expiredAt } : null,
        deposits: deposits.map(d => ({ invoiceId: d.invoiceId, amount: d.amount, total: d.total, status: d.status, createdAt: d.createdAt })),
        transactions
      });
    } catch (e) {
      return res.status(500).json({ error: 'Gagal memuat saldo: ' + explainError(e) });
    }
  }

  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const body = readBody(req);
  const action = String(body.action || '');

  // Mode maintenance: tahan deposit baru & belanja. 'check' dan 'cancel' sengaja tetap jalan supaya
  // deposit yang sudah terlanjur dibayar tetap bisa dikreditkan.
  if (action === 'deposit' || action === 'buy') {
    const mb = await maintenanceBlock('wallet', role);
    if (mb) return res.status(503).json(mb);
  }

  // ───────────────────────── Batalkan invoice pending ─────────────────────────
  if (action === 'cancel') {
    const invoiceId = String(body.invoiceId || '');
    if (!invoiceId || invoiceId.includes('/')) return res.status(400).json({ error: 'invoiceId tidak valid.' });
    try {
      const dref = db.collection('deposits').doc(invoiceId);
      const result = await db.runTransaction(async (t) => {
        const snap = await t.get(dref);
        if (!snap.exists || snap.data().uid !== uid) return { err: 'Invoice tidak ditemukan.' };
        const dep = snap.data();
        if (dep.credited) return { err: 'Invoice ini sudah lunas, tidak bisa dibatalkan.' };
        if (dep.status !== 'pending') return { err: 'Invoice ini sudah ' + dep.status + ', tidak perlu dibatalkan.' };
        t.update(dref, { status: 'cancelled', cancelledAt: Date.now() });
        return { ok: true };
      });
      if (result.err) return res.status(400).json({ error: result.err });
      return res.status(200).json({ ok: true, status: 'cancelled' });
    } catch (e) {
      return res.status(500).json({ error: 'Gagal membatalkan invoice: ' + explainError(e) });
    }
  }

  // ───────────────────────── Buat invoice QRIS ─────────────────────────
  if (action === 'deposit') {
    const amount = Math.floor(Number(body.amount));
    if (!Number.isFinite(amount) || amount < MIN_DEPOSIT) {
      return res.status(400).json({ error: `Minimal deposit Rp${MIN_DEPOSIT.toLocaleString('id-ID')}.` });
    }
    if (amount > MAX_DEPOSIT) {
      return res.status(400).json({ error: `Maksimal deposit Rp${MAX_DEPOSIT.toLocaleString('id-ID')} per transaksi.` });
    }
    if (!process.env.SAIRIPEDIA_API_KEY) {
      return res.status(500).json({ error: 'SAIRIPEDIA_API_KEY belum diset di Environment Variable Vercel.' });
    }
    const ip = String(req.headers['x-forwarded-for'] || req.socket?.remoteAddress || '').split(',')[0].trim();
    if (ipLimited(ip)) {
      return res.status(429).json({ error: 'Terlalu banyak percobaan bikin invoice dari koneksi ini, coba lagi beberapa menit lagi.' });
    }
    try {
      // Cooldown per akun: cegah spam klik BUAT QRIS beruntun (akurat lintas instance, beda dari limit IP di atas).
      const cdRef = db.collection('deposit_cooldown').doc(uid);
      const cdSnap = await cdRef.get();
      const lastAt = cdSnap.exists ? (cdSnap.data().lastAt || 0) : 0;
      if (Date.now() - lastAt < DEPOSIT_COOLDOWN_MS) {
        const wait = Math.ceil((DEPOSIT_COOLDOWN_MS - (Date.now() - lastAt)) / 1000);
        return res.status(429).json({ error: `Tunggu ${wait} detik sebelum bikin invoice baru.` });
      }

      // Batasi invoice menggantung supaya gak bisa spam bikin QRIS.
      const cutoff = Date.now() - 60 * 60 * 1000;
      const ps = await db.collection('deposits').where('uid', '==', uid).where('status', '==', 'pending').limit(20).get();
      const open = ps.docs.filter(d => (d.data().createdAt || 0) > cutoff).length;
      if (open >= MAX_PENDING) {
        return res.status(429).json({ error: `Kamu masih punya invoice yang belum dibayar (maks ${MAX_PENDING}). Batalkan salah satu, bayar, atau tunggu kedaluwarsa dulu.` });
      }
      await cdRef.set({ lastAt: Date.now() });

      const g = await gatewayGet('/api/invoice', { amount: String(amount) });
      const d = g.data;
      // Dicatat ke log Vercel (Project -> Logs) supaya field yang beda dari dokumentasi
      // ketahuan tanpa membongkar isinya ke user.
      console.log('[wallet] SairiPedia /api/invoice ->', g.status, JSON.stringify(d).slice(0, 500));
      if (!g.ok || !d || d.success !== true || !d.invoice_id) {
        return res.status(502).json({ error: 'Payment gateway menolak: ' + ((d && (d.error || d.message)) || ('HTTP ' + g.status)) });
      }
      const invoiceId = String(d.invoice_id);
      if (invoiceId.includes('/') || invoiceId.length > 200) {
        return res.status(502).json({ error: 'ID invoice dari gateway tidak valid.' });
      }
      const gwAmount = Number(findStringLike(d, /^amount$/i) || d.amount);
      if (Number.isFinite(gwAmount) && gwAmount !== amount) {
        return res.status(502).json({ error: 'Nominal invoice dari gateway tidak sesuai, dibatalkan.' });
      }
      // Dicari di mana pun posisinya di respons (lihat findImageLike), karena nama/posisi field
      // gambar QRIS kadang beda dari dokumentasi.
      let qris = findImageLike(d);
      if (qris.startsWith('//')) qris = 'https:' + qris;
      if (!qris) {
        console.log('[wallet] QRIS image TIDAK ditemukan di respons di atas. Invoice tetap dibuat (cek status via CEK STATUS PEMBAYARAN), tapi gambar gak bisa ditampilkan.');
        return res.status(502).json({ error: 'Invoice berhasil dibuat di gateway, tapi gambar QRIS tidak ditemukan di balasannya. Cek Vercel Logs (baris [wallet]) untuk lihat struktur balasan asli.' });
      }
      const rec = {
        invoiceId, uid, amount,
        fee: num(Number(d.fee)), total: num(Number(d.total)) || amount,
        qrisImage: qris, expiredAt: String(d.expired_at || ''),
        status: 'pending', credited: false, createdAt: Date.now()
      };
      await db.collection('deposits').doc(invoiceId).set(rec);
      return res.status(200).json({ invoiceId, amount: rec.amount, fee: rec.fee, total: rec.total, qrisImage: rec.qrisImage, expiredAt: rec.expiredAt });
    } catch (e) {
      return res.status(500).json({ error: 'Gagal membuat invoice: ' + explainError(e) });
    }
  }

  // ───────────────────────── Cek status & kreditkan saldo ─────────────────────────
  if (action === 'check') {
    const invoiceId = String(body.invoiceId || '');
    if (!invoiceId || invoiceId.includes('/')) return res.status(400).json({ error: 'invoiceId tidak valid.' });
    if (!process.env.SAIRIPEDIA_API_KEY) {
      return res.status(500).json({ error: 'SAIRIPEDIA_API_KEY belum diset di Environment Variable Vercel.' });
    }
    try {
      const dref = db.collection('deposits').doc(invoiceId);
      const snap = await dref.get();
      if (!snap.exists || snap.data().uid !== uid) return res.status(404).json({ error: 'Invoice tidak ditemukan.' });
      const dep = snap.data();
      if (dep.credited) {
        const w = await wref.get();
        return res.status(200).json({ status: 'paid', credited: true, balance: num(w.exists ? w.data().balance : 0) });
      }

      const g = await gatewayGet('/api/invoice/status', { invoice_id: invoiceId });
      const d = g.data;
      if (!g.ok || !d || d.error) {
        return res.status(502).json({ error: 'Gagal cek status ke payment gateway: ' + ((d && (d.error || d.message)) || ('HTTP ' + g.status)) });
      }
      const st = String(d.status || '').toLowerCase();

      if (PAID.includes(st)) {
        // Pastikan data gateway cocok dengan invoice kita sebelum saldo dikreditkan.
        if ((d.invoice_id && String(d.invoice_id) !== invoiceId) || (d.amount != null && Number(d.amount) !== dep.amount)) {
          return res.status(502).json({ error: 'Data pembayaran tidak cocok dengan invoice. Hubungi admin.' });
        }
        const out = await db.runTransaction(async (t) => {
          const ds = await t.get(dref);
          const ws = await t.get(wref);
          if (ds.data().credited) return { balance: num(ws.exists ? ws.data().balance : 0) };
          const bal = num(ws.exists ? ws.data().balance : 0) + ds.data().amount;
          t.set(wref, { balance: bal }, { merge: true });
          t.update(dref, { status: 'paid', credited: true, paidAt: Date.now() });
          return { balance: bal, newly: true };
        });
        if (out.newly) await logTransaction(db, uid, { type: 'deposit', amount: dep.amount, label: 'Isi saldo via QRIS' });
        return res.status(200).json({ status: 'paid', credited: true, balance: out.balance, newly: !!out.newly });
      }
      if (DEAD.includes(st)) {
        await dref.update({ status: 'expired' });
        return res.status(200).json({ status: 'expired' });
      }
      return res.status(200).json({ status: 'pending' });
    } catch (e) {
      return res.status(500).json({ error: 'Gagal cek pembayaran: ' + explainError(e) });
    }
  }

  // ───────────────────────── Beli item Store ─────────────────────────
  if (action === 'buy') {
    const id = String(body.item || '');
    const prem = STORE_PREMIUM[id];
    const lim = STORE_LIMIT[id];
    const item = prem || lim;
    if (!item) return res.status(400).json({ error: 'Item tidak dikenal.' });

    try {
      const result = await db.runTransaction(async (t) => {
        const ws = await t.get(wref);
        const us = await t.get(uref);
        const bal = num(ws.exists ? ws.data().balance : 0);
        const eff = effectiveRoleData(us.exists ? us.data() : {});

        if (eff.role === 'owner') return { err: 'Akun OWNER sudah unlimited, gak perlu beli.' };
        if (prem && eff.role === 'premium' && eff.roleExpiresAt === null) return { err: 'Kamu sudah PREMIUM PERMANEN.' };
        if (lim && lim.forRole === 'free' && eff.role !== 'free') return { err: 'Akun PREMIUM sudah unlimited di fitur ini.' };
        if (lim && lim.forRole === 'premium' && eff.role !== 'premium') return { err: 'Jatah Suntik Sosmed cuma buat akun PREMIUM. Beli Premium dulu.' };
        if (bal < item.price) return { err: `Saldo kurang. Butuh Rp${item.price.toLocaleString('id-ID')}, saldo kamu Rp${bal.toLocaleString('id-ID')}.` };

        const wUpdate = { balance: bal - item.price };
        let roleExpiresAt;
        if (prem) {
          // Perpanjang dari sisa masa aktif kalau masih premium.
          const base = eff.role === 'premium' && eff.roleExpiresAt ? Math.max(Date.now(), eff.roleExpiresAt) : Date.now();
          roleExpiresAt = prem.days === null ? null : base + prem.days * DAY;
          t.set(uref, { role: 'premium', roleExpiresAt }, { merge: true });
        } else {
          wUpdate[lim.field] = num(ws.exists ? ws.data()[lim.field] : 0) + lim.amount;
        }
        t.set(wref, wUpdate, { merge: true });
        t.set(db.collection('purchases').doc(), { uid, item: id, label: item.label, price: item.price, createdAt: Date.now() });
        return { ok: true, balance: bal - item.price, roleExpiresAt, premium: !!prem };
      });
      if (result.err) return res.status(400).json({ error: result.err });
      await logTransaction(db, uid, { type: 'purchase', amount: -item.price, label: 'Beli: ' + item.label });
      return res.status(200).json({ ok: true, balance: result.balance, premium: result.premium, roleExpiresAt: result.roleExpiresAt ?? null });
    } catch (e) {
      return res.status(500).json({ error: 'Gagal memproses pembelian: ' + explainError(e) });
    }
  }

  return res.status(400).json({ error: 'Action tidak dikenali.' });
}
