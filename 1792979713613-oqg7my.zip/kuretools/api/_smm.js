// Helper submit order Suntik Sosmed ke panel FAYUPEDIA.
// Prefix "_" -> bukan Serverless Function sendiri (lihat catatan di _wallet.js),
// cuma modul yang di-import dari api/system.js dan api/admin.js supaya logic
// kirim-ke-panelnya gak dobel di dua tempat dan perilakunya konsisten.

const SMM_API_BASE = process.env.FAYUPEDIA_API_BASE || 'https://fayupedia.id/api';
const SMM_ORDER_URL = process.env.FAYUPEDIA_ORDER_URL || (SMM_API_BASE + '/order');

// Kirim 1 order ke panel. Dipanggil dari:
//  - system.js: OTOMATIS, langsung setelah saldo user FREE dipotong (gak nunggu admin).
//  - admin.js : saat admin klik ACC buat order PREMIUM/OWNER (jatah gratis mingguan).
export async function submitSmmOrder({ serviceId, link, quantity }) {
  if (!process.env.FAYUPEDIA_API_KEY || !process.env.FAYUPEDIA_API_ID) {
    return { ok: false, error: 'FAYUPEDIA_API_KEY / FAYUPEDIA_API_ID belum diset di Environment Variable.' };
  }
  try {
    const params = new URLSearchParams({
      api_id: process.env.FAYUPEDIA_API_ID,
      api_key: process.env.FAYUPEDIA_API_KEY,
      service: String(serviceId),
      target: link,
      quantity: String(quantity)
    });
    const upstream = await fetch(SMM_ORDER_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: params.toString(),
      signal: AbortSignal.timeout(20000)
    });
    const data = await upstream.json().catch(() => null);
    if (!upstream.ok || !data || data.error || !data.order) {
      return { ok: false, error: 'Order ditolak panel: ' + (data && (data.error || data.message) || ('HTTP ' + upstream.status)) };
    }
    return { ok: true, orderId: data.order };
  } catch (e) {
    return { ok: false, error: 'Gagal menghubungi panel: ' + (e && e.message ? e.message : String(e)) };
  }
}
