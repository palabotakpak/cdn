// Vercel Serverless Function
// Generate soal captcha matematika sederhana + token yang ditandatangani (HMAC),
// sehingga server tidak perlu menyimpan state apa pun (stateless, gratis, tanpa DB).
//
// Simpan secret-nya di Vercel -> Project Settings -> Environment Variables
// Nama variable: CAPTCHA_SECRET (string acak, panjang bebas)

import crypto from 'crypto';

import { secretFor } from './_secrets.js';
const SECRET = secretFor('CAPTCHA_SECRET', 'captcha');
const TTL_MS = 5 * 60 * 1000; // soal berlaku 5 menit

function sign(payload) {
  return crypto.createHmac('sha256', SECRET).update(payload).digest('base64url');
}

export function makeToken(answer) {
  const payload = JSON.stringify({ a: String(answer), exp: Date.now() + TTL_MS });
  const payloadB64 = Buffer.from(payload).toString('base64url');
  const sig = sign(payloadB64);
  return payloadB64 + '.' + sig;
}

export function verifyToken(token, userAnswer) {
  if (!token || typeof token !== 'string' || !token.includes('.')) {
    return { ok: false, reason: 'malformed-token' };
  }
  const [payloadB64, sig] = token.split('.');
  const expectedSig = sign(payloadB64);

  const sigBuf = Buffer.from(sig || '');
  const expectedBuf = Buffer.from(expectedSig);
  if (sigBuf.length !== expectedBuf.length || !crypto.timingSafeEqual(sigBuf, expectedBuf)) {
    return { ok: false, reason: 'bad-signature' };
  }

  let payload;
  try {
    payload = JSON.parse(Buffer.from(payloadB64, 'base64url').toString('utf8'));
  } catch {
    return { ok: false, reason: 'bad-payload' };
  }

  if (!payload.exp || Date.now() > payload.exp) {
    return { ok: false, reason: 'expired' };
  }

  const normalizedUser = String(userAnswer ?? '').trim();
  const normalizedExpected = String(payload.a ?? '').trim();
  if (normalizedUser === '' || normalizedUser !== normalizedExpected) {
    return { ok: false, reason: 'wrong-answer' };
  }

  return { ok: true };
}

// ── Captcha GAMBAR (kunci acak, di-render sendiri jadi SVG, tanpa API luar) ──
// Kunci TIDAK pernah dikirim ke client: token cuma berisi id acak + exp + tanda tangan, dan kunci
// diturunkan di server dari HMAC(id). Gambar di-render langsung di server sebagai SVG (GET
// ?img=<token>) supaya tidak ada dependency ke API pihak ketiga yang bisa down/berubah/dihapus.
//   GET /api/captcha?type=img   -> { token, img }
//   GET /api/captcha?img=<tok>  -> image/svg+xml
const IMG_TTL_MS = 5 * 60 * 1000;
const KEY_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // tanpa I/O/0/1 biar gak ambigu
const KEY_LEN = 5;

function keyFromId(id) {
  const h = crypto.createHmac('sha256', SECRET).update('imgkey:' + id).digest();
  let k = '';
  for (let i = 0; i < KEY_LEN; i++) k += KEY_ALPHABET[h[i] % KEY_ALPHABET.length];
  return k;
}

export function makeImgToken() {
  const id = crypto.randomBytes(9).toString('base64url');
  const exp = Date.now() + IMG_TTL_MS;
  return id + '.' + exp + '.' + sign('img:' + id + '.' + exp);
}

function parseImgToken(token) {
  if (typeof token !== 'string') return null;
  const [id, expStr, sig] = token.split('.');
  if (!id || !expStr || !sig) return null;
  const expected = sign('img:' + id + '.' + expStr);
  const a = Buffer.from(sig), b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  const exp = Number(expStr);
  if (!exp || Date.now() > exp) return null;
  return { id, exp };
}

// Cek jawaban (tidak peka huruf besar/kecil). Return { ok, id, exp } — id dipakai pemanggil untuk "sekali pakai".
export function verifyImgCaptcha(token, answer) {
  const t = parseImgToken(token);
  if (!t) return { ok: false, reason: 'expired-or-invalid' };
  const given = String(answer ?? '').trim().toUpperCase();
  const want = keyFromId(t.id);
  const a = Buffer.from(given), b = Buffer.from(want);
  if (!given || a.length !== b.length || !crypto.timingSafeEqual(a, b)) return { ok: false, reason: 'wrong-answer' };
  return { ok: true, id: t.id, exp: t.exp };
}

const imgHits = new Map(); // anti-spam ringan (per instance): maks 40 gambar / 10 menit / IP
function imgLimited(ip) {
  const now = Date.now();
  const arr = (imgHits.get(ip) || []).filter(t => now - t < 10 * 60 * 1000);
  if (arr.length >= 40) { imgHits.set(ip, arr); return true; }
  arr.push(now); imgHits.set(ip, arr);
  return false;
}

// PRNG deterministik dari seed (biar noise/rotasi tiap huruf konsisten per id, tapi
// tetap acak antar-captcha). Tidak perlu kripto kuat di sini, cuma dekorasi visual.
function seededRand(seedBuf, salt) {
  let h = crypto.createHash('sha256').update(seedBuf).update(String(salt)).digest();
  let i = 0;
  return function () {
    if (i >= h.length) { h = crypto.createHash('sha256').update(h).digest(); i = 0; }
    return h[i++] / 255;
  };
}

function renderCaptchaSvg(id, key) {
  const W = 220, H = 80;
  const seed = Buffer.from(id, 'utf8');
  const rnd = seededRand(seed, 'v1');
  const colors = ['#2d2a4a', '#1f6f5c', '#8a3b2d', '#3b5488', '#6a3b78'];

  let svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">`;
  svg += `<rect width="${W}" height="${H}" fill="#f0f0f0"/>`;

  // garis-garis pengganggu
  for (let i = 0; i < 6; i++) {
    const x1 = rnd() * W, y1 = rnd() * H, x2 = rnd() * W, y2 = rnd() * H;
    const c = colors[Math.floor(rnd() * colors.length)];
    svg += `<path d="M${x1.toFixed(1)},${y1.toFixed(1)} L${x2.toFixed(1)},${y2.toFixed(1)}" stroke="${c}" stroke-width="1.5" opacity="0.35" fill="none"/>`;
  }

  // titik-titik noise
  for (let i = 0; i < 40; i++) {
    const cx = rnd() * W, cy = rnd() * H;
    const c = colors[Math.floor(rnd() * colors.length)];
    svg += `<circle cx="${cx.toFixed(1)}" cy="${cy.toFixed(1)}" r="1" fill="${c}" opacity="0.4"/>`;
  }

  // huruf-huruf kunci: posisi + rotasi acak
  const n = key.length;
  const slot = W / n;
  for (let i = 0; i < n; i++) {
    const ch = key[i];
    const cx = slot * i + slot / 2 + (rnd() - 0.5) * 8;
    const cy = H / 2 + (rnd() - 0.5) * 14;
    const rot = (rnd() - 0.5) * 50;
    const size = 30 + Math.floor(rnd() * 8);
    const c = colors[Math.floor(rnd() * colors.length)];
    svg += `<text x="${cx.toFixed(1)}" y="${cy.toFixed(1)}" transform="rotate(${rot.toFixed(1)} ${cx.toFixed(1)} ${cy.toFixed(1)})" font-family="Arial,Helvetica,sans-serif" font-weight="800" font-size="${size}" fill="${c}" text-anchor="middle" dominant-baseline="middle">${ch}</text>`;
  }

  svg += `<rect x="1" y="1" width="${W - 2}" height="${H - 2}" fill="none" stroke="#d0d0d0" stroke-width="2"/>`;
  svg += `</svg>`;
  return svg;
}

function serveImage(req, res) {
  const t = parseImgToken(req.query && req.query.img);
  if (!t) return res.status(400).json({ error: 'Captcha kedaluwarsa, muat ulang.' });
  try {
    const key = keyFromId(t.id);
    const svg = renderCaptchaSvg(t.id, key);
    res.setHeader('Content-Type', 'image/svg+xml; charset=utf-8');
    return res.status(200).send(svg);
  } catch (e) {
    console.error('[captcha img]', e && e.message);
    return res.status(502).json({ error: 'Gambar captcha gagal dibuat, klik refresh.' });
  }
}

function randInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function readJsonBody(req) {
  return new Promise((resolve) => {
    let data = '';
    req.on('data', (chunk) => { data += chunk; });
    req.on('end', () => {
      try { resolve(JSON.parse(data || '{}')); }
      catch { resolve({}); }
    });
  });
}

export async function captchaHandler(req, res) {
  res.setHeader('Cache-Control', 'no-store');

  if (req.method === 'GET' && req.query && req.query.img) {
    res.setHeader('Cache-Control', 'no-store');
    return serveImage(req, res);
  }

  if (req.method === 'GET' && req.query && req.query.type === 'img') {
    const ip = String(req.headers['x-forwarded-for'] || req.socket?.remoteAddress || '').split(',')[0].trim();
    if (imgLimited(ip)) return res.status(429).json({ error: 'Terlalu banyak permintaan captcha, tunggu sebentar.' });
    const token = makeImgToken();
    return res.status(200).json({ token, img: '/api/captcha?img=' + encodeURIComponent(token) });
  }

  if (req.method === 'GET') {
    const a = randInt(1, 20);
    const b = randInt(1, 20);
    const ops = ['+', '-', '×'];
    const op = ops[randInt(0, ops.length - 1)];

    let answer;
    let question;
    if (op === '+') { answer = a + b; question = `${a} + ${b}`; }
    else if (op === '-') {
      const hi = Math.max(a, b), lo = Math.min(a, b);
      answer = hi - lo; question = `${hi} - ${lo}`;
    } else { answer = a * b; question = `${a} × ${b}`; }

    const token = makeToken(answer);
    return res.status(200).json({ question, token });
  }

  if (req.method === 'POST') {
    const body = req.body && Object.keys(req.body).length ? req.body : await readJsonBody(req);
    const { token, answer } = body || {};
    const result = verifyToken(token, answer);
    if (!result.ok) {
      return res.status(400).json({ ok: false, reason: result.reason });
    }
    // token sekali pakai: terbitkan "verified ticket" pendek yang hanya berlaku
    // beberapa menit, supaya proses signup yang mengikuti tahu captcha-nya lolos.
    const ticket = crypto.createHmac('sha256', SECRET).update('verified:' + token).digest('base64url');
    return res.status(200).json({ ok: true, ticket });
  }

  return res.status(405).json({ error: 'Method not allowed' });
}

// Captcha gambar: valid + sekali pakai. Return null kalau lolos, atau string pesan error.
export async function consumeCaptcha(admin, body) {
  const v = verifyImgCaptcha(body.captchaToken, body.captchaAnswer);
  if (!v.ok) {
    return v.reason === 'wrong-answer' ? 'Captcha salah, coba lagi.' : 'Captcha kedaluwarsa, muat ulang captcha.';
  }
  try {
    await admin.db.collection('captcha_used').doc(crypto.createHash('sha256').update(v.id).digest('hex')).create({ exp: v.exp });
  } catch (e) {
    if (e && (e.code === 6 || /already exists/i.test(e.message || ''))) return 'Captcha sudah dipakai, muat ulang captcha.';
    console.error('[captcha consume]', e && e.message);
    return 'Gagal memeriksa captcha, coba lagi.';
  }
  return null;
}


// Captcha matematika juga sekali pakai (sebelumnya token yang sama bisa dipakai ulang selama 5 menit).
export async function consumeMathToken(admin, token) {
  try {
    await admin.db.collection('captcha_used').doc(crypto.createHash('sha256').update('m:' + token).digest('hex')).create({ exp: Date.now() + TTL_MS });
    return null;
  } catch (e) {
    if (e && (e.code === 6 || /already exists/i.test(e.message || ''))) return 'Captcha sudah dipakai, muat ulang captcha.';
    console.error('[captcha math consume]', e && e.message);
    return 'Gagal memeriksa captcha, coba lagi.';
  }
}
