// Vercel Serverless Function - Instagram Downloader (video, reel, foto, carousel)
//
// POST /api/igdl
//   body: { link: '<url postingan/reel Instagram>' }
//
// Lewat API publik api.siputzx.my.id (gratis, tanpa API key, repo aktif
// di-maintain di github.com/siputzx/apisku). Ambil daftar media (video
// dan/atau foto, termasuk carousel multi-item).
//
// Wajib header Authorization: Bearer <idToken>, sama pola dengan endpoint lain.
// Tanpa limit untuk semua role (FREE/PREMIUM/OWNER), tetap wajib login.

import { getRoleFromRequest, reserveUsage, refundUsage, explainError, logDownload, logFeature } from './_firebaseAdmin.js';
import { maintenanceBlock } from './_firebaseAdmin.js';

const API_URL = 'https://api.siputzx.my.id/api/d/igdl';
const FREE_LIMIT = 15;
const USAGE_COLLECTION = 'igdl_usage';
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '';
const BOT_UA_RE = /(curl|wget|python-requests|python-urllib|scrapy|axios\/|node-fetch|go-http-client|libwww-perl|httpclient|aiohttp|okhttp|postman|insomnia|headlesschrome|phantomjs|puppeteer|playwright|bot|crawler|spider|scraper)/i;
const IG_RE = /instagram\.com/i;

function guessType(u) {
  return /\.(jpe?g|png|webp)(\?|$)/i.test(u) ? 'image' : 'video';
}

// Response shape dari api.siputzx.my.id belum bisa saya verifikasi live dari sini
// (sandbox ini tanpa akses jaringan keluar), jadi parsing-nya dibuat fleksibel:
// nyoba beberapa kemungkinan bentuk data yang umum dipakai API sejenis ({status,
// data:[...]}, {status, data:{data:[...]}}, {status, data:{url:[...]}}, atau
// satu item tunggal {status, data:{url}}). Kalau setelah deploy ternyata
// bentuknya beda, kasih tau pesan error / hasil mentahnya biar saya sesuaikan.
function extractMedia(payload) {
  const d = payload.data;
  let raw = [];
  if (Array.isArray(d)) raw = d;
  else if (Array.isArray(d?.data)) raw = d.data;
  else if (Array.isArray(d?.url)) raw = d.url;
  else if (Array.isArray(d?.result)) raw = d.result;
  else if (d?.url) raw = [d.url];

  return raw
    .map(m => {
      if (typeof m === 'string') return { type: guessType(m), url: m };
      const u = m.url || m.link || m.download || null;
      return u ? { type: m.type || guessType(u), url: u } : null;
    })
    .filter(Boolean);
}

async function fetchInstagram(link) {
  const url = `${API_URL}?url=${encodeURIComponent(link)}`;
  const res = await fetch(url, {
    method: 'GET',
    headers: {
      'Accept': 'application/json',
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    }
  });

  const text = await res.text();
  let payload;
  try { payload = JSON.parse(text); } catch { throw new Error('Respons server tidak terbaca.'); }

  if (!res.ok || payload.status === false || !payload.data) {
    throw new Error(payload.message || payload.msg || `Gagal mengambil data (${res.status}). Pastikan postingan bersifat publik.`);
  }

  const media = extractMedia(payload);
  const d = (payload.data && typeof payload.data === 'object' && !Array.isArray(payload.data)) ? payload.data : {};

  return {
    author: {
      username: d.username || d.author || null,
      fullname: d.fullname || d.full_name || null
    },
    caption: (d.caption || d.title || '').trim(),
    stats: {
      likes: d.likes ?? null,
      comments: d.comments ?? null,
      followed: d.followed ?? d.followers ?? null
    },
    media
  };
}

export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // --- Anti-scraping, sama seperti endpoint lain ---
  const ua = req.headers['user-agent'] || '';
  if (!ua || BOT_UA_RE.test(ua)) {
    return res.status(403).json({ error: 'Akses ditolak' });
  }
  if (ALLOWED_ORIGIN) {
    const origin = req.headers['origin'] || req.headers['referer'] || '';
    if (!origin.startsWith(ALLOWED_ORIGIN)) {
      return res.status(403).json({ error: 'Akses ditolak' });
    }
  }
  // --- end anti-scraping ---

  const { role, uid, provider, error: authError, dbError } = await getRoleFromRequest(req);
  if (!uid) {
    return res.status(401).json({ error: authError ? 'Verifikasi login gagal: ' + authError : 'Login dulu.' });
  }
  if (dbError) return res.status(500).json({ error: dbError });
  if (provider !== 'google.com' && provider !== 'password') {
    return res.status(401).json({ error: 'Metode login tidak didukung.' });
  }

  { // mode maintenance (diatur dari panel admin; OWNER tetap bisa akses)
    const mb = await maintenanceBlock('igdl', role);
    if (mb) return res.status(503).json(mb);
  }

  const body = typeof req.body === 'string' ? safeParse(req.body) : (req.body || {});
  const link = String(body.link || '').trim();
  if (!link) return res.status(400).json({ error: 'Link postingan Instagram belum diisi.' });
  if (!IG_RE.test(link)) return res.status(400).json({ error: 'Link itu bukan dari Instagram. Paste link postingan/reel Instagram dulu.' });

  await logFeature(uid, 'igdl');

  const unlimited = true; // semua tool di Tools Hub tanpa limit untuk semua role (FREE_LIMIT dibiarkan, tidak terpakai)

  let reserved = null;
  if (!unlimited) {
    try {
      const r = await reserveUsage(uid, FREE_LIMIT, USAGE_COLLECTION);
      if (!r.ok) {
        return res.status(429).json({
          error: 'Limit harian habis. Reset otomatis jam 00:00 WIB, atau upgrade ke premium.',
          _usage: { count: r.count, limit: FREE_LIMIT }
        });
      }
      reserved = r;
    } catch (e) {
      return res.status(500).json({ error: 'Gagal mengecek limit harian: ' + explainError(e) });
    }
  }

  const usageOut = (failed) => reserved
    ? { count: Math.max(0, reserved.count - (failed ? 1 : 0)), limit: FREE_LIMIT }
    : { count: 0, limit: null };

  try {
    const result = await fetchInstagram(link);
    if (!result.media.length) {
      if (reserved) { try { await refundUsage(uid, USAGE_COLLECTION); } catch {} }
      return res.status(502).json({ error: 'Media tidak ketemu. Pastikan link postingan publik dan valid.', _usage: usageOut(true) });
    }
    await logDownload(uid, {
      type: 'instagram', key: link, ref: link,
      title: result.caption || result.author?.fullname || result.author?.username,
      subtitle: result.author?.username ? '@' + result.author.username : ''
    });
    return res.status(200).json({ success: true, ...result, _usage: usageOut(false) });
  } catch (e) {
    if (reserved) {
      try { await refundUsage(uid, USAGE_COLLECTION); } catch { /* best-effort */ }
    }
    return res.status(502).json({ error: e.message || 'Gagal memproses link ini.', _usage: usageOut(true) });
  }
}

function safeParse(s) {
  try { return JSON.parse(s); } catch { return {}; }
}
