// REST API publik "React Channel" pakai API key — PREMIUM/OWNER otomatis, FREE harus di-ACC admin. Limit/hari: premium 30, free 10, owner tanpa batas.
// File ber-underscore = helper (bukan Serverless Function, tidak menambah hitungan limit 12 Vercel).
// Dipanggil dari api/rch.js (?tool=apirch, lewat rewrite /api/v1/rch) dan api/profile.js (kelola key).
//
//   GET /api/v1/rch?apikey=<kunci>&url=<link postingan channel>&reaction=<emoji>
//   (atau kirim kunci lewat header  x-api-key: <kunci>)
//
// Penyimpanan (Firestore, hanya server yang bisa akses):
//   apikeys/{sha256(key)}  -> { uid, createdAt }      (lookup cepat: key -> uid; key asli TIDAK disimpan)
//   users/{uid}            -> apiKeyHash, apiKeyPrefix, apiKeyCreatedAt
//   api_usage/{uid}        -> { date, count }          (reset 00:00 WIB, pakai reserveUsage biasa)

import crypto from 'crypto';
import { FieldValue } from 'firebase-admin/firestore';
import {
  prepareDb, getAdminServices, effectiveRoleData, reserveUsage, refundUsage,
  getUsage, maintenanceBlock, explainError
} from './_firebaseAdmin.js';
import { sendMagicLink, applyPremium, extractLink, logHistory, AMPREM_EMAIL_RE } from './amprem.js';

// Limit harian per role: premium 30, free 10 (free wajib di-ACC admin dulu), owner tanpa batas.
export const API_LIMITS = { free: 10, premium: 30 };
export function apiLimitFor(role) { return role === 'owner' ? null : (API_LIMITS[role] ?? API_LIMITS.free); }
// Limit harian khusus endpoint AM Premium: premium & owner tanpa batas, free 35/hari.
export const AMPREM_API_LIMITS = { free: 35 };
export function apiAmpremLimitFor(role) {
  return (role === 'owner' || role === 'premium') ? null : (AMPREM_API_LIMITS[role] ?? AMPREM_API_LIMITS.free);
}
// Boleh pakai API? premium/owner otomatis; free hanya kalau sudah di-ACC admin (users/{uid}.apiAccess === 'approved').
export function apiAccessOk(role, data) {
  return role === 'owner' || role === 'premium' || !!(data && data.apiAccess === 'approved');
}
const USAGE_COLLECTION = 'api_usage';
const AMPREM_USAGE_COLLECTION = 'api_amprem_usage';
const KEY_RE = /^(KR-|kt_)[a-f0-9]{40}$/; // KR- = format sekarang; kt_ = key lama (tetap diterima)
const CHANNEL_RE = /^https?:\/\/(www\.)?whatsapp\.com\/channel\/[A-Za-z0-9_-]+\/\d+/i;

const sha = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');

// ── Kelola key (dipanggil profile.js, user sudah login & role sudah dicek pemanggil) ──
export async function generateApiKey(uid) {
  const { db } = getAdminServices();
  const key = 'KR-' + crypto.randomBytes(20).toString('hex');
  const hash = sha(key);
  const userRef = db.collection('users').doc(uid);
  await db.runTransaction(async (t) => {
    const u = await t.get(userRef);
    const oldHash = u.exists ? u.data().apiKeyHash : null;
    if (oldHash) t.delete(db.collection('apikeys').doc(oldHash)); // key lama langsung mati
    t.set(db.collection('apikeys').doc(hash), { uid, createdAt: Date.now() });
    t.set(userRef, { apiKeyHash: hash, apiKeyPrefix: key.slice(0, 7), apiKeyCreatedAt: Date.now() }, { merge: true });
  });
  return key; // satu-satunya kali key asli terlihat
}

export async function revokeApiKey(uid) {
  const { db } = getAdminServices();
  const userRef = db.collection('users').doc(uid);
  await db.runTransaction(async (t) => {
    const u = await t.get(userRef);
    const oldHash = u.exists ? u.data().apiKeyHash : null;
    if (oldHash) t.delete(db.collection('apikeys').doc(oldHash));
    t.set(userRef, { apiKeyHash: FieldValue.delete(), apiKeyPrefix: FieldValue.delete(), apiKeyCreatedAt: FieldValue.delete() }, { merge: true });
  });
}

// Ringkasan untuk profileResponse (tanpa key asli).
export async function apiKeyInfo(uid, userData, role) {
  const eligible = apiAccessOk(role, userData);
  const access = (role === 'premium' || role === 'owner') ? 'auto' : ((userData && userData.apiAccess) || 'none');
  let used = 0, bonus = 0;
  if (eligible) {
    try { used = (await getUsage(uid, USAGE_COLLECTION)).count; } catch { /* abaikan */ }
    try { const w = await getAdminServices().db.collection('wallets').doc(uid).get(); bonus = (w.exists && w.data().bonus_api_usage) || 0; } catch { /* abaikan */ }
  }
  return {
    eligible,
    access, // auto | none | pending | approved | rejected
    canRequest: role === 'free' && (access === 'none' || access === 'rejected'),
    has: !!(userData && userData.apiKeyHash),
    banned: !!(userData && userData.apiBanned),
    banReason: (userData && userData.apiBanReason) || '',
    prefix: (userData && userData.apiKeyPrefix) || null,
    createdAt: (userData && userData.apiKeyCreatedAt) || null,
    limit: apiLimitFor(role),
    used, bonus
  };
}

// ── Endpoint publik ──
const ipHits = new Map(); // anti-spam ringan per instance: 60 request / menit / IP
function ipLimited(ip) {
  const now = Date.now();
  const arr = (ipHits.get(ip) || []).filter((t) => now - t < 60000);
  if (arr.length >= 60) { ipHits.set(ip, arr); return true; }
  arr.push(now); ipHits.set(ip, arr);
  return false;
}

// Anti-robot untuk pemakaian key: maks 5 request / 10 detik per key (per instance), supaya satu key tidak bisa dipakai menghantam server.
const keyHits = new Map();
function keyBurstLimited(k) {
  const now = Date.now();
  const arr = (keyHits.get(k) || []).filter((t) => now - t < 10000);
  if (arr.length >= 5) { keyHits.set(k, arr); return true; }
  arr.push(now); keyHits.set(k, arr);
  if (keyHits.size > 5000) keyHits.clear();
  return false;
}

// Tebak-tebak key: maks 20 key salah / 10 menit per IP (per instance).
const badKeyHits = new Map();
function badKeyLimited(ip) {
  const now = Date.now();
  const arr = (badKeyHits.get(ip) || []).filter((t) => now - t < 600000);
  badKeyHits.set(ip, arr);
  if (badKeyHits.size > 5000) badKeyHits.clear();
  return arr.length >= 20;
}
function noteBadKey(ip) { const arr = badKeyHits.get(ip) || []; arr.push(Date.now()); badKeyHits.set(ip, arr); }

export async function publicReact(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'x-api-key, content-type');
  res.setHeader('Cache-Control', 'no-store');
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'GET') return res.status(405).json({ status: false, error: 'Method not allowed, pakai GET.' });

  const out = (code, body) => res.status(code).json({ status: false, ...body });

  const ip = String(req.headers['x-forwarded-for'] || req.socket?.remoteAddress || '').split(',')[0].trim();
  if (ipLimited(ip)) return out(429, { error: 'Terlalu banyak permintaan, coba lagi sebentar.' });

  const q = req.query || {};
  const key = String(req.headers['x-api-key'] || q.apikey || '').trim();
  if (badKeyLimited(ip)) return out(429, { error: 'Terlalu banyak API key salah, coba lagi 10 menit lagi.' });
  if (!KEY_RE.test(key)) { noteBadKey(ip); return out(401, { error: 'API key tidak valid atau belum dikirim (parameter apikey).' }); }

  if (keyBurstLimited(sha(key))) return out(429, { error: 'Terlalu cepat. Maksimal 5 request per 10 detik per key.' });

  const url = String(q.url || '').trim();
  const reaction = String(q.reaction || '').trim();
  if (!url || !reaction) return out(400, { error: 'Parameter url dan reaction wajib diisi.' });
  if (!CHANNEL_RE.test(url)) return out(400, { error: 'Link bukan link postingan saluran WhatsApp yang valid.' });
  if (reaction.length > 16) return out(400, { error: 'Reaksi kepanjangan, pakai emoji saja.' });

  const nexaKey = process.env.NEXADEV_KEY;
  if (!nexaKey) return out(500, { error: 'Server belum dikonfigurasi (NEXADEV_KEY).' });

  try { await prepareDb(); } catch { /* getAdminServices yang menentukan */ }
  const admin = getAdminServices();
  if (!admin) return out(500, { error: 'Server database belum dikonfigurasi.' });

  // key -> uid -> role (dicek ulang tiap request, jadi premium yang habis masa aktif otomatis ditolak)
  let uid, role, udata;
  try {
    const hash = sha(key);
    const kSnap = await admin.db.collection('apikeys').doc(hash).get();
    if (!kSnap.exists) { noteBadKey(ip); return out(401, { error: 'API key tidak valid atau sudah dicabut.' }); }
    uid = kSnap.data().uid;
    const uSnap = await admin.db.collection('users').doc(uid).get();
    const data = uSnap.exists ? uSnap.data() : {};
    if (data.apiKeyHash !== hash) return out(401, { error: 'API key tidak valid atau sudah dicabut.' });
    role = effectiveRoleData(data).role;
    udata = data;
    if (data.banned) return out(403, { error: 'Akun kamu dibanned.' });
    if (data.apiBanned) return out(403, { error: 'API key kamu diblokir admin.' + (data.apiBanReason ? ' Alasan: ' + data.apiBanReason : '') });
  } catch (e) {
    return out(500, { error: 'Gagal memeriksa API key: ' + explainError(e) });
  }
  if (!apiAccessOk(role, udata)) {
    return out(403, { error: 'Akses API belum disetujui admin. Ajukan lewat halaman /apidocs, atau upgrade ke PREMIUM.' });
  }
  const dailyLimit = apiLimitFor(role);

  const mb = await maintenanceBlock('zeereact', role);
  if (mb) return res.status(503).json({ status: false, ...mb });

  let reserved = null;
  if (role !== 'owner') {
    try {
      const r = await reserveUsage(uid, dailyLimit, USAGE_COLLECTION);
      if (!r.ok) {
        return out(429, { error: `Limit harian API habis (${dailyLimit}/hari). Reset otomatis jam 00:00 WIB.`, usage: { count: r.count, limit: dailyLimit } });
      }
      reserved = r;
    } catch (e) {
      return out(500, { error: 'Gagal mengecek limit harian: ' + explainError(e) });
    }
  }
  const usage = (failed) => ({ count: reserved ? Math.max(0, reserved.count - (failed ? 1 : 0)) : 0, limit: reserved ? reserved.limit : null });
  const refund = async () => { if (reserved) { try { await refundUsage(uid, USAGE_COLLECTION); } catch { /* best-effort */ } } };

  try {
    const apiUrl = `https://api.nexadev.my.id/api/rch?key=${encodeURIComponent(nexaKey)}&url=${encodeURIComponent(url)}&reaction=${encodeURIComponent(reaction)}`;
    const upstream = await fetch(apiUrl, { method: 'GET', headers: { Accept: 'application/json' } });
    const text = await upstream.text();
    let data;
    try { data = JSON.parse(text); } catch { data = { raw: text }; }
    if (!data || typeof data !== 'object' || Array.isArray(data)) data = { data };

    const failed = !upstream.ok ||
      data.status === false || data.success === false || data.ok === false ||
      ['error', 'failed', 'fail'].includes(String(data.status).toLowerCase()) || !!data.error;

    // Jangan bocorkan key nexadev kalau upstream memantulkannya.
    const clean = JSON.parse(JSON.stringify(data).split(nexaKey).join('***'));
    // Rebrand: upstream ngasih "author": "NexaDev" di field result, ganti jadi KUREZA.
    if (clean.result && typeof clean.result === 'object' && clean.result.author) {
      clean.result.author = 'KUREZA';
    }
    if (failed) {
      await refund();
      return res.status(upstream.ok ? 502 : upstream.status).json({ status: false, error: 'Gagal react di server upstream.', result: clean, usage: usage(true) });
    }
    return res.status(200).json({ status: true, result: clean, usage: usage(false) });
  } catch (e) {
    await refund();
    return res.status(502).json({ status: false, error: 'Gagal menghubungi server upstream.', usage: usage(true) });
  }
}

// ── Endpoint publik: AM Premium (apply / magic link) ──
// Dipanggil dari api/rch.js (?tool=apiamprem, lewat rewrite /api/v1/amprem).
// Limit harian terpisah dari react (api_amprem_usage), beda angka: free 35/hari, premium & owner tanpa batas.
//   GET /api/v1/amprem?apikey=<kunci>&action=magic&email=<email>
//   GET /api/v1/amprem?apikey=<kunci>&action=apply&email=<email>&link=<link dari email>
//   (atau kirim kunci lewat header  x-api-key: <kunci>)
export async function publicAmprem(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'x-api-key, content-type');
  res.setHeader('Cache-Control', 'no-store');
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'GET') return res.status(405).json({ status: false, error: 'Method not allowed, pakai GET.' });

  const out = (code, body) => res.status(code).json({ status: false, ...body });

  const ip = String(req.headers['x-forwarded-for'] || req.socket?.remoteAddress || '').split(',')[0].trim();
  if (ipLimited(ip)) return out(429, { error: 'Terlalu banyak permintaan, coba lagi sebentar.' });

  const q = req.query || {};
  const key = String(req.headers['x-api-key'] || q.apikey || '').trim();
  if (badKeyLimited(ip)) return out(429, { error: 'Terlalu banyak API key salah, coba lagi 10 menit lagi.' });
  if (!KEY_RE.test(key)) { noteBadKey(ip); return out(401, { error: 'API key tidak valid atau belum dikirim (parameter apikey).' }); }

  if (keyBurstLimited(sha(key))) return out(429, { error: 'Terlalu cepat. Maksimal 5 request per 10 detik per key.' });

  const action = String(q.action || '').trim().toLowerCase();
  if (action !== 'magic' && action !== 'apply') {
    return out(400, { error: 'Parameter action harus "magic" atau "apply".' });
  }
  const email = String(q.email || '').trim();
  if (!AMPREM_EMAIL_RE.test(email)) return out(400, { error: 'Parameter email tidak valid.' });

  let rawLink = '';
  if (action === 'apply') {
    rawLink = String(q.link || '').trim();
    if (!rawLink || !rawLink.includes('http')) {
      return out(400, { error: 'Parameter link wajib diisi, harus link dari email Alight Motion.' });
    }
  }

  try { await prepareDb(); } catch { /* getAdminServices yang menentukan */ }
  const admin = getAdminServices();
  if (!admin) return out(500, { error: 'Server database belum dikonfigurasi.' });

  // key -> uid -> role (dicek ulang tiap request, jadi premium yang habis masa aktif otomatis ditolak)
  let uid, role, udata;
  try {
    const hash = sha(key);
    const kSnap = await admin.db.collection('apikeys').doc(hash).get();
    if (!kSnap.exists) { noteBadKey(ip); return out(401, { error: 'API key tidak valid atau sudah dicabut.' }); }
    uid = kSnap.data().uid;
    const uSnap = await admin.db.collection('users').doc(uid).get();
    const data = uSnap.exists ? uSnap.data() : {};
    if (data.apiKeyHash !== hash) return out(401, { error: 'API key tidak valid atau sudah dicabut.' });
    role = effectiveRoleData(data).role;
    udata = data;
    if (data.banned) return out(403, { error: 'Akun kamu dibanned.' });
    if (data.apiBanned) return out(403, { error: 'API key kamu diblokir admin.' + (data.apiBanReason ? ' Alasan: ' + data.apiBanReason : '') });
  } catch (e) {
    return out(500, { error: 'Gagal memeriksa API key: ' + explainError(e) });
  }
  if (!apiAccessOk(role, udata)) {
    return out(403, { error: 'Akses API belum disetujui admin. Ajukan lewat halaman /apidocs, atau upgrade ke PREMIUM.' });
  }

  const mb = await maintenanceBlock('amprem', role);
  if (mb) return res.status(503).json({ status: false, ...mb });

  const dailyLimit = apiAmpremLimitFor(role); // null = premium/owner, tanpa batas
  let reserved = null;
  if (dailyLimit !== null) {
    try {
      const r = await reserveUsage(uid, dailyLimit, AMPREM_USAGE_COLLECTION);
      if (!r.ok) {
        return out(429, { error: `Limit harian API AM Premium habis (${dailyLimit}/hari). Reset otomatis jam 00:00 WIB, atau upgrade ke PREMIUM untuk tanpa batas.`, usage: { count: r.count, limit: dailyLimit } });
      }
      reserved = r;
    } catch (e) {
      return out(500, { error: 'Gagal mengecek limit harian: ' + explainError(e) });
    }
  }
  const usage = (failed) => ({ count: reserved ? Math.max(0, reserved.count - (failed ? 1 : 0)) : 0, limit: reserved ? reserved.limit : null });
  const refund = async () => { if (reserved) { try { await refundUsage(uid, AMPREM_USAGE_COLLECTION); } catch { /* best-effort */ } } };

  try {
    if (action === 'magic') {
      const result = await sendMagicLink(email);
      await logHistory(admin.db, uid, { type: 'magic', email, message: result.message, via: 'api' });
      return res.status(200).json({ status: true, result, usage: usage(false) });
    } else {
      const finalLink = extractLink(rawLink);
      const result = await applyPremium(email, finalLink);
      await logHistory(admin.db, uid, { type: 'apply', email, planName: result.planName, expiry: result.expiry, membershipStatus: result.membershipStatus, via: 'api' });
      return res.status(200).json({ status: true, result, usage: usage(false) });
    }
  } catch (e) {
    await refund();
    return res.status(502).json({ status: false, error: e.message || 'Gagal menghubungi server upstream AM Premium.', usage: usage(true) });
  }
}

// ── Free user mengajukan akses API (menunggu ACC admin) ──
export async function requestApiAccess(uid, role, data) {
  if (role !== 'free') return { err: 'Akun ini tidak perlu mengajukan akses.' };
  if (data && data.apiAccess === 'approved') return { ok: true, access: 'approved' };
  if (data && data.apiAccess === 'pending') return { ok: true, access: 'pending' };
  if (data && data.apiBanned) return { err: 'Akses API kamu diblokir admin.' };
  const { db } = getAdminServices();
  await db.collection('users').doc(uid).set({ apiAccess: 'pending', apiRequestedAt: Date.now() }, { merge: true });
  return { ok: true, access: 'pending' };
}

// ── Panel admin (dipanggil api/admin.js; pemanggil sudah cek kode owner) ──
export async function adminListApiKeys() {
  const { db } = getAdminServices();
  const [withKey, withAccess] = await Promise.all([
    db.collection('users').where('apiKeyHash', '>', '').limit(500).get(),
    db.collection('users').where('apiAccess', 'in', ['pending', 'approved', 'rejected']).limit(500).get()
  ]);
  const docs = new Map();
  for (const d of withKey.docs) docs.set(d.id, d);
  for (const d of withAccess.docs) docs.set(d.id, d);
  const today = new Date(Date.now() + 7 * 3600 * 1000).toISOString().slice(0, 10);
  const keys = await Promise.all([...docs.values()].map(async (d) => {
    const u = d.data();
    const role = effectiveRoleData(u).role;
    let used = 0;
    try {
      const us = await db.collection(USAGE_COLLECTION).doc(d.id).get();
      if (us.exists && us.data().date === today) used = us.data().count || 0;
    } catch { /* abaikan */ }
    return {
      uid: d.id, email: u.email || '(tanpa email)', username: u.username || '',
      role, access: (role === 'premium' || role === 'owner') ? 'auto' : (u.apiAccess || 'none'),
      hasKey: !!u.apiKeyHash, prefix: u.apiKeyPrefix || '', createdAt: u.apiKeyCreatedAt || null,
      requestedAt: u.apiRequestedAt || null,
      used, limit: apiLimitFor(role), banned: !!u.apiBanned, banReason: u.apiBanReason || ''
    };
  }));
  const rank = (k) => (k.access === 'pending' ? 0 : 1);
  keys.sort((a, b) => rank(a) - rank(b) || a.email.localeCompare(b.email));
  return keys;
}

// ACC / tolak akses API untuk user free. Tolak (atau cabut akses) = key yang ada ikut dihapus.
export async function adminSetApiAccess(uid, status) {
  const { db } = getAdminServices();
  const ref = db.collection('users').doc(uid);
  const snap = await ref.get();
  if (!snap.exists) return false;
  if (status === 'rejected') await revokeApiKey(uid);
  await ref.set({ apiAccess: status, apiAccessAt: Date.now() }, { merge: true });
  return true;
}

export async function adminSetApiBan(uid, banned, reason) {
  const { db } = getAdminServices();
  const ref = db.collection('users').doc(uid);
  const snap = await ref.get();
  if (!snap.exists) return false;
  await ref.set({
    apiBanned: !!banned,
    apiBanReason: banned ? String(reason || '').slice(0, 200) : FieldValue.delete(),
    apiBannedAt: banned ? Date.now() : FieldValue.delete()
  }, { merge: true });
  return true;
}
