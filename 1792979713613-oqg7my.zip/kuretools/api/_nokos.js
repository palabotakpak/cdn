// Nokos (sewa nomor virtual buat terima OTP) -- bukan Serverless Function sendiri
// (prefix "_"), dipanggil dari api/system.js (action=nokos, USER biasa) dan
// api/admin.js (action=nokos-*, khusus OWNER) supaya jumlah Serverless Function
// tetap <= 12 di Vercel Hobby plan.
//
// Upstream: Ditznesia (https://www.ditznesia.com/api/dev) -- semua endpoint GET,
// apikey dikirim lewat query string. Env wajib: DITZNESIA_API_KEY (TIDAK PERNAH
// dikirim ke client). Opsional: DITZNESIA_API_BASE (default di bawah).
//
// Produk yang dijual ke USER BIASA cuma 1: "Nomor WA Indonesia", harga FLAT
// NOKOS_WA_PRICE (Rp5.000) -- berapa pun server yang dipilih & berapa pun harga
// asli dari Ditznesia (server 1 WA ~Rp4.040, server 5 ~Rp2.500, dst), user tetap
// bayar Rp5.000 rata. Selisihnya jadi untung (atau ditanggung) platform, BUKAN
// pass-through harga asli. User cuma boleh: order, cek status, resend OTP, batal
// (refund Rp5.000 flat yang dia bayar -- bukan field `price` dari respons
// /cancel, karena yang dia bayar memang flat, bukan harga asli).
//
// Endpoint upstream lain (countries, services, operators, profile, deposit,
// history) CUMA bisa diakses lewat panel admin (OWNER) di api/admin.js, actions
// 'nokos-*' -- dipakai buat ngecek akun Ditznesia (saldo master, riwayat, isi
// saldo via deposit QRIS, lihat katalog layanan/negara/operator mentah).

const DITZ_BASE = process.env.DITZNESIA_API_BASE || 'https://www.ditznesia.com/api/dev';

export const NOKOS_WA_PRICE = 5000; // harga jual flat ke user, SELALU segini apa pun server/harga asli

// server 1,2,3,5 pakai kode negara angka ("6" = Indonesia di Ditznesia); server 4 pakai
// kode ISO ("id"), sesuai contoh di dokumentasi API.
export const NOKOS_SERVERS = {
  1: { label: 'Server 1', country: '6' },
  2: { label: 'Server 2', country: '6' },
  3: { label: 'Server 3', country: '6' },
  4: { label: 'Server 4', country: 'id' },
  5: { label: 'Server 5', country: '6' }
};

function ditzKey() { return process.env.DITZNESIA_API_KEY || ''; }

async function ditzGet(path, params) {
  if (!ditzKey()) return { ok: false, status: 500, data: null, error: 'DITZNESIA_API_KEY belum diset di Environment Variable.' };
  const url = new URL(DITZ_BASE + path);
  url.searchParams.set('apikey', ditzKey());
  for (const [k, v] of Object.entries(params || {})) {
    if (v !== undefined && v !== null && v !== '') url.searchParams.set(k, String(v));
  }
  try {
    const res = await fetch(url.toString(), { signal: AbortSignal.timeout(20000) });
    const data = await res.json().catch(() => null);
    if (!res.ok || !data || data.error) {
      return { ok: false, status: res.status, data, error: (data && (data.error || data.message)) || ('HTTP ' + res.status) };
    }
    return { ok: true, status: res.status, data };
  } catch (e) {
    return { ok: false, status: 502, data: null, error: 'Gagal menghubungi Ditznesia: ' + (e && e.message ? e.message : String(e)) };
  }
}

// Server 2/4/5 butuh parameter `provider` (dipilih dari /services), bukan `operator` kayak
// server 1 atau tanpa param kayak server 3. Nama field provider ID di respons /services belum
// 100% pasti dari dokumentasi (cuma dicontohin buat server 1 yang gak butuh provider), jadi
// dicoba beberapa kemungkinan field dengan fallback ke `id`. Kalau ternyata meleset setelah
// dites live, sesuaikan daftar field di bawah (findWaProvider).
async function findWaProvider(server, country) {
  const r = await ditzGet('/services', { server, country, service: 'wa' });
  if (!r.ok || !Array.isArray(r.data) || !r.data.length) return null;
  const item = r.data.find((x) => x && (x.produk === 'wa' || x.id === 'wa')) || r.data[0];
  return item.provider ?? item.provider_id ?? item.providerId ?? item.id ?? null;
}

// Order 1 nomor WA Indonesia dari server pilihan user. Mengembalikan data order ASLI dari
// Ditznesia (termasuk `id` asli -- ini yang disimpan & dipakai buat status/resend/cancel
// selanjutnya, BUKAN harga `price` di dalamnya yang dipakai buat potong saldo user).
export async function orderNokosWa(server) {
  const srv = NOKOS_SERVERS[Number(server)];
  if (!srv) return { ok: false, error: 'Server tidak dikenal.' };

  const params = { server, country: srv.country, produk: 'wa' };
  if (Number(server) === 1) {
    params.operator = 'any';
  } else if (Number(server) === 3) {
    // tanpa param tambahan
  } else {
    const provider = await findWaProvider(server, srv.country);
    if (!provider) return { ok: false, error: 'Gagal menemukan provider WA buat server ini. Cek katalog layanan di panel admin (nokos-services).' };
    params.provider = provider;
  }

  const r = await ditzGet('/order', params);
  if (!r.ok || !r.data || !r.data.id) return { ok: false, error: r.error || 'Order ditolak upstream.' };
  return { ok: true, order: r.data };
}

export async function statusNokos(ditzId) {
  const r = await ditzGet('/status', { id: ditzId });
  if (!r.ok) return { ok: false, error: r.error || 'Gagal cek status.' };
  return { ok: true, data: r.data };
}

export async function resendNokos(ditzId) {
  const r = await ditzGet('/resend', { id: ditzId });
  if (!r.ok) return { ok: false, error: r.error || 'Gagal resend OTP.' };
  return { ok: true, data: r.data };
}

export async function cancelNokos(ditzId) {
  const r = await ditzGet('/cancel', { id: ditzId });
  if (!r.ok) return { ok: false, error: r.error || 'Gagal membatalkan order.' };
  return { ok: true, data: r.data };
}

// ---- Dipakai admin.js (OWNER-only, passthrough mentah ke Ditznesia) ----
export async function ditzProfile() { return ditzGet('/profile', {}); }
export async function ditzCountries(server) { return ditzGet('/countries', { server }); }
export async function ditzServices(server, country, service) { return ditzGet('/services', { server, country, service }); }
export async function ditzOperators(server, country) { return ditzGet('/operators', { server, country }); }
export async function ditzHistory(limit) { return ditzGet('/history', { limit: limit || 20 }); }
export async function ditzDepositCreate(nominal, code) { return ditzGet('/deposit/create', { nominal, code }); }
export async function ditzDepositStatus(id) { return ditzGet('/deposit/status', { id }); }
export async function ditzDepositCancel(id) { return ditzGet('/deposit/cancel', { id }); }
export async function ditzDepositHistory(limit, status) { return ditzGet('/deposit/history', { limit: limit || 20, status }); }
