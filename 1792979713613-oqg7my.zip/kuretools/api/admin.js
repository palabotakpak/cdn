// Vercel Serverless Function - panel admin (login pakai KODE saja, tanpa akun)
//
// Setiap request POST wajib bawa header:  X-Admin-Code: <kode admin>
// Kode dicek DI SERVER terhadap env var OWNER_CODE (tidak pernah ada di frontend/repo).
//
// Aksi (body JSON):
//   { action: 'check' }                                  -> cek kode benar atau salah
//   { action: 'list-users' }                             -> daftar user + username + role + roleExpiresAt + banned
//   { action: 'set-role', email, role, days? }           -> role: 'owner' | 'premium' | 'free'
//                                                            'owner' = permanen & unlimited (tanpa masa aktif, days diabaikan)
//                                                            days wajib diisi kalau role 'premium'
//                                                            (masa aktif, 1-3650 hari). Setelah lewat,
//                                                            otomatis balik ke 'free' (self-heal, lihat
//                                                            _firebaseAdmin.js -> getRoleFromRequest).
//   { action: 'ban-user', email, reason? }               -> blokir akun (semua API nolak dia, lihat
//                                                            _firebaseAdmin.js -> getRoleFromRequest)
//   { action: 'unban-user', email }                      -> cabut blokir
//   { action: 'get-announcement' }                       -> baca pengumuman broadcast saat ini
//   { action: 'set-announcement', text, enabled }        -> set/matikan pengumuman broadcast
//                                                            (tampil di semua halaman user, lihat /api/announcement)
//   { action: 'get-maintenance' }                        -> daftar fitur web + status maintenance (on/off) + pesan
//   { action: 'set-maintenance', features }              -> features = { <kunci>: { on, message? } }; fitur yang on ditahan
//                                                            di server (503) dan ditandai di frontend. OWNER tetap bisa akses.
//   { action: 'smm-balance' }                             -> cek sisa saldo akun FAYUPEDIA (SMM Panel)
//   { action: 'wallet-lookup', email }                    -> saldo + limit tambahan milik user
//   { action: 'wallet-adjust', email, amount }            -> tambah (atau kurangi pakai minus) saldo user secara manual
//   { action: 'limit-adjust', email, type, amount }       -> tambah/kurangi limit tambahan manual; type: react | amprem | smm
//   { action: 'stats' }                                   -> statistik: jumlah user per role + pemakaian fitur (total/hari ini/7 hari)
//   { action: 'smm-orders' }                              -> daftar 100 transaksi Suntik Sosmed terakhir + status live
//   { action: 'smm-approve', id }                         -> ACC order 'menunggu_acc' -> baru dikirim ke panel.
//                                                            CATATAN: sejak order FREE (bayar saldo) auto-submit
//                                                            langsung dari api/system.js, satu-satunya order yang
//                                                            masih nyangkut di 'menunggu_acc' adalah order PREMIUM/
//                                                            OWNER yang pakai jatah gratis mingguan (price = 0).
//   { action: 'smm-reject', id }                          -> tolak order, jatah mingguan dikembalikan (refund saldo
//                                                            cuma kejadian kalau ada order lama peninggalan sebelum
//                                                            perubahan auto-submit FREE di atas)
//   { action: 'nokos-profile' }                           -> profil & saldo akun Ditznesia (MASTER, bukan punya user)
//   { action: 'nokos-countries', server }                 -> daftar negara per server
//   { action: 'nokos-services', server, country, service? } -> daftar layanan (+ harga asli upstream)
//   { action: 'nokos-operators', server, country }        -> daftar operator seluler asli (server 1 & 4)
//   { action: 'nokos-history', limit? }                   -> riwayat order ASLI akun Ditznesia (rekonsiliasi saldo)
//   { action: 'nokos-orders' }                             -> daftar transaksi Nokos INTERNAL (semua user, platform sendiri)
//   { action: 'nokos-deposit-create', nominal, code? }    -> buat invoice QRIS isi saldo akun Ditznesia (MASTER)
//   { action: 'nokos-deposit-status', id }                -> cek status deposit akun Ditznesia
//   { action: 'nokos-deposit-cancel', id }                -> batalkan deposit pending akun Ditznesia
//   { action: 'nokos-deposit-history', limit?, status? }  -> riwayat deposit akun Ditznesia
//
// Env var wajib: OWNER_CODE + kredensial Firebase Admin (lihat _firebaseAdmin.js)
// Env var opsional (buat smm-balance / smm-orders): FAYUPEDIA_API_KEY, FAYUPEDIA_API_URL
// Env var wajib buat fitur Nokos: DITZNESIA_API_KEY (lihat api/_nokos.js)

import crypto from 'crypto';
import { prepareDb, getAdminServices, getAdminInitError, explainError, effectiveRoleData, refundSmmUsage, wibDate, MAINT_FEATURES, resetMaintenanceCache } from './_firebaseAdmin.js';
import { submitSmmOrder } from './_smm.js';
import { ditzProfile, ditzCountries, ditzServices, ditzOperators, ditzHistory, ditzDepositCreate, ditzDepositStatus, ditzDepositCancel, ditzDepositHistory } from './_nokos.js';
import { FieldValue } from 'firebase-admin/firestore';
import { adminListApiKeys, adminSetApiBan, adminSetApiAccess, revokeApiKey } from './_apikey.js';

const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '';
const OWNER_CODE = process.env.OWNER_CODE || '';
const SETTABLE_ROLES = ['owner', 'premium', 'free'];
const MIN_DAYS = 1;
const MAX_DAYS = 3650;

// Batasi tebak-tebakan kode: 8 salah / 15 menit per IP (best-effort, in-memory).
const FAIL_MAX = 8;
const FAIL_WINDOW_MS = 15 * 60 * 1000;
const fails = new Map();

function isBlocked(ip) {
  const e = fails.get(ip);
  if (!e) return false;
  if (Date.now() - e.start > FAIL_WINDOW_MS) { fails.delete(ip); return false; }
  return e.count >= FAIL_MAX;
}
function recordFail(ip) {
  const now = Date.now();
  const e = fails.get(ip);
  if (!e || now - e.start > FAIL_WINDOW_MS) fails.set(ip, { start: now, count: 1 });
  else e.count += 1;
}

// Penguncian PERMANEN (Firestore) supaya tidak bisa dilewati dengan memicu banyak instance serverless.
// Best-effort: kalau DB bermasalah, tetap jalan dengan penghitung in-memory di atas.
function ipDocId(ip) { return crypto.createHash('sha256').update('adminfail:' + ip).digest('hex'); }
async function isBlockedDb(ip) {
  try {
    await prepareDb();
    const a = getAdminServices();
    if (!a) return false;
    const s = await a.db.collection('admin_lock').doc(ipDocId(ip)).get();
    if (!s.exists) return false;
    const d = s.data();
    return Date.now() - (d.start || 0) <= FAIL_WINDOW_MS && (d.count || 0) >= FAIL_MAX;
  } catch { return false; }
}
async function recordFailDb(ip) {
  try {
    const a = getAdminServices();
    if (!a) return;
    const ref = a.db.collection('admin_lock').doc(ipDocId(ip));
    await a.db.runTransaction(async (t) => {
      const s = await t.get(ref);
      const now = Date.now();
      const d = s.exists ? s.data() : null;
      if (!d || now - (d.start || 0) > FAIL_WINDOW_MS) t.set(ref, { start: now, count: 1 });
      else t.set(ref, { start: d.start, count: (d.count || 0) + 1 });
    });
  } catch { /* best-effort */ }
}

const AUDITED = new Set(['set-role', 'ban-user', 'unban-user', 'wallet-adjust', 'limit-adjust', 'apikey-access', 'apikey-delete', 'apikey-ban', 'apikey-unban', 'smm-approve', 'smm-reject', 'set-maintenance', 'set-announcement']);
async function audit(admin, action, body, ip) {
  try {
    await admin.db.collection('admin_audit').add({
      action, at: Date.now(), ip,
      target: String(body.uid || body.email || body.id || '').slice(0, 120),
      detail: JSON.stringify({ role: body.role, status: body.status, amount: body.amount, type: body.type, days: body.days }).slice(0, 300)
    });
  } catch { /* best-effort */ }
}

function safeEqual(a, b) {
  const ha = crypto.createHash('sha256').update(String(a)).digest();
  const hb = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(ha, hb);
}

function getClientIp(req) {
  const fwd = req.headers['x-forwarded-for'];
  if (fwd) return String(fwd).split(',')[0].trim();
  return req.socket?.remoteAddress || 'unknown';
}

export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  if (ALLOWED_ORIGIN) {
    const origin = req.headers['origin'] || req.headers['referer'] || '';
    if (!origin.startsWith(ALLOWED_ORIGIN)) {
      return res.status(403).json({ error: 'Akses ditolak' });
    }
  }

  if (!OWNER_CODE) {
    return res.status(500).json({ error: 'OWNER_CODE belum diset di environment variables Vercel' });
  }

  const ip = getClientIp(req);
  if (isBlocked(ip) || await isBlockedDb(ip)) {
    return res.status(429).json({ error: 'Terlalu banyak kode salah, coba lagi 15 menit lagi.' });
  }

  const code = String(req.headers['x-admin-code'] || '').trim();
  if (!code || !safeEqual(code, OWNER_CODE)) {
    recordFail(ip);
    await recordFailDb(ip);
    return res.status(403).json({ error: 'Kode admin salah.' });
  }

  const body = typeof req.body === 'string' ? safeParse(req.body) : (req.body || {});
  const action = body.action;

  if (action === 'check') {
    return res.status(200).json({ ok: true });
  }

  await prepareDb();
  const admin = getAdminServices();
  if (!admin) {
    return res.status(500).json({ error: 'Firebase Admin belum dikonfigurasi: ' + (getAdminInitError() || 'env var kosong') });
  }

  if (AUDITED.has(action)) await audit(admin, action, body, ip);

  if (action === 'list-users') {
    try {
      const snap = await admin.db.collection('users').limit(500).get();
      const users = snap.docs.map(d => {
        const data = d.data();
        const eff = effectiveRoleData(data); // tampilan read-only; self-heal beneran terjadi pas user itu sendiri hit API
        return {
          uid: d.id,
          email: data.email || '(tanpa email)',
          username: data.username || '',
          role: eff.role,
          roleExpiresAt: eff.roleExpiresAt,
          banned: !!data.banned,
          banReason: data.banReason || ''
        };
      }).sort((a, b) => a.email.localeCompare(b.email));
      return res.status(200).json({ ok: true, users });
    } catch (e) {
      return res.status(500).json({ error: 'Gagal membaca daftar user: ' + explainError(e) });
    }
  }

  // ── API key publik (/api/v1/rch): daftar, hapus, ban/unban ──
  if (action === 'apikey-list') {
    try { return res.status(200).json({ ok: true, keys: await adminListApiKeys() }); }
    catch (e) { return res.status(500).json({ error: 'Gagal membaca daftar API key: ' + explainError(e) }); }
  }
  if (action === 'apikey-access') {
    const uid = String(body.uid || '').trim();
    const status = String(body.status || '');
    if (!uid) return res.status(400).json({ error: 'uid target wajib diisi.' });
    if (status !== 'approved' && status !== 'rejected') return res.status(400).json({ error: 'status harus approved atau rejected.' });
    try {
      const found = await adminSetApiAccess(uid, status);
      if (!found) return res.status(404).json({ error: 'User tidak ditemukan.' });
      return res.status(200).json({ ok: true, uid, status });
    } catch (e) {
      return res.status(500).json({ error: 'Gagal memproses akses API: ' + explainError(e) });
    }
  }
  if (action === 'apikey-delete' || action === 'apikey-ban' || action === 'apikey-unban') {
    const uid = String(body.uid || '').trim();
    if (!uid) return res.status(400).json({ error: 'uid target wajib diisi.' });
    try {
      if (action === 'apikey-delete') {
        await revokeApiKey(uid);
        return res.status(200).json({ ok: true, uid, deleted: true });
      }
      const banned = action === 'apikey-ban';
      const found = await adminSetApiBan(uid, banned, String(body.reason || '').trim());
      if (!found) return res.status(404).json({ error: 'User tidak ditemukan.' });
      return res.status(200).json({ ok: true, uid, banned });
    } catch (e) {
      return res.status(500).json({ error: 'Gagal memproses API key: ' + explainError(e) });
    }
  }

  if (action === 'set-role') {
    const email = String(body.email || '').trim().toLowerCase();
    const role = String(body.role || '').trim();
    if (!email) return res.status(400).json({ error: 'Email target wajib diisi.' });
    if (!SETTABLE_ROLES.includes(role)) {
      return res.status(400).json({ error: 'Role harus owner, premium, atau free.' });
    }

    let roleExpiresAt = null;
    if (role === 'premium') {
      const days = Number(body.days);
      if (!Number.isFinite(days) || days < MIN_DAYS || days > MAX_DAYS) {
        return res.status(400).json({ error: `Masa aktif wajib diisi angka ${MIN_DAYS}-${MAX_DAYS} hari.` });
      }
      roleExpiresAt = Date.now() + Math.round(days) * 24 * 60 * 60 * 1000;
    }

    try {
      const target = await admin.auth.getUserByEmail(email);
      const snap = await admin.db.collection('users').doc(target.uid).get();
      if (snap.exists && snap.data().role === 'owner') {
        return res.status(400).json({ error: 'Target berstatus owner, gak bisa diubah dari sini.' });
      }
      await admin.db.collection('users').doc(target.uid).set({ role, email, roleExpiresAt }, { merge: true });
      return res.status(200).json({ ok: true, email, role, roleExpiresAt });
    } catch (e) {
      if (e && e.code === 'auth/user-not-found') {
        return res.status(404).json({ error: 'User dengan email itu belum terdaftar. Minta dia daftar dulu.' });
      }
      return res.status(500).json({ error: 'Gagal mengubah role: ' + explainError(e) });
    }
  }

  if (action === 'ban-user' || action === 'unban-user') {
    const email = String(body.email || '').trim().toLowerCase();
    if (!email) return res.status(400).json({ error: 'Email target wajib diisi.' });
    const banned = action === 'ban-user';
    const reason = banned ? String(body.reason || '').trim().slice(0, 200) : '';

    try {
      const target = await admin.auth.getUserByEmail(email);
      const snap = await admin.db.collection('users').doc(target.uid).get();
      if (snap.exists && snap.data().role === 'owner') {
        return res.status(400).json({ error: 'Target berstatus owner, gak bisa diban dari sini.' });
      }
      await admin.db.collection('users').doc(target.uid).set({
        banned,
        banReason: banned ? reason : null,
        bannedAt: banned ? Date.now() : null
      }, { merge: true });

      if (banned) {
        // Paksa sesi aktif dia logout di request berikutnya (ID token lama jadi gak valid lagi).
        try { await admin.auth.revokeRefreshTokens(target.uid); } catch { /* best-effort */ }
      }

      return res.status(200).json({ ok: true, email, banned, banReason: reason });
    } catch (e) {
      if (e && e.code === 'auth/user-not-found') {
        return res.status(404).json({ error: 'User dengan email itu belum terdaftar.' });
      }
      return res.status(500).json({ error: 'Gagal mengubah status ban: ' + explainError(e) });
    }
  }

  if (action === 'smm-balance') {
    if (!process.env.FAYUPEDIA_API_KEY || !process.env.FAYUPEDIA_API_ID) {
      return res.status(500).json({ error: 'FAYUPEDIA_API_KEY / FAYUPEDIA_API_ID belum diset di Environment Variable.' });
    }
    try {
      const apiBase = process.env.FAYUPEDIA_API_BASE || 'https://fayupedia.id/api';
      const balanceUrl = process.env.FAYUPEDIA_BALANCE_URL || (apiBase + '/balance');
      const params = new URLSearchParams({
        api_id: process.env.FAYUPEDIA_API_ID,
        api_key: process.env.FAYUPEDIA_API_KEY
      });
      const upstream = await fetch(balanceUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: params.toString()
      });
      const data = await upstream.json().catch(() => null);
      if (!upstream.ok || !data || data.error) {
        return res.status(502).json({ error: 'Gagal ambil saldo: ' + (data?.error || ('HTTP ' + upstream.status)) });
      }
      return res.status(200).json({ ok: true, balance: data.balance, currency: data.currency || 'IDR' });
    } catch (e) {
      return res.status(500).json({ error: 'Gagal menghubungi panel: ' + explainError(e) });
    }
  }

  if (action === 'smm-orders') {
    try {
      const snap = await admin.db.collection('smm_orders').orderBy('createdAt', 'desc').limit(100).get();
      const orderIds = [];
      const orders = snap.docs.map(d => {
        const v = d.data();
        orderIds.push(v.orderId);
        return { ...v, id: d.id };
      });

      // Refresh status sekalian dari panel (best-effort, gak gagalin response
      // kalau panel lagi error) biar admin liat status terbaru tiap transaksi.
      // Endpoint /api/status FAYUPEDIA cuma terima 1 id per request (bukan
      // batch), jadi di-loop paralel, dibatasi 20 transaksi terbaru biar
      // gak kena timeout serverless function.
      if (orderIds.length && process.env.FAYUPEDIA_API_KEY && process.env.FAYUPEDIA_API_ID) {
        const apiBase = process.env.FAYUPEDIA_API_BASE || 'https://fayupedia.id/api';
        const statusUrl = process.env.FAYUPEDIA_STATUS_URL || (apiBase + '/status');
        const toRefresh = orders.filter(o => o.status !== 'menunggu_acc' && o.status !== 'ditolak').slice(0, 20);
        await Promise.all(toRefresh.map(async (o) => {
          try {
            const params = new URLSearchParams({
              api_id: process.env.FAYUPEDIA_API_ID,
              api_key: process.env.FAYUPEDIA_API_KEY,
              id: String(o.orderId)
            });
            const upstream = await fetch(statusUrl, {
              method: 'POST',
              headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
              body: params.toString()
            });
            const data = await upstream.json().catch(() => null);
            if (upstream.ok && data && data.order_status) o.status = data.order_status;
          } catch { /* best-effort, tampilin status lama kalau 1 order gagal refresh */ }
        }));
      }

      return res.status(200).json({ ok: true, orders });
    } catch (e) {
      return res.status(500).json({ error: 'Gagal membaca transaksi: ' + explainError(e) });
    }
  }

  if (action === 'smm-approve' || action === 'smm-reject') {
    const id = String(body.id || '').trim();
    if (!id || id.includes('/')) return res.status(400).json({ error: 'ID order tidak valid.' });
    const ref = admin.db.collection('smm_orders').doc(id);

    // Klaim order secara atomik supaya gak bisa di-ACC/tolak dobel.
    let order;
    try {
      order = await admin.db.runTransaction(async (t) => {
        const snap = await t.get(ref);
        if (!snap.exists) return { err: 'Order tidak ditemukan.' };
        const v = snap.data();
        if (v.status !== 'menunggu_acc') return { err: 'Order ini sudah diproses (status: ' + v.status + ').' };
        t.update(ref, { status: 'diproses_admin' });
        return { v };
      });
    } catch (e) {
      return res.status(500).json({ error: 'Gagal memproses order: ' + explainError(e) });
    }
    if (order.err) return res.status(409).json({ error: order.err });
    const v = order.v;

    if (action === 'smm-reject') {
      try {
        await ref.update({ status: 'ditolak', rejectedAt: Date.now() });
        if (v.uid && v.weekStart) {
          try { await refundSmmUsage(v.uid, v.weekStart); } catch { /* best-effort */ }
        }
        // FREE: saldo yang ditahan saat order dibuat dikembalikan ke wallet.
        if (v.uid && v.price > 0) {
          try {
            const wref = admin.db.collection('wallets').doc(v.uid);
            await admin.db.runTransaction(async (t) => {
              const wsnap = await t.get(wref);
              const bal = wsnap.exists && typeof wsnap.data().balance === 'number' ? wsnap.data().balance : 0;
              t.set(wref, { balance: bal + v.price }, { merge: true });
            });
          } catch { /* best-effort */ }
        }
        return res.status(200).json({ ok: true, status: 'ditolak' });
      } catch (e) {
        return res.status(500).json({ error: 'Gagal menolak order: ' + explainError(e) });
      }
    }

    // smm-approve -> kirim ke panel FAYUPEDIA (pakai helper bersama, sama dengan yang dipakai
    // auto-submit order FREE di api/system.js supaya perilakunya konsisten)
    const revert = async () => { try { await ref.update({ status: 'menunggu_acc' }); } catch { /* best-effort */ } };
    try {
      const submit = await submitSmmOrder({ serviceId: v.serviceId, link: v.link, quantity: v.quantity });
      if (!submit.ok) {
        await revert();
        return res.status(502).json({ error: submit.error });
      }
      await ref.update({ status: 'pending', panelOrderId: submit.orderId, approvedAt: Date.now() });
      return res.status(200).json({ ok: true, status: 'pending', order: submit.orderId });
    } catch (e) {
      await revert();
      return res.status(500).json({ error: 'Gagal menghubungi panel: ' + explainError(e) });
    }
  }

  if (action === 'wallet-lookup' || action === 'wallet-adjust' || action === 'limit-adjust') {
    const email = String(body.email || '').trim().toLowerCase();
    if (!email) return res.status(400).json({ error: 'Email target wajib diisi.' });
    const LIMIT_FIELDS = { react: 'bonus_usage', amprem: 'bonus_amprem_usage', smm: 'bonus_smm', api: 'bonus_api_usage' };
    const LIMIT_NAMES = { react: 'ZeeReact', amprem: 'AM Premium', smm: 'Suntik Sosmed', api: 'REST API' };

    let amount = 0;
    if (action !== 'wallet-lookup') {
      amount = Math.trunc(Number(body.amount));
      const max = action === 'wallet-adjust' ? 10000000 : 10000;
      if (!Number.isFinite(amount) || amount === 0 || Math.abs(amount) > max) {
        return res.status(400).json({ error: 'Jumlah harus angka bulat tidak nol, maksimal ' + max.toLocaleString('id-ID') + '. Pakai minus untuk mengurangi.' });
      }
    }
    const type = String(body.type || '');
    if (action === 'limit-adjust' && !LIMIT_FIELDS[type]) {
      return res.status(400).json({ error: 'Tipe limit harus react, amprem, smm, atau api.' });
    }

    try {
      const target = await admin.auth.getUserByEmail(email);
      const wref = admin.db.collection('wallets').doc(target.uid);
      const num = (v) => (typeof v === 'number' && Number.isFinite(v) ? v : 0);
      const shape = (w) => ({
        balance: num(w.balance),
        bonus: { react: num(w.bonus_usage), amprem: num(w.bonus_amprem_usage), smm: num(w.bonus_smm), api: num(w.bonus_api_usage) }
      });

      if (action === 'wallet-lookup') {
        const w = await wref.get();
        return res.status(200).json({ ok: true, email, ...shape(w.exists ? w.data() : {}) });
      }

      const out = await admin.db.runTransaction(async (t) => {
        const w = await t.get(wref);
        const cur = w.exists ? w.data() : {};
        const field = action === 'wallet-adjust' ? 'balance' : LIMIT_FIELDS[type];
        const before = num(cur[field]);
        const after = before + amount;
        if (after < 0) return { err: 'Hasil tidak boleh minus (nilai sekarang ' + before.toLocaleString('id-ID') + ').' };
        t.set(wref, { [field]: after }, { merge: true });
        // Catatan audit: siapa/apa yang diubah manual, buat jaga-jaga kalau ada sengketa.
        t.set(admin.db.collection('wallet_adjustments').doc(), {
          uid: target.uid, email, kind: action === 'wallet-adjust' ? 'saldo' : 'limit:' + type,
          amount, before, after, createdAt: Date.now()
        });
        return { ok: true, state: shape({ ...cur, [field]: after }), before, after };
      });
      if (out.err) return res.status(400).json({ error: out.err });
      return res.status(200).json({
        ok: true, email, ...out.state, before: out.before, after: out.after,
        label: action === 'wallet-adjust' ? 'Saldo' : 'Limit ' + LIMIT_NAMES[type]
      });
    } catch (e) {
      if (e && e.code === 'auth/user-not-found') {
        return res.status(404).json({ error: 'User dengan email itu belum terdaftar.' });
      }
      return res.status(500).json({ error: 'Gagal memproses: ' + explainError(e) });
    }
  }

  if (action === 'stats') {
    try {
      const db = admin.db;
      // --- user ---
      const usnap = await db.collection('users').select('role', 'roleExpiresAt', 'banned').limit(20000).get();
      const users = { total: usnap.size, owner: 0, premium: 0, free: 0, banned: 0 };
      usnap.docs.forEach(d => {
        const data = d.data();
        const r = effectiveRoleData(data).role;
        if (r === 'owner') users.owner++; else if (r === 'premium') users.premium++; else users.free++;
        if (data.banned) users.banned++;
      });

      // --- saldo & Store ---
      const wallet = { totalBalance: 0, holders: 0, totalDeposited: 0, depositCount: 0, totalSpent: 0, purchaseCount: 0 };
      try {
        const ws = await db.collection('wallets').select('balance').limit(20000).get();
        ws.docs.forEach(d => { const b = d.data().balance; if (typeof b === 'number' && b > 0) { wallet.totalBalance += b; wallet.holders++; } });
        const dsn = await db.collection('deposits').where('status', '==', 'paid').select('amount').limit(20000).get();
        dsn.docs.forEach(d => { wallet.totalDeposited += Number(d.data().amount) || 0; wallet.depositCount++; });
        const ps = await db.collection('purchases').select('price').limit(20000).get();
        ps.docs.forEach(d => { wallet.totalSpent += Number(d.data().price) || 0; wallet.purchaseCount++; });
        // Order Suntik Sosmed FREE yang dibayar dari saldo (ditolak = sudah di-refund, gak dihitung).
        const sm = await db.collection('smm_orders').where('paidWithBalance', '==', true).select('price', 'status').limit(20000).get();
        sm.docs.forEach(d => { const o = d.data(); if (o.status !== 'ditolak') { wallet.totalSpent += Number(o.price) || 0; wallet.purchaseCount++; } });
      } catch { /* koleksi belum ada / gagal baca: tampilkan 0 */ }

      // --- pemakaian fitur ---
      const totalSnap = await db.collection('stats').doc('features').get();
      const total = (totalSnap.exists && totalSnap.data().total) || {};
      const dates = [];
      for (let i = 0; i < 14; i++) {
        dates.push(new Date(Date.now() + 7 * 3600 * 1000 - i * 86400000).toISOString().slice(0, 10));
      }
      const daySnaps = await db.getAll(...dates.map(dt => db.collection('stats_daily').doc(dt)));
      const days = daySnaps.map((sn, i) => {
        const dd = sn.exists ? sn.data() : {};
        return { date: dates[i], features: dd.features || {}, active: Object.keys(dd.users || {}).length };
      });
      const sumDays = (n, key) => days.slice(0, n).reduce((a, x) => a + (x.features[key] || 0), 0);

      const features = Object.keys(total).filter(k => k !== '_all').map(k => ({
        key: k, count: total[k] || 0, today: sumDays(1, k), week: sumDays(7, k)
      })).sort((a, b) => b.count - a.count);

      return res.status(200).json({
        ok: true,
        users,
        wallet,
        totalUses: total._all || 0,
        todayUses: sumDays(1, '_all'),
        todayActive: days[0].active,
        features,
        days: days.slice(0, 7).reverse().map(x => ({ date: x.date, uses: x.features._all || 0, active: x.active }))
      });
    } catch (e) {
      return res.status(500).json({ error: 'Gagal membaca statistik: ' + explainError(e) });
    }
  }

  if (action === 'get-announcement') {
    try {
      const snap = await admin.db.collection('config').doc('announcement').get();
      const data = snap.exists ? snap.data() : {};
      return res.status(200).json({ ok: true, text: data.text || '', enabled: !!data.enabled, updatedAt: data.updatedAt || null });
    } catch (e) {
      return res.status(500).json({ error: 'Gagal membaca pengumuman: ' + explainError(e) });
    }
  }

  if (action === 'set-announcement') {
    const text = String(body.text || '').trim().slice(0, 500);
    const enabled = !!body.enabled && text.length > 0;
    try {
      const updatedAt = Date.now();
      await admin.db.collection('config').doc('announcement').set({ text, enabled, updatedAt }, { merge: true });
      return res.status(200).json({ ok: true, text, enabled, updatedAt });
    } catch (e) {
      return res.status(500).json({ error: 'Gagal menyimpan pengumuman: ' + explainError(e) });
    }
  }

  if (action === 'get-maintenance') {
    try {
      const snap = await admin.db.collection('config').doc('maintenance').get();
      const data = snap.exists ? snap.data() : {};
      const raw = (data && data.features) || {};
      const features = Object.entries(MAINT_FEATURES).map(([key, label]) => ({
        key, label, on: !!(raw[key] && raw[key].on), message: String((raw[key] && raw[key].message) || '')
      }));
      return res.status(200).json({ ok: true, features, updatedAt: data.updatedAt || null });
    } catch (e) {
      return res.status(500).json({ error: 'Gagal membaca status maintenance: ' + explainError(e) });
    }
  }

  if (action === 'set-maintenance') {
    // body.features = { <kunci>: { on: bool, message?: string } }. Kunci yang tidak dikenal diabaikan,
    // kunci yang tidak dikirim dianggap OFF (dokumen ditimpa utuh supaya state selalu sama dengan layar admin).
    const input = (body.features && typeof body.features === 'object') ? body.features : {};
    const features = {};
    for (const key of Object.keys(MAINT_FEATURES)) {
      const f = input[key];
      if (f && f.on) features[key] = { on: true, message: String(f.message || '').trim().slice(0, 200) };
    }
    try {
      const updatedAt = Date.now();
      await admin.db.collection('config').doc('maintenance').set({ features, updatedAt });
      resetMaintenanceCache();
      return res.status(200).json({ ok: true, active: Object.keys(features), updatedAt });
    } catch (e) {
      return res.status(500).json({ error: 'Gagal menyimpan status maintenance: ' + explainError(e) });
    }
  }

  // ---- Nokos (sewa nomor OTP) -- semua di bawah ini CUMA panel admin, tidak diekspos ke
  // user biasa sama sekali (lihat api/system.js -> action=nokos buat fitur user: order/
  // status/resend/cancel Nomor WA). Fungsi upstream (ditzProfile dkk) ada di api/_nokos.js.
  if (action === 'nokos-profile') {
    const r = await ditzProfile();
    if (!r.ok) return res.status(502).json({ error: r.error });
    return res.status(200).json({ ok: true, data: r.data });
  }

  if (action === 'nokos-countries') {
    const r = await ditzCountries(body.server);
    if (!r.ok) return res.status(502).json({ error: r.error });
    return res.status(200).json({ ok: true, data: r.data });
  }

  if (action === 'nokos-services') {
    const r = await ditzServices(body.server, body.country, body.service);
    if (!r.ok) return res.status(502).json({ error: r.error });
    return res.status(200).json({ ok: true, data: r.data });
  }

  if (action === 'nokos-operators') {
    const r = await ditzOperators(body.server, body.country);
    if (!r.ok) return res.status(502).json({ error: r.error });
    return res.status(200).json({ ok: true, data: r.data });
  }

  if (action === 'nokos-history') {
    // Riwayat ASLI dari akun Ditznesia (master), bukan data internal Firestore -- buat
    // rekonsiliasi saldo master vs yang kepake. Lihat 'nokos-orders' buat data internal.
    const r = await ditzHistory(body.limit);
    if (!r.ok) return res.status(502).json({ error: r.error });
    return res.status(200).json({ ok: true, data: r.data });
  }

  if (action === 'nokos-deposit-create') {
    const nominal = Number(body.nominal);
    if (!Number.isFinite(nominal) || nominal < 1000) {
      return res.status(400).json({ error: 'Nominal minimal Rp1.000.' });
    }
    const r = await ditzDepositCreate(nominal, body.code);
    if (!r.ok) return res.status(502).json({ error: r.error });
    return res.status(200).json({ ok: true, data: r.data });
  }

  if (action === 'nokos-deposit-status') {
    if (!body.id) return res.status(400).json({ error: 'id deposit wajib diisi.' });
    const r = await ditzDepositStatus(body.id);
    if (!r.ok) return res.status(502).json({ error: r.error });
    return res.status(200).json({ ok: true, data: r.data });
  }

  if (action === 'nokos-deposit-cancel') {
    if (!body.id) return res.status(400).json({ error: 'id deposit wajib diisi.' });
    const r = await ditzDepositCancel(body.id);
    if (!r.ok) return res.status(502).json({ error: r.error });
    return res.status(200).json({ ok: true, data: r.data });
  }

  if (action === 'nokos-deposit-history') {
    const r = await ditzDepositHistory(body.limit, body.status);
    if (!r.ok) return res.status(502).json({ error: r.error });
    return res.status(200).json({ ok: true, data: r.data });
  }

  if (action === 'nokos-orders') {
    // Transaksi INTERNAL (semua user, bukan cuma punya admin) -- beda dari 'nokos-history'
    // yang itu riwayat mentah akun Ditznesia. Ini buat lihat siapa beli apa di platform sendiri.
    try {
      const snap = await admin.db.collection('nokos_orders').limit(200).get();
      const orders = snap.docs.map((d) => ({ id: d.id, ...d.data() }))
        .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0))
        .slice(0, 100);
      return res.status(200).json({ ok: true, orders });
    } catch (e) {
      return res.status(500).json({ error: 'Gagal membaca transaksi Nokos: ' + explainError(e) });
    }
  }

  if (action === 'cs-threads') {
    // Daftar semua thread chat, yang punya pesan terbaru/unread duluan.
    try {
      const snap = await admin.db.collection('cs_threads').limit(300).get();
      const threads = snap.docs.map((d) => ({ id: d.id, ...d.data() }))
        .sort((a, b) => (b.lastMessageAt || 0) - (a.lastMessageAt || 0))
        .slice(0, 150);
      return res.status(200).json({ ok: true, threads });
    } catch (e) {
      return res.status(500).json({ error: 'Gagal membaca daftar chat: ' + explainError(e) });
    }
  }

  if (action === 'cs-messages') {
    const uid = String(body.uid || '').trim();
    if (!uid) return res.status(400).json({ error: 'uid wajib diisi.' });
    try {
      const threadRef = admin.db.collection('cs_threads').doc(uid);
      const msnap = await threadRef.collection('messages').orderBy('createdAt', 'desc').limit(100).get();
      const messages = msnap.docs.map((d) => ({ id: d.id, ...d.data() })).reverse();
      // Pesan user otomatis "dibaca" admin begitu thread-nya dibuka di panel.
      threadRef.set({ unreadAdmin: 0 }, { merge: true }).catch(() => {});
      return res.status(200).json({ ok: true, messages });
    } catch (e) {
      return res.status(500).json({ error: 'Gagal membaca pesan: ' + explainError(e) });
    }
  }

  if (action === 'cs-reply') {
    // Balasan admin TIDAK kena cooldown 30 detik (itu cuma buat sisi user, anti-spam).
    const uid = String(body.uid || '').trim();
    const text = String(body.message || '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').trim().slice(0, 1000);
    if (!uid) return res.status(400).json({ error: 'uid wajib diisi.' });
    if (!text) return res.status(400).json({ error: 'Pesan kosong.' });
    try {
      const threadRef = admin.db.collection('cs_threads').doc(uid);
      const now = Date.now();
      const msgRef = threadRef.collection('messages').doc();
      await msgRef.set({ from: 'admin', text, createdAt: now });
      await threadRef.set({
        lastMessage: text, lastMessageAt: now, lastFrom: 'admin',
        unreadUser: FieldValue.increment(1)
      }, { merge: true });
      return res.status(200).json({ ok: true, message: { id: msgRef.id, from: 'admin', text, createdAt: now } });
    } catch (e) {
      return res.status(500).json({ error: 'Gagal mengirim balasan: ' + explainError(e) });
    }
  }

  return res.status(400).json({ error: 'Action tidak dikenal.' });
}

function safeParse(s) {
  try { return JSON.parse(s); } catch { return {}; }
}
