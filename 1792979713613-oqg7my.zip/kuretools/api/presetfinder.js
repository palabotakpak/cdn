// Vercel Serverless Function - TikTok Preset Finder (Alight Motion)
//
// POST /api/presetfinder
//   body: { link: '<url video TikTok>' }
//
// Nyari link preset Alight Motion dari deskripsi/bio/komentar video TikTok,
// lewat scraper pihak ketiga (amfinder.web.id, respons Server-Sent Events).
//
// Wajib header Authorization: Bearer <idToken>, sama pola dengan endpoint lain.
// Tanpa limit untuk semua role (FREE/PREMIUM/OWNER), tetap wajib login.

import { getRoleFromRequest, reserveUsage, refundUsage, explainError, logFeature } from './_firebaseAdmin.js';
import { maintenanceBlock } from './_firebaseAdmin.js';

const BASE_URL = 'https://amfinder.web.id';
const FREE_LIMIT = 10;
const USAGE_COLLECTION = 'presetfinder_usage';
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '';
const BOT_UA_RE = /(curl|wget|python-requests|python-urllib|scrapy|axios\/|node-fetch|go-http-client|libwww-perl|httpclient|aiohttp|okhttp|postman|insomnia|headlesschrome|phantomjs|puppeteer|playwright|bot|crawler|spider|scraper)/i;

function isValidTikTokUrl(url) {
  const trimmed = (url || '').trim();
  return /tiktok\.com/i.test(trimmed) || /^\d{15,}$/.test(trimmed);
}

async function parseSSEStream(response) {
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop() || '';

    let currentEvent = null;
    for (const line of lines) {
      if (line.startsWith('event:')) {
        currentEvent = line.slice(6).trim();
      } else if (line.startsWith('data:')) {
        const data = line.slice(5).trim();

        if (currentEvent === 'result') {
          try { return JSON.parse(data); }
          catch { throw new Error('Respons server tidak terbaca'); }
        }
        if (currentEvent === 'error') {
          try {
            const err = JSON.parse(data);
            throw new Error(err.message || 'Terjadi kesalahan di server scraper');
          } catch (e) {
            if (e instanceof SyntaxError) throw new Error('Terjadi kesalahan, coba lagi.');
            throw e;
          }
        }
      }
    }
  }
  throw new Error('Koneksi terputus sebelum selesai, coba lagi.');
}

async function getPresetLinks(linkTiktok) {
  const url = (linkTiktok || '').trim();
  if (!isValidTikTokUrl(url)) {
    throw new Error('Link itu bukan dari TikTok. Paste link video TikTok dulu.');
  }

  const apiUrl = `${BASE_URL}/api/find?url=${encodeURIComponent(url)}`;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 55_000);

  try {
    const response = await fetch(apiUrl, {
      method: 'GET',
      headers: {
        'Accept': 'text/event-stream',
        'User-Agent': 'Mozilla/5.0 (compatible; ZeeReactPresetFinder/1.0)'
      },
      signal: controller.signal
    });

    if (!response.ok) throw new Error(`Server scraper merespons status ${response.status}`);

    const contentType = response.headers.get('content-type') || '';
    if (!contentType.includes('text/event-stream')) {
      throw new Error('Format respons dari server tidak sesuai.');
    }

    const result = await parseSSEStream(response);
    if (result.ok === false) {
      throw new Error(result.error || 'Scraper gagal memproses link ini.');
    }

    return {
      author: result.author || null,
      avatar: result.authorDetail?.avatar || null,
      video: {
        description: (result.video?.description || '').trim(),
        cover: result.video?.cover || null,
        stats: {
          views: result.video?.stats?.views ?? null,
          likes: result.video?.stats?.likes ?? null,
          comments: result.video?.stats?.comments ?? null
        }
      },
      presetLinks: (result.presetLinks || []).map(p => ({
        title: p.title || (p.type === '5mb' ? '5MB preset' : 'XML file'),
        url: p.url,
        type: p.type,
        size: p.size || null,
        ratio: p.ratio || null,
        pinned: !!p.pinned,
        byAuthor: !!p.byAuthor
      }))
    };
  } catch (e) {
    if (e.name === 'AbortError') throw new Error('Waktu tunggu habis, coba lagi.');
    throw e;
  } finally {
    clearTimeout(timeout);
  }
}

export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // --- Anti-scraping, sama seperti endpoint lain ---
  const ua = req.headers['user-agent'] || '';
  if (!ua || BOT_UA_RE.test(ua)) {
    return res.status(403).json({ error: 'Akses ditolak' });
  }
  if (ALLOWED_ORIGIN) {
    const origin = req.headers['origin'] || req.headers['referer'] || '';
    if (!origin.startsWith(ALLOWED_ORIGIN)) {
      return res.status(403).json({ error: 'Akses ditolak' });
    }
  }
  // --- end anti-scraping ---

  const { role, uid, provider, error: authError, dbError } = await getRoleFromRequest(req);
  if (!uid) {
    return res.status(401).json({ error: authError ? 'Verifikasi login gagal: ' + authError : 'Login dulu.' });
  }
  if (dbError) return res.status(500).json({ error: dbError });
  if (provider !== 'google.com' && provider !== 'password') {
    return res.status(401).json({ error: 'Metode login tidak didukung.' });
  }

  { // mode maintenance (diatur dari panel admin; OWNER tetap bisa akses)
    const mb = await maintenanceBlock('presetfinder', role);
    if (mb) return res.status(503).json(mb);
  }

  const body = typeof req.body === 'string' ? safeParse(req.body) : (req.body || {});
  const link = String(body.link || '').trim();
  if (!link) return res.status(400).json({ error: 'Link video TikTok belum diisi.' });

  await logFeature(uid, 'presetfinder');

  const unlimited = true; // semua tool di Tools Hub tanpa limit untuk semua role (FREE_LIMIT dibiarkan, tidak terpakai)

  let reserved = null;
  if (!unlimited) {
    try {
      const r = await reserveUsage(uid, FREE_LIMIT, USAGE_COLLECTION);
      if (!r.ok) {
        return res.status(429).json({
          error: 'Limit harian habis. Reset otomatis jam 00:00 WIB, atau upgrade ke premium.',
          _usage: { count: r.count, limit: FREE_LIMIT }
        });
      }
      reserved = r;
    } catch (e) {
      return res.status(500).json({ error: 'Gagal mengecek limit harian: ' + explainError(e) });
    }
  }

  const usageOut = (failed) => reserved
    ? { count: Math.max(0, reserved.count - (failed ? 1 : 0)), limit: FREE_LIMIT }
    : { count: 0, limit: null };

  try {
    const result = await getPresetLinks(link);
    return res.status(200).json({ success: true, ...result, _usage: usageOut(false) });
  } catch (e) {
    if (reserved) {
      try { await refundUsage(uid, USAGE_COLLECTION); } catch { /* best-effort */ }
    }
    return res.status(502).json({ error: e.message || 'Gagal memproses link ini.', _usage: usageOut(true) });
  }
}

function safeParse(s) {
  try { return JSON.parse(s); } catch { return {}; }
}
