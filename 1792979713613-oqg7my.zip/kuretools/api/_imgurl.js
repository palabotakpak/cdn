// Helper Gambar ke URL (BUKAN serverless function: prefix underscore = tidak dihitung Vercel).
// Dipanggil dari api/ttdl.js lewat body { action:'imgurl', mime, data } (data = base64)
// supaya jumlah Serverless Function tetap di bawah limit 12 (Vercel Hobby plan).
//
// Gambar di-upload lalu URL-nya dikembalikan. Dicoba berurutan sampai ada yang berhasil:
// imgbb (permanen, cuma jalan kalau env IMGBB_API_KEY diset) -> 0x0.st (30 hari-1 tahun) ->
// uguu.se (3 jam) -> tmpfiles.org (1 jam) -> catbox.moe (permanen) -> litterbox (72 jam).
// catbox & litterbox taruh belakang karena sering memblokir IP server/datacenter (balas
// "Invalid uploader"), tapi tetap dicoba gratis buat jaga-jaga.
// Kalau semua gagal, pesan error memuat alasan tiap host supaya gampang dilacak.
// Batas body Vercel 4.5MB, jadi ukuran gambar dibatasi ~3MB (client sudah auto-kompres).

export const MAX_IMAGE_BYTES = 3 * 1024 * 1024;

const TYPES = {
  'image/jpeg': { ext: 'jpg',  magic: (b) => b[0] === 0xFF && b[1] === 0xD8 && b[2] === 0xFF },
  'image/png':  { ext: 'png',  magic: (b) => b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4E && b[3] === 0x47 },
  'image/gif':  { ext: 'gif',  magic: (b) => b[0] === 0x47 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x38 },
  'image/webp': { ext: 'webp', magic: (b) => b.length > 12 && b.toString('ascii', 0, 4) === 'RIFF' && b.toString('ascii', 8, 12) === 'WEBP' }
};

// Validasi input, return { error } atau { buffer, mime, ext }.
export function prepareImage({ mime, data }) {
  const cfg = TYPES[String(mime || '').toLowerCase()];
  if (!cfg) return { error: 'Format gambar tidak didukung. Pakai JPG, PNG, WEBP, atau GIF.' };

  const b64 = String(data || '').replace(/^data:[^,]*,/, '');
  if (!b64) return { error: 'Gambar belum dipilih.' };

  const buffer = Buffer.from(b64, 'base64');
  if (!buffer.length) return { error: 'Data gambar kosong atau rusak.' };
  if (buffer.length > MAX_IMAGE_BYTES) return { error: 'Gambar terlalu besar (maksimal 3 MB).' };
  if (!cfg.magic(buffer)) return { error: 'Isi file bukan gambar yang valid.' };

  return { buffer, mime: String(mime).toLowerCase(), ext: cfg.ext };
}

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
const PER_HOST_TIMEOUT_MS = 12000; // 4 host x 12 dtk < maxDuration 60 dtk

function snip(t) {
  return String(t || '').replace(/\s+/g, ' ').trim().slice(0, 80);
}

function makeForm(fields, fileField, { buffer, mime, ext }) {
  const form = new FormData();
  for (const [k, v] of Object.entries(fields)) form.append(k, v);
  form.append(fileField, new Blob([buffer], { type: mime }), `img-${Date.now()}.${ext}`);
  return form;
}

async function post(url, form) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'User-Agent': UA, 'Accept': '*/*' },
    body: form,
    signal: AbortSignal.timeout(PER_HOST_TIMEOUT_MS)
  });
  const text = (await res.text()).trim();
  return { res, text };
}

// Host yang membalas teks polos berisi URL (catbox, litterbox, 0x0.st).
// fileField beda-beda per host: catbox/litterbox pakai 'fileToUpload', 0x0.st pakai 'file'.
async function textHost(url, fields, fileField, img) {
  const { res, text } = await post(url, makeForm(fields, fileField, img));
  if (!res.ok || !/^https?:\/\/\S+$/i.test(text)) throw new Error(`HTTP ${res.status} ${snip(text)}`.trim());
  return text;
}

// ImgBB: perlu API key gratis (daftar di api.imgbb.com, gak ada biaya), tapi gak ikut
// memblokir IP server/datacenter kayak catbox, dan link-nya permanen. Opsional: kalau
// env IMGBB_API_KEY gak diset, host ini dilewati otomatis (tidak dihitung sebagai gagal).
async function imgbbHost(img) {
  const key = process.env.IMGBB_API_KEY;
  if (!key) throw new Error('IMGBB_API_KEY belum diset (lewati)');
  const { res, text } = await post(`https://api.imgbb.com/1/upload?key=${encodeURIComponent(key)}`, makeForm({}, 'image', img));
  let json;
  try { json = JSON.parse(text); } catch { throw new Error(`HTTP ${res.status} ${snip(text)}`.trim()); }
  const url = json?.data?.url;
  if (!res.ok || !json?.success || !url) throw new Error(`HTTP ${res.status} ${snip(json?.error?.message || text)}`.trim());
  return url;
}

// Urutan: host yang ramah IP server/datacenter duluan (ImgBB kalau key ada, lalu 0x0.st,
// uguu, tmpfiles), catbox/litterbox diletakkan terakhir karena sering memblokir IP
// Vercel (balas "Invalid uploader") -- tetap dicoba (gratis, gagalnya cepat, bukan
// nunggu timeout) buat jaga-jaga kalau suatu saat gak diblokir lagi.
const HOSTS = [
  {
    name: 'imgbb',
    expires: null,
    run: imgbbHost
  },
  {
    name: '0x0.st',
    expires: '30 hari - 1 tahun (tergantung ukuran)',
    run: (img) => textHost('https://0x0.st', {}, 'file', img)
  },
  {
    name: 'uguu',
    expires: '3 jam',
    run: async (img) => {
      const { res, text } = await post('https://uguu.se/upload', makeForm({}, 'files[]', img));
      let url = null;
      try { url = JSON.parse(text)?.files?.[0]?.url || null; } catch { /* bukan JSON */ }
      if (!url) url = (text.match(/https?:\/\/[^\s"'\\]+/) || [])[0] || null;
      if (!res.ok || !url) throw new Error(`HTTP ${res.status} ${snip(text)}`.trim());
      return url;
    }
  },
  {
    name: 'tmpfiles',
    expires: '1 jam',
    run: async (img) => {
      const { res, text } = await post('https://tmpfiles.org/api/v1/upload', makeForm({}, 'file', img));
      let url = null;
      try { url = JSON.parse(text)?.data?.url || null; } catch { /* bukan JSON */ }
      if (!res.ok || !url) throw new Error(`HTTP ${res.status} ${snip(text)}`.trim());
      // Link tampilan -> link file langsung.
      return url.replace('http://', 'https://').replace('tmpfiles.org/', 'tmpfiles.org/dl/');
    }
  },
  {
    name: 'catbox',
    expires: null,
    run: (img) => textHost('https://catbox.moe/user/api.php', { reqtype: 'fileupload' }, 'fileToUpload', img)
  },
  {
    name: 'litterbox',
    expires: '72 jam',
    run: (img) => textHost('https://litterbox.catbox.moe/resources/internals/api.php', { reqtype: 'fileupload', time: '72h' }, 'fileToUpload', img)
  }
];

export async function uploadImage(img) {
  const errors = [];
  for (const h of HOSTS) {
    try {
      const url = await h.run(img);
      return { url, host: h.name, expires: h.expires };
    } catch (e) {
      const why = e && e.name === 'TimeoutError' ? 'timeout' : snip(e && e.message);
      errors.push(`${h.name}: ${why || 'gagal'}`);
    }
  }
  throw new Error('Semua server upload gagal (' + errors.join('; ') + ').');
}
