// Vercel Serverless Function - gabungan health check + announcement + leaderboard Blok Blast
// Digabung dari api/health.js + api/announcement.js (+ leaderboard game) supaya jumlah total
// Serverless Function tetap di bawah limit 12 (Vercel Hobby plan).
//
// Routing:
//   GET  /api/announcement        -> (rewrite) action=announcement (default)
//   GET  /api/maintenance         -> (rewrite) action=maintenance (daftar fitur yang lagi maintenance, publik)
//   GET  /api/health               -> (rewrite) action=health
//   GET  /api/leaderboard          -> (rewrite) action=leaderboard (ambil skor)
//   POST /api/leaderboard          -> (rewrite) action=leaderboard (kirim skor)
//   GET/POST /api/wallet           -> (rewrite) action=wallet (saldo, deposit QRIS, Store limit & premium)
//   GET  /api/system?action=xxx    -> akses langsung juga bisa
//
// CATATAN: Global Chat TIDAK lewat sini. Global Chat pakai Supabase sendiri
// (auth anonim + Postgres + Realtime), jalan full dari browser tanpa lewat
// /api/*, jadi gak nambah Serverless Function sama sekali. Lihat public/chat.html.

import { handleWallet, logTransaction } from './_wallet.js';
import { submitSmmOrder } from './_smm.js';
import { NOKOS_WA_PRICE, NOKOS_SERVERS, orderNokosWa, statusNokos, resendNokos, cancelNokos } from './_nokos.js';
import {
  prepareDb, getDbId, getAdminServices, getAdminInitError, describeAdminConfig, explainError,
  getRoleFromRequest, logFeature, maintenanceBlock, getMaintenance, MAINT_FEATURES
} from './_firebaseAdmin.js';
import { FieldValue } from 'firebase-admin/firestore';

// ---------- Customer Service (chat user <-> admin) ----------
// 1 thread per uid: cs_threads/{uid} (metadata) + cs_threads/{uid}/messages/{autoId} (isi chat).
// Cooldown kirim pesan USER dicek di server (bukan cuma di frontend) supaya gak bisa di-bypass.
const CS_COOLDOWN_MS = 30 * 1000;
const CS_MSG_MAX_LEN = 500;
const CS_HISTORY_LIMIT = 50;

async function handleCs(req, res) {
  const { uid, email, error: authError } = await getRoleFromRequest(req);
  if (!uid) {
    return res.status(401).json({ error: authError || 'Login dulu buat pakai Customer Service.' });
  }

  const admin2 = getAdminServices();
  if (!admin2) {
    return res.status(500).json({ error: 'Firebase Admin belum dikonfigurasi: ' + (getAdminInitError() || 'env var kosong') });
  }
  const threadRef = admin2.db.collection('cs_threads').doc(uid);

  if (req.method === 'GET') {
    try {
      const [tsnap, msnap] = await Promise.all([
        threadRef.get(),
        threadRef.collection('messages').orderBy('createdAt', 'desc').limit(CS_HISTORY_LIMIT).get()
      ]);
      const tdata = tsnap.exists ? tsnap.data() : {};
      const messages = msnap.docs.map((d) => ({ id: d.id, ...d.data() })).reverse();
      const lastUserAt = tdata.lastUserMessageAt || 0;
      const cooldownRemaining = Math.max(0, Math.ceil((lastUserAt + CS_COOLDOWN_MS - Date.now()) / 1000));

      // Pesan dari admin sudah "dibaca" user begitu dia buka/refresh chat-nya.
      if ((tdata.unreadUser || 0) > 0) {
        threadRef.set({ unreadUser: 0 }, { merge: true }).catch(() => {});
      }

      return res.status(200).json({ messages, cooldownRemaining, cooldownSeconds: CS_COOLDOWN_MS / 1000 });
    } catch (e) {
      return res.status(500).json({ error: 'Gagal memuat chat: ' + explainError(e) });
    }
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method tidak didukung.' });
  }

  const body = req.body || {};
  const text = String(body.message || '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').trim().slice(0, CS_MSG_MAX_LEN);
  if (!text) {
    return res.status(400).json({ error: 'Pesan kosong.' });
  }

  try {
    const out = await admin2.db.runTransaction(async (t) => {
      const tsnap = await t.get(threadRef);
      const tdata = tsnap.exists ? tsnap.data() : {};
      const lastUserAt = tdata.lastUserMessageAt || 0;
      const remainMs = lastUserAt + CS_COOLDOWN_MS - Date.now();
      if (remainMs > 0) {
        return { cooldown: Math.ceil(remainMs / 1000) };
      }

      const now = Date.now();
      const msgRef = threadRef.collection('messages').doc();
      t.set(msgRef, { from: 'user', text, createdAt: now });
      t.set(threadRef, {
        uid, email: email || tdata.email || '',
        lastMessage: text, lastMessageAt: now, lastFrom: 'user',
        lastUserMessageAt: now,
        unreadAdmin: FieldValue.increment(1),
        createdAt: tdata.createdAt || now
      }, { merge: true });

      return { ok: true, id: msgRef.id, createdAt: now };
    });

    if (out.cooldown) {
      return res.status(429).json({ error: `Tunggu ${out.cooldown} detik lagi sebelum kirim pesan baru.`, cooldownRemaining: out.cooldown });
    }
    return res.status(200).json({ ok: true, message: { id: out.id, from: 'user', text, createdAt: out.createdAt }, cooldownRemaining: CS_COOLDOWN_MS / 1000 });
  } catch (e) {
    return res.status(500).json({ error: 'Gagal mengirim pesan: ' + explainError(e) });
  }
}

const LB_COLLECTION = 'blokblast_leaderboard';
const LB_MAX_NAME_LEN = 16;
const LB_LIMIT = 20;

function lbSanitizeName(raw) {
  if (typeof raw !== 'string') return '';
  let clean = raw.replace(/<[^>]*>/g, '').replace(/[\u0000-\u001F\u007F]/g, '').trim();
  return clean.slice(0, LB_MAX_NAME_LEN);
}

function lbDocId(name) {
  // ID dokumen = nama yang dinormalisasi (lowercase, karakter aman) supaya
  // 1 nama = 1 slot (skor terbaik), tanpa duplikat karena beda kapitalisasi.
  const norm = name.toLowerCase().replace(/[^a-z0-9_\-\s]/g, '').trim().replace(/\s+/g, '_');
  return norm.slice(0, LB_MAX_NAME_LEN) || 'anon';
}

// ---------- Suntik Sosmed (proxy ke FAYU PEDIA SMM Panel) ----------
// Jatah gratis DIHAPUS. Semua role (FREE/PREMIUM/OWNER) SELALU bayar dari saldo per `unit`
// (lihat SMM_FREE_PRICING), kelipatan unit, lalu LANGSUNG auto-submit ke panel -- gak ada lagi
// jalur nunggu ACC admin buat order baru.
// API key & service ID disimpan di Environment Variable Vercel, TIDAK PERNAH dikirim ke client.

// FREE (bukan premium/owner): boleh order juga, TAPI bayar dari saldo per `unit` (bukan jatah
// mingguan gratis). Jumlah wajib kelipatan `unit`. Harga & batas per layanan diatur di sini.
// maxQty untuk tiktok_followers & tiktok_views belum ditentukan user, jadi dipasang nilai
// wajar sementara -- sesuaikan di sini kalau mau diubah.
const SMM_FREE_PRICING = {
  tiktok_likes:     { unit: 100,  pricePerUnit: 2000, maxQty: 1000000 },
  wa_channel:       { unit: 100,  pricePerUnit: 1000, maxQty: 10000 },
  tiktok_followers: { unit: 100,  pricePerUnit: 2000, maxQty: 100000 },
  tiktok_views:     { unit: 1000, pricePerUnit: 100,  maxQty: 10000000 }
};
// FAYUPEDIA pakai 1 path REST per aksi, dikonfirmasi dari contoh client resmi:
//   .../api/balance, .../api/services, .../api/order, .../api/status,
//   .../api/refill, .../api/refill/status
// Auth-nya DUA field sekaligus: api_id + api_key (bukan cuma 1 key).
// Field order pakai 'target' (bukan 'link'), response status pakai 'order_status'.
const SMM_API_BASE = process.env.FAYUPEDIA_API_BASE || 'https://fayupedia.id/api';
const SMM_ORDER_URL = process.env.FAYUPEDIA_ORDER_URL || (SMM_API_BASE + '/order');
const SMM_API_ID = process.env.FAYUPEDIA_API_ID || '';
const SMM_SERVICES = {
  tiktok_likes: {
    label: 'TikTok Likes',
    serviceId: process.env.FAYUPEDIA_SERVICE_TIKTOK_LIKES || '',
    linkHint: 'Link video TikTok (https://www.tiktok.com/@user/video/xxxx)'
  },
  wa_channel: {
    label: 'Followers Saluran WhatsApp',
    serviceId: process.env.FAYUPEDIA_SERVICE_WA_CHANNEL || '',
    linkHint: 'Link saluran WhatsApp (https://whatsapp.com/channel/xxxx)'
  },
  tiktok_followers: {
    label: 'TikTok Followers',
    serviceId: process.env.FAYUPEDIA_SERVICE_TIKTOK_FOLLOWERS || '1843',
    linkHint: 'Link profil TikTok (https://www.tiktok.com/@username)'
  },
  tiktok_views: {
    label: 'TikTok Views',
    serviceId: process.env.FAYUPEDIA_SERVICE_TIKTOK_VIEWS || '1824',
    linkHint: 'Link video TikTok (https://www.tiktok.com/@user/video/xxxx)'
  }
};

// ---------- Nokos (sewa nomor WA buat terima OTP, proxy ke Ditznesia) ----------
// Produk CUMA 1: "Nomor WA Indonesia", harga FLAT Rp5.000/nomor (NOKOS_WA_PRICE di _nokos.js),
// berapa pun server (1-5) yang dipilih user & berapa pun harga asli dari Ditznesia. User biasa
// cuma bisa: order, cek status, resend OTP, batal (refund Rp5.000 flat). Endpoint upstream
// lain (countries/services/operators/profile/deposit/history) CUMA lewat panel admin
// (api/admin.js -> action 'nokos-*'), tidak diekspos di sini sama sekali.
//
// Data: nokos_orders/{autoId} -> { uid, server, ditzId, number, otp, status, price (flat yang
// dibayar user), realPrice (harga asli dari Ditznesia, cuma buat referensi admin), createdAt }.
async function handleNokos(req, res) {
  const { role, uid, error: authError } = await getRoleFromRequest(req);
  if (!uid) {
    return res.status(401).json({ error: authError || 'Belum login.' });
  }
  if (req.method === 'POST') {
    const mb = await maintenanceBlock('nokos', role);
    if (mb) return res.status(503).json(mb);
  }

  const admin2 = getAdminServices();

  if (req.method === 'GET') {
    let balance = 0;
    try {
      const wsnap = await admin2.db.collection('wallets').doc(uid).get();
      balance = wsnap.exists && typeof wsnap.data().balance === 'number' ? wsnap.data().balance : 0;
    } catch { /* tampilkan 0 kalau gagal baca */ }

    let orders = [];
    try {
      const snap = await admin2.db.collection('nokos_orders').where('uid', '==', uid).limit(50).get();
      orders = snap.docs.map((d) => ({ id: d.id, ...d.data() }))
        .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0))
        .slice(0, 30)
        .map((o) => ({
          id: o.id, server: o.server, number: o.number, otp: o.otp || null,
          status: o.status, price: o.price, createdAt: o.createdAt,
          canResend: !!o.can_resend, resendWaiting: !!o.resend_waiting
        }));
    } catch { /* riwayat kosong kalau gagal baca */ }

    return res.status(200).json({
      balance, price: NOKOS_WA_PRICE,
      servers: Object.fromEntries(Object.entries(NOKOS_SERVERS).map(([k, v]) => [k, v.label])),
      orders
    });
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method tidak didukung.' });
  }

  const body = req.body || {};
  const sub = String(body.action || '');

  // ---- Order nomor WA baru ----
  if (sub === 'order') {
    const server = Number(body.server);
    if (!NOKOS_SERVERS[server]) {
      return res.status(400).json({ error: 'Server tidak valid. Pilih 1-5.' });
    }
    if (!process.env.DITZNESIA_API_KEY) {
      return res.status(500).json({ error: 'DITZNESIA_API_KEY belum diset di Environment Variable.' });
    }

    const wref = admin2.db.collection('wallets').doc(uid);
    let balanceAfter;
    try {
      const out = await admin2.db.runTransaction(async (t) => {
        const wsnap = await t.get(wref);
        const bal = wsnap.exists && typeof wsnap.data().balance === 'number' ? wsnap.data().balance : 0;
        if (bal < NOKOS_WA_PRICE) return { err: `Saldo kurang. Nomor ini Rp${NOKOS_WA_PRICE.toLocaleString('id-ID')}, saldo kamu Rp${bal.toLocaleString('id-ID')}. Isi saldo dulu di menu Saldo & Store.` };
        t.set(wref, { balance: bal - NOKOS_WA_PRICE }, { merge: true });
        return { ok: true, balance: bal - NOKOS_WA_PRICE };
      });
      if (out.err) return res.status(400).json({ error: out.err });
      balanceAfter = out.balance;
    } catch (e) {
      return res.status(500).json({ error: 'Gagal memotong saldo: ' + explainError(e) });
    }

    const result = await orderNokosWa(server);
    if (!result.ok) {
      // Upstream gagal -> kembalikan saldo, order gak pernah tersimpan.
      try {
        await admin2.db.runTransaction(async (t) => {
          const wsnap = await t.get(wref);
          const bal = wsnap.exists && typeof wsnap.data().balance === 'number' ? wsnap.data().balance : 0;
          t.set(wref, { balance: bal + NOKOS_WA_PRICE }, { merge: true });
        });
      } catch { /* best-effort */ }
      return res.status(502).json({ error: result.error + ' Saldo sudah dikembalikan.' });
    }

    const o = result.order;
    const ref = admin2.db.collection('nokos_orders').doc();
    const orderDoc = {
      uid, server, ditzId: o.id, number: o.number || null, otp: (o.otp && o.otp !== 'Waiting') ? o.otp : null,
      status: o.status || 'pending', price: NOKOS_WA_PRICE, realPrice: o.price || null,
      expiresAtMs: o.expires_at_ms || null, createdAt: Date.now()
    };
    try {
      await ref.set(orderDoc);
      await logFeature(uid, 'nokos');
      try { await logTransaction(admin2.db, uid, { type: 'nokos_order', label: 'Beli Nomor WA (server ' + server + ')', amount: -NOKOS_WA_PRICE }); } catch { /* opsional */ }
    } catch (e) {
      return res.status(500).json({ error: 'Nomor sudah dibeli dari upstream tapi gagal disimpan: ' + explainError(e) + '. Hubungi admin, jangan order ulang.' });
    }

    return res.status(200).json({
      order: { id: ref.id, server, number: orderDoc.number, otp: orderDoc.otp, status: orderDoc.status, price: NOKOS_WA_PRICE },
      balance: balanceAfter
    });
  }

  // ---- Cek status / resend / batal: semua butuh kepemilikan order (uid cocok) ----
  if (sub === 'status' || sub === 'resend' || sub === 'cancel') {
    const id = String(body.id || '');
    if (!id) return res.status(400).json({ error: 'id order wajib diisi.' });

    const ref = admin2.db.collection('nokos_orders').doc(id);
    let snap;
    try { snap = await ref.get(); } catch (e) { return res.status(500).json({ error: explainError(e) }); }
    if (!snap.exists || snap.data().uid !== uid) {
      return res.status(404).json({ error: 'Order tidak ditemukan.' });
    }
    const current = snap.data();

    if (sub === 'status') {
      const r = await statusNokos(current.ditzId);
      if (!r.ok) return res.status(502).json({ error: r.error });
      const patch = {
        status: r.data.status || current.status,
        otp: (r.data.otp && r.data.otp !== 'Waiting') ? r.data.otp : (current.otp || null),
        can_resend: !!r.data.can_resend, resend_waiting: !!r.data.resend_waiting
      };
      try { await ref.update(patch); } catch { /* best-effort */ }
      return res.status(200).json({ order: { id, number: current.number, ...patch } });
    }

    if (sub === 'resend') {
      if (current.status === 'canceled' || current.status === 'dibatalkan') {
        return res.status(400).json({ error: 'Order ini sudah dibatalkan.' });
      }
      const r = await resendNokos(current.ditzId);
      if (!r.ok) return res.status(502).json({ error: r.error });
      const patch = {
        status: r.data.status || current.status,
        otp: (r.data.otp && r.data.otp !== 'Waiting') ? r.data.otp : (current.otp || null),
        can_resend: !!r.data.can_resend, resend_waiting: !!r.data.resend_waiting
      };
      try { await ref.update(patch); } catch { /* best-effort */ }
      return res.status(200).json({ order: { id, number: current.number, ...patch } });
    }

    // sub === 'cancel'
    if (current.status === 'canceled' || current.status === 'dibatalkan') {
      return res.status(400).json({ error: 'Order ini sudah dibatalkan sebelumnya.' });
    }
    const r = await cancelNokos(current.ditzId);
    if (!r.ok) return res.status(502).json({ error: r.error });

    let balanceAfter;
    try {
      const wref = admin2.db.collection('wallets').doc(uid);
      const out = await admin2.db.runTransaction(async (t) => {
        const wsnap = await t.get(wref);
        const bal = wsnap.exists && typeof wsnap.data().balance === 'number' ? wsnap.data().balance : 0;
        // Refund harga FLAT yang dia bayar (current.price), bukan field `price` upstream.
        t.set(wref, { balance: bal + current.price }, { merge: true });
        return bal + current.price;
      });
      balanceAfter = out;
    } catch { /* saldo tetap dicoba dikembalikan manual kalau ini gagal -- lapor ke admin */ }

    try { await ref.update({ status: 'dibatalkan' }); } catch { /* best-effort */ }
    try { await logTransaction(admin2.db, uid, { type: 'nokos_refund', label: 'Refund batal Nomor WA', amount: current.price }); } catch { /* opsional */ }

    return res.status(200).json({ order: { id, status: 'dibatalkan' }, balance: balanceAfter });
  }

  return res.status(400).json({ error: 'Aksi tidak dikenal.' });
}

async function handleSmm(req, res) {
  const { role, uid, error: authError } = await getRoleFromRequest(req);
  if (!uid) {
    return res.status(401).json({ error: authError || 'Belum login.' });
  }
  if (req.method === 'POST') { // mode maintenance: order baru ditahan, lihat saldo/riwayat (GET) tetap jalan
    const mb = await maintenanceBlock('smm', role);
    if (mb) return res.status(503).json(mb);
  }
  if (req.method === 'GET') {
    try {
      let balance = 0;
      try {
        const wsnap = await getAdminServices().db.collection('wallets').doc(uid).get();
        balance = wsnap.exists && typeof wsnap.data().balance === 'number' ? wsnap.data().balance : 0;
      } catch { /* tampilkan 0 kalau gagal baca */ }

      // Riwayat order milik user ini saja (tanpa orderBy supaya gak butuh composite index).
      let orders = [];
      try {
        const admin2 = getAdminServices();
        const snap = await admin2.db.collection('smm_orders').where('uid', '==', uid).limit(50).get();
        orders = snap.docs.map(d => d.data())
          .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0))
          .slice(0, 10)
          .map(o => ({ service: o.service, quantity: o.quantity, status: o.status || 'pending', createdAt: o.createdAt, orderId: o.status === 'menunggu_acc' || o.status === 'ditolak' ? null : o.orderId }));

        // Segarkan status dari panel buat order yang sudah di-ACC (best-effort, maks 5).
        if (process.env.FAYUPEDIA_API_KEY && SMM_API_ID) {
          const statusUrl = process.env.FAYUPEDIA_STATUS_URL || (SMM_API_BASE + '/status');
          await Promise.all(orders.filter(o => o.orderId).slice(0, 5).map(async (o) => {
            try {
              const params = new URLSearchParams({ api_id: SMM_API_ID, api_key: process.env.FAYUPEDIA_API_KEY, id: String(o.orderId) });
              const up = await fetch(statusUrl, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: params.toString() });
              const dd = await up.json().catch(() => null);
              if (up.ok && dd && dd.order_status) o.status = dd.order_status;
            } catch { /* tampilin status lama */ }
          }));
        }
        orders.forEach(o => { delete o.orderId; });
      } catch { orders = []; }

      // Jatah gratis DIHAPUS -- semua role (FREE/PREMIUM/OWNER) sekarang selalu bayar dari
      // saldo & langsung auto-submit ke panel, gak ada lagi jalur nunggu ACC admin.
      return res.status(200).json({
        orders,
        payPerOrder: true,
        balance,
        services: Object.fromEntries(Object.entries(SMM_SERVICES).map(([k, v]) => {
          const fp = SMM_FREE_PRICING[k];
          return [k, { label: v.label, linkHint: v.linkHint, maxQty: fp ? fp.maxQty : 0, unit: fp ? fp.unit : null, pricePerUnit: fp ? fp.pricePerUnit : null }];
        }))
      });
    } catch (e) {
      return res.status(500).json({ error: 'Gagal cek status: ' + explainError(e) });
    }
  }

  if (req.method === 'POST') {
    const body = req.body || {};
    const serviceKey = String(body.service || '');
    const link = String(body.link || '').trim();
    const quantity = Math.floor(Number(body.quantity));

    const svc = SMM_SERVICES[serviceKey];
    if (!svc) {
      return res.status(400).json({ error: 'Layanan tidak dikenal.' });
    }
    if (!svc.serviceId) {
      return res.status(500).json({ error: 'Layanan "' + svc.label + '" belum dikonfigurasi (service ID kosong di Environment Variable).' });
    }
    if (!/^https:\/\//i.test(link) || link.length > 500) {
      return res.status(400).json({ error: 'Link tidak valid.' });
    }
    if (!Number.isFinite(quantity) || quantity < 1) {
      return res.status(400).json({ error: 'Kuantitas tidak valid.' });
    }
    if (!process.env.FAYUPEDIA_API_KEY || !SMM_API_ID) {
      return res.status(500).json({ error: 'FAYUPEDIA_API_KEY / FAYUPEDIA_API_ID belum diset di Environment Variable.' });
    }

    // Jatah gratis DIHAPUS -- semua role (FREE/PREMIUM/OWNER) selalu bayar dari saldo, gak ada
    // lagi jalur pakai jatah mingguan / nunggu ACC admin.
    const fp = SMM_FREE_PRICING[serviceKey];
    const maxQty = fp ? fp.maxQty : 0;
    const unit = fp ? fp.unit : 100;
    if (!fp || quantity < unit || quantity % unit !== 0) {
      return res.status(400).json({ error: 'Jumlah wajib kelipatan ' + unit + ' (minimal ' + unit + ') untuk order bayar saldo.' });
    }
    if (quantity > maxQty) {
      return res.status(400).json({ error: 'Maksimal ' + maxQty + ' per order.' });
    }
    const price = (quantity / unit) * fp.pricePerUnit;

    const admin2 = getAdminServices();
    const ref = admin2.db.collection('smm_orders').doc();

    // Potong saldo, lalu LANGSUNG submit ke panel. Gak perlu ACC admin sama sekali. Kalau panel
    // menolak, saldo dikembalikan dan order gak disimpan ke smm_orders.
    const wref = admin2.db.collection('wallets').doc(uid);
    let balanceAfter;
    try {
      const out = await admin2.db.runTransaction(async (t) => {
        const wsnap = await t.get(wref);
        const bal = wsnap.exists && typeof wsnap.data().balance === 'number' ? wsnap.data().balance : 0;
        if (bal < price) return { err: `Saldo kurang. Order ini Rp${price.toLocaleString('id-ID')}, saldo kamu Rp${bal.toLocaleString('id-ID')}. Isi saldo dulu di menu Saldo & Store.` };
        t.set(wref, { balance: bal - price }, { merge: true });
        return { ok: true, balance: bal - price };
      });
      if (out.err) return res.status(400).json({ error: out.err });
      balanceAfter = out.balance;
    } catch (e) {
      return res.status(500).json({ error: 'Gagal memotong saldo: ' + explainError(e) });
    }

    const submit = await submitSmmOrder({ serviceId: svc.serviceId, link, quantity });
    if (!submit.ok) {
      // Panel nolak / gagal dihubungi -> kembalikan saldo, order gak pernah tersimpan.
      try {
        await admin2.db.runTransaction(async (t) => {
          const wsnap = await t.get(wref);
          const bal = wsnap.exists && typeof wsnap.data().balance === 'number' ? wsnap.data().balance : 0;
          t.set(wref, { balance: bal + price }, { merge: true });
        });
      } catch { /* best-effort, kalau gagal refund tetap balas error ke user */ }
      return res.status(502).json({ error: submit.error + ' Saldo sudah dikembalikan.' });
    }
    await logTransaction(admin2.db, uid, { type: 'smm_order', amount: -price, label: 'Suntik Sosmed: ' + svc.label });

    const orderDoc = {
      orderId: ref.id, uid, service: svc.label, serviceId: svc.serviceId, link, quantity,
      status: 'pending', price, paidWithBalance: true,
      panelOrderId: submit.orderId, autoApproved: true, approvedAt: Date.now(),
      createdAt: Date.now()
    };
    try {
      await ref.set(orderDoc);
      await logFeature(uid, 'suntik_sosmed');
    } catch { /* order sudah terlanjur disubmit ke panel; gagal simpan log gak dibatalkan */ }

    return res.status(200).json({
      pending: false, order: ref.id, service: svc.label, quantity, price,
      balance: balanceAfter
    });
  }

  return res.status(405).json({ error: 'Method not allowed' });
}

async function handleLeaderboard(req, res) {
  await prepareDb();
  const admin = getAdminServices();
  if (!admin) {
    return res.status(500).json({ error: 'Firebase Admin belum dikonfigurasi: ' + (getAdminInitError() || 'env var kosong') });
  }
  const col = admin.db.collection(LB_COLLECTION);

  if (req.method === 'GET') {
    try {
      const snap = await col.orderBy('score', 'desc').limit(LB_LIMIT).get();
      const scores = snap.docs.map((d) => {
        const v = d.data();
        return { name: v.name, score: v.score };
      });
      // Boleh basi beberapa detik: cache di CDN Vercel biar request rame-rame gak semua nembak Firestore.
      res.setHeader('Cache-Control', 'public, max-age=5, stale-while-revalidate=30');
      return res.status(200).json({ scores });
    } catch (e) {
      return res.status(500).json({ error: 'Gagal membaca leaderboard: ' + explainError(e) });
    }
  }

  if (req.method === 'POST') {
    const payload = req.body || {};
    const name = lbSanitizeName(payload.name);
    const score = Math.floor(Number(payload.score));

    if (!name) {
      return res.status(400).json({ error: 'Nama tidak boleh kosong' });
    }
    if (!Number.isFinite(score) || score < 0 || score > 1000000) {
      return res.status(400).json({ error: 'Skor tidak valid' });
    }

    try {
      const ref = col.doc(lbDocId(name));
      await admin.db.runTransaction(async (tx) => {
        const cur = await tx.get(ref);
        if (!cur.exists || score > (cur.data().score || 0)) {
          tx.set(ref, { name, score, updatedAt: new Date().toISOString() });
        }
      });
      const snap = await col.orderBy('score', 'desc').limit(LB_LIMIT).get();
      const scores = snap.docs.map((d) => {
        const v = d.data();
        return { name: v.name, score: v.score };
      });
      return res.status(200).json({ scores });
    } catch (e) {
      return res.status(500).json({ error: 'Gagal menyimpan skor: ' + explainError(e) });
    }
  }

  return res.status(405).json({ error: 'Method not allowed' });
}

async function handleAnnouncement(req, res) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  await prepareDb();
  const admin = getAdminServices();
  if (!admin) {
    return res.status(500).json({ error: 'Firebase Admin belum dikonfigurasi: ' + (getAdminInitError() || 'env var kosong') });
  }

  try {
    const snap = await admin.db.collection('config').doc('announcement').get();
    const data = snap.exists ? snap.data() : {};
    // Pengumuman jarang berubah: cache 30 detik di CDN, kurangi hit Firestore tiap pengunjung buka halaman.
    res.setHeader('Cache-Control', 'public, max-age=30, stale-while-revalidate=120');
    return res.status(200).json({
      enabled: !!data.enabled,
      text: data.text || '',
      updatedAt: data.updatedAt || null
    });
  } catch (e) {
    return res.status(500).json({ error: 'Gagal membaca pengumuman: ' + explainError(e) });
  }
}

// Publik (tanpa login): daftar fitur yang lagi maintenance, dipakai frontend buat nandain & nahan akses.
async function handleMaintenance(req, res) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }
  const m = await getMaintenance(true);
  const features = {};
  for (const [k, f] of Object.entries(m.features)) {
    features[k] = { label: MAINT_FEATURES[k] || k, message: f.message || '' };
  }
  // Server sudah cache 10 detik (getMaintenance), CDN ikut cache biar makin ringan pas rame.
  res.setHeader('Cache-Control', 'public, max-age=5, stale-while-revalidate=30');
  return res.status(200).json({ features, updatedAt: m.updatedAt || null });
}

async function handleHealth(req, res) {
  const env = process.env;
  const cfg = describeAdminConfig();

  const out = {
    firebase_kredensial: cfg,
    env: {
      NEXADEV_KEY: env.NEXADEV_KEY ? 'ada' : 'KOSONG',
      OWNER_CODE: env.OWNER_CODE ? 'ada' : 'KOSONG',
      CAPTCHA_SECRET: env.CAPTCHA_SECRET ? 'ada' : 'KOSONG (pakai fallback dev, tidak aman)',
      ALLOWED_ORIGIN: env.ALLOWED_ORIGIN || '(kosong, tidak apa-apa)'
    }
  };

  await prepareDb();
  const admin = getAdminServices();
  if (!admin) {
    out.admin = 'GAGAL: ' + (getAdminInitError() || 'env Firebase belum lengkap');
    return res.status(500).json(out);
  }
  out.admin = 'ok (kredensial terbaca)';
  out.firestore_database_id = getDbId();

  try {
    await admin.db.collection('_health').doc('ping').get();
    out.firestore = 'ok (terhubung)';
  } catch (e) {
    out.firestore = 'GAGAL: ' + explainError(e);
  }

  try {
    await admin.auth.listUsers(1);
    out.auth = 'ok (terhubung)';
  } catch (e) {
    out.auth = 'GAGAL: ' + e.message;
  }

  const ok = out.firestore.startsWith('ok') && out.auth.startsWith('ok');
  return res.status(ok ? 200 : 500).json(out);
}

export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');

  const action = (req.query && req.query.action) || 'announcement';

  if (action === 'health') {
    return handleHealth(req, res);
  }
  if (action === 'maintenance') {
    return handleMaintenance(req, res);
  }
  if (action === 'leaderboard') {
    return handleLeaderboard(req, res);
  }
  if (action === 'smm') {
    return handleSmm(req, res);
  }
  if (action === 'nokos') {
    return handleNokos(req, res);
  }
  if (action === 'wallet') {
    return handleWallet(req, res);
  }
  if (action === 'cs') {
    return handleCs(req, res);
  }
  return handleAnnouncement(req, res);
}
