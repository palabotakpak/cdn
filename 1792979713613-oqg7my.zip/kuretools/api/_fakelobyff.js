// Helper Fake Lobby FF Maker (BUKAN serverless function: prefix underscore = tidak dihitung Vercel).
// Dipanggil dari api/ttdl.js lewat body { action:'fakelobyff', game:'ff'|'ffduo'|'ml', nickname, nickname2?, avatar? } supaya
// jumlah Serverless Function tetap di bawah limit 12 (Vercel Hobby plan).
//
// FF Solo/Duo lewat apii.nexadev.my.id (fakeff, fakeffduo), ML lewat api.nexray.eu.cc (fakelobyml).
// Responsnya bisa berupa gambar langsung (image/*) atau JSON berisi URL gambar,
// jadi parsing dibuat fleksibel: kalau gambar -> dikirim balik sebagai data URL,
// kalau JSON -> cari URL gambar di dalamnya.
//

import { fetchImageDataUrl } from './_dlproxy.js';

const API_URL = 'https://apii.nexadev.my.id/fakeff';         // ?usn=<nickname>
const DUO_API_URL = 'https://apii.nexadev.my.id/fakeffduo'; // ?nickname1=&nickname2=
export const MAX_NICK = 24;
const MAX_IMAGE_BYTES = 3 * 1024 * 1024; // jaga di bawah batas respons Vercel (4.5MB, belum termasuk base64)

// Cari URL gambar di payload JSON dengan bentuk apa pun.
function findImageUrl(node, depth = 0) {
  if (!node || depth > 4) return null;
  if (typeof node === 'string') {
    return /^https?:\/\//i.test(node) ? node : null;
  }
  if (Array.isArray(node)) {
    for (const it of node) {
      const f = findImageUrl(it, depth + 1);
      if (f) return f;
    }
    return null;
  }
  if (typeof node === 'object') {
    const keys = ['url', 'image', 'result', 'data', 'link', 'download', 'img'];
    for (const k of keys) {
      if (k in node) {
        const f = findImageUrl(node[k], depth + 1);
        if (f) return f;
      }
    }
    for (const k of Object.keys(node)) {
      const f = findImageUrl(node[k], depth + 1);
      if (f) return f;
    }
  }
  return null;
}

export async function fetchLobby(nickname) {
  return fetchMakerImage(`${API_URL}?usn=${encodeURIComponent(nickname)}`);
}

// Fake Lobby FF Duo: dua nickname. Return { error } atau { url }.
export function buildLobbyDuoUrl({ nickname, nickname2 }) {
  nickname = String(nickname || '').trim();
  nickname2 = String(nickname2 || '').trim();
  if (!nickname) return { error: 'Nickname 1 belum diisi.' };
  if (!nickname2) return { error: 'Nickname 2 belum diisi.' };
  if (nickname.length > MAX_NICK || nickname2.length > MAX_NICK) {
    return { error: `Nickname maksimal ${MAX_NICK} karakter.` };
  }
  return { url: `${DUO_API_URL}?nickname1=${encodeURIComponent(nickname)}&nickname2=${encodeURIComponent(nickname2)}` };
}

// Fake Lobby ML (Mobile Legends): api.nexray.eu.cc/maker/fakelobyml?avatar=<url gambar>&nickname=
// Return { error } atau { url }.
const ML_API_URL = 'https://api.nexray.eu.cc/maker/fakelobyml';
export function buildLobbyMlUrl({ nickname, avatar }) {
  nickname = String(nickname || '').trim();
  if (!nickname) return { error: 'Nickname belum diisi.' };
  if (nickname.length > MAX_NICK) return { error: `Nickname maksimal ${MAX_NICK} karakter.` };

  avatar = String(avatar || '').trim();
  if (!avatar) return { error: 'Link avatar belum diisi.' };
  if (avatar.length > 500 || !/^https?:\/\//i.test(avatar)) {
    return { error: 'Link avatar harus diawali http:// atau https://.' };
  }

  const q = new URLSearchParams({ avatar, nickname });
  return { url: `${ML_API_URL}?${q.toString()}` };
}

// Generik: ambil gambar dari endpoint maker mana pun (dipakai juga oleh _iqc.js).
export async function fetchMakerImage(url) {
  const res = await fetch(url, {
    method: 'GET',
    headers: {
      'Accept': 'image/*,application/json',
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    }
  });

  const ctype = (res.headers.get('content-type') || '').toLowerCase();

  if (!res.ok) {
    let msg = `Gagal mengambil data (${res.status}).`;
    if (ctype.includes('json')) {
      try {
        const j = await res.json();
        msg = j.message || j.error || j.msg || msg;
      } catch { /* abaikan */ }
    }
    throw new Error(msg);
  }

  // Kasus 1: API langsung balikin gambar.
  if (ctype.startsWith('image/')) {
    const buf = Buffer.from(await res.arrayBuffer());
    if (buf.length > MAX_IMAGE_BYTES) throw new Error('Gambar hasil terlalu besar.');
    return { image: `data:${ctype.split(';')[0]};base64,${buf.toString('base64')}` };
  }

  // Kasus 2: API balikin JSON berisi link gambar.
  const text = await res.text();
  let payload;
  try { payload = JSON.parse(text); } catch { throw new Error('Respons server tidak terbaca.'); }

  if (payload && payload.status === false) {
    throw new Error(payload.message || payload.error || 'Gagal membuat gambar.');
  }

  const imgUrl = findImageUrl(payload);
  if (!imgUrl) throw new Error('Gambar hasil tidak ditemukan di respons server.');
  // Ambil gambarnya di server -> data URL, supaya download tetap di web ini (tanpa buka link luar).
  try {
    return { image: await fetchImageDataUrl(imgUrl, MAX_IMAGE_BYTES) };
  } catch {
    return { image: imgUrl, remote: true }; // cadangan: frontend download lewat proxy /api/ttdl action 'dl'
  }
}
