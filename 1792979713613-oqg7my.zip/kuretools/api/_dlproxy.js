// Helper proxy download (BUKAN serverless function: prefix underscore = tidak dihitung Vercel).
// Dipanggil dari api/ttdl.js lewat body { action:'dl', url, filename } supaya semua tool download
// menyimpan file langsung di web ini (tanpa buka tab/web lain) dan jumlah Serverless Function
// tetap di bawah limit 12 (Vercel Hobby plan).
//
// Server mengambil file dari sumbernya lalu men-stream ke browser. Pengamanan:
//  - hanya https, tanpa kredensial, port 443, bukan localhost/.local/.internal
//  - hostname di-resolve dan DITOLAK kalau mengarah ke IP privat/loopback/link-local (anti-SSRF),
//    dicek ulang di setiap redirect (maks 4 hop)
//  - hanya tipe file media (image/*, video/*, audio/*, octet-stream), maks 100 MB
//  - opsional: env DL_ALLOWED_HOSTS (daftar domain dipisah koma) buat membatasi sumber ke
//    domain tertentu saja, contoh: "tikwm.com,tiktokcdn.com,cdninstagram.com,fbcdn.net,catbox.moe"

import dns from 'node:dns/promises';
import net from 'node:net';
import { Readable, Transform } from 'node:stream';
import { pipeline } from 'node:stream/promises';

export const DL_MAX_BYTES = 100 * 1024 * 1024;
const MAX_REDIRECTS = 4;
const FETCH_TIMEOUT_MS = 25000;
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
const OK_TYPE = /^(image|video|audio)\/|^(application|binary)\/(octet-stream|mp4|mpeg|x-mpegurl|vnd\.apple\.mpegurl)$/i;

function allowedHosts() {
  return (process.env.DL_ALLOWED_HOSTS || '').split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
}

export function isPrivateIp(ip) {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split('.').map(Number);
    return a === 0 || a === 10 || a === 127 ||
      (a === 100 && b >= 64 && b <= 127) ||
      (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168) ||
      (a === 192 && b === 0) ||
      (a === 198 && (b === 18 || b === 19)) ||
      a >= 224;
  }
  if (net.isIPv6(ip)) {
    const x = ip.toLowerCase();
    if (x === '::' || x === '::1') return true;
    if (x.startsWith('fc') || x.startsWith('fd')) return true;
    if (/^fe[89ab]/.test(x)) return true;
    if (x.startsWith('::ffff:')) {
      const m = x.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/);
      return m ? isPrivateIp(m[1]) : true;
    }
    return false;
  }
  return true;
}

export async function assertPublicHttps(urlStr) {
  let u;
  try { u = new URL(String(urlStr || '')); } catch { throw new Error('Link file tidak valid.'); }
  if (u.protocol !== 'https:') throw new Error('Link file harus https.');
  if (u.username || u.password) throw new Error('Link file tidak valid.');
  if (u.port && u.port !== '443') throw new Error('Link file tidak diizinkan.');

  const host = u.hostname.toLowerCase().replace(/^\[|\]$/g, '');
  if (host === 'localhost' || host.endsWith('.local') || host.endsWith('.internal') || host.endsWith('.localhost')) {
    throw new Error('Link file tidak diizinkan.');
  }

  const allow = allowedHosts();
  if (allow.length && !allow.some(d => host === d || host.endsWith('.' + d))) {
    throw new Error(`Sumber file (${host}) belum diizinkan.`);
  }

  if (net.isIP(host)) {
    if (isPrivateIp(host)) throw new Error('Link file tidak diizinkan.');
    return u;
  }

  let addrs;
  try { addrs = await dns.lookup(host, { all: true }); } catch { throw new Error('Sumber file tidak bisa dijangkau.'); }
  if (!addrs.length || addrs.some(a => isPrivateIp(a.address))) throw new Error('Link file tidak diizinkan.');
  return u;
}

// fetch dengan pengecekan SSRF di setiap redirect.
export async function safeFetch(urlStr, extraHeaders = {}) {
  let current = urlStr;
  for (let hop = 0; hop <= MAX_REDIRECTS; hop++) {
    const u = await assertPublicHttps(current);
    const headers = { 'User-Agent': UA, 'Accept': '*/*', ...extraHeaders };
    if (/(^|\.)tikwm\.com$/i.test(u.hostname)) headers['Referer'] = 'https://www.tikwm.com/';
    const res = await fetch(u.toString(), {
      method: 'GET',
      redirect: 'manual',
      headers,
      signal: AbortSignal.timeout(FETCH_TIMEOUT_MS)
    });
    if ([301, 302, 303, 307, 308].includes(res.status)) {
      const loc = res.headers.get('location');
      if (!loc) throw new Error('Sumber file mengarahkan ke tempat yang tidak valid.');
      current = new URL(loc, u).toString();
      continue;
    }
    return res;
  }
  throw new Error('Terlalu banyak pengalihan dari sumber file.');
}

// Ambil gambar jarak jauh lalu ubah jadi data URL (dipakai maker yang balikin link gambar).
export async function fetchImageDataUrl(urlStr, maxBytes) {
  const res = await safeFetch(urlStr, { Accept: 'image/*' });
  if (!res.ok) throw new Error(`Sumber gambar menolak (${res.status}).`);
  const ctype = (res.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
  if (!ctype.startsWith('image/')) throw new Error('Hasil bukan gambar.');
  const buf = Buffer.from(await res.arrayBuffer());
  if (buf.length > maxBytes) throw new Error('Gambar hasil terlalu besar.');
  return `data:${ctype};base64,${buf.toString('base64')}`;
}

function cleanFilename(name) {
  const n = String(name || '').replace(/[\\/:*?"<>|\u0000-\u001f]+/g, '').trim().slice(0, 120);
  return n || 'download';
}

// Stream file ke browser. Lempar Error SEBELUM header terkirim kalau ada masalah.
export async function streamDownload(res, { url, filename }) {
  const upstream = await safeFetch(url);
  if (!upstream.ok) throw new Error(`Sumber file menolak (${upstream.status}).`);
  if (!upstream.body) throw new Error('Sumber file kosong.');

  const ctype = (upstream.headers.get('content-type') || 'application/octet-stream').split(';')[0].trim().toLowerCase();
  if (!OK_TYPE.test(ctype)) throw new Error('Tipe file tidak didukung.');

  const len = Number(upstream.headers.get('content-length') || 0);
  if (len > DL_MAX_BYTES) throw new Error('File terlalu besar (maksimal 100 MB).');

  const name = cleanFilename(filename);
  const ascii = name.replace(/[^\x20-\x7e]+/g, '_');
  res.status(200);
  res.setHeader('Content-Type', ctype);
  if (len) res.setHeader('Content-Length', String(len));
  res.setHeader('Content-Disposition', `attachment; filename="${ascii}"; filename*=UTF-8''${encodeURIComponent(name)}`);
  res.setHeader('X-Content-Type-Options', 'nosniff');

  let sent = 0;
  const limiter = new Transform({
    transform(chunk, _enc, cb) {
      sent += chunk.length;
      if (sent > DL_MAX_BYTES) return cb(new Error('File terlalu besar.'));
      cb(null, chunk);
    }
  });
  await pipeline(Readable.fromWeb(upstream.body), limiter, res);
}
