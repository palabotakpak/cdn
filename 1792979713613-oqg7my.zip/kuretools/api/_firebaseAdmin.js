// Inisialisasi Firebase Admin SDK, dipakai server-side buat:
// 1. Verifikasi ID token yang dikirim frontend (Authorization: Bearer <token>)
// 2. Baca role user (free/premium/owner) dari Firestore (users/{uid}.role)
//
// PENTING: role HANYA bisa diubah lewat Firebase Console / Admin SDK oleh
// pemilik project Firebase. firestore.rules mengunci field "role" supaya
// user biasa gak bisa naikin role dirinya sendiri lewat client SDK.
//
// Env vars yang dibutuhkan (Vercel -> Environment Variables):
//   FIREBASE_PROJECT_ID
//   FIREBASE_CLIENT_EMAIL
//   FIREBASE_PRIVATE_KEY   (copy dari file JSON service account, termasuk \n-nya)
// Dapetin ini dari: Firebase Console -> Project Settings -> Service Accounts
//   -> Generate new private key

import { initializeApp, getApps, cert } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';

let adminApp = null;
let initError = null;

// ID database Firestore. Default '(default)'. Kalau database dibuat dengan ID lain
// (mis. 'default' tanpa kurung), kita deteksi otomatis, atau set env FIRESTORE_DATABASE_ID.
let dbId = process.env.FIRESTORE_DATABASE_ID || '(default)';
let dbProbe = null;

function fsFor(app) {
  return dbId && dbId !== '(default)' ? getFirestore(app, dbId) : getFirestore(app);
}

export function getDbId() {
  return dbId;
}

function isNotFound(e) {
  return !!e && (e.code === 5 || /NOT_FOUND/.test(String(e.message || '')));
}

// Panggil sekali di awal tiap request (murah setelah berhasil pertama kali).
export function prepareDb() {
  if (dbProbe) return dbProbe;
  dbProbe = (async () => {
    if (process.env.FIRESTORE_DATABASE_ID) return;
    const app = getAdminApp();
    if (!app) { dbProbe = null; return; }
    for (const id of ['(default)', 'default']) {
      try {
        const db = id === '(default)' ? getFirestore(app) : getFirestore(app, id);
        await db.collection('_health').doc('ping').get();
        dbId = id;
        return;
      } catch (e) {
        if (!isNotFound(e)) { dbId = '(default)'; return; }
      }
    }
    dbId = '(default)';
    dbProbe = null; // belum ketemu: coba lagi di request berikutnya
  })();
  return dbProbe;
}

// Kredensial dibaca dari SATU env var FIREBASE_SERVICE_ACCOUNT (isi file JSON service account,
// boleh mentah atau base64). Kalau tidak ada, jatuh ke 3 env var lama
// (FIREBASE_PROJECT_ID / FIREBASE_CLIENT_EMAIL / FIREBASE_PRIVATE_KEY).
function readCredentials() {
  const blob = (process.env.FIREBASE_SERVICE_ACCOUNT || '').trim();
  if (blob) {
    let text = blob;
    if (!text.startsWith('{')) {
      try { text = Buffer.from(text, 'base64').toString('utf8'); } catch { /* biarin, gagal di parse */ }
    }
    const j = JSON.parse(text);
    return {
      source: 'FIREBASE_SERVICE_ACCOUNT',
      projectId: j.project_id,
      clientEmail: j.client_email,
      privateKey: String(j.private_key || '').replace(/\\n/g, '\n')
    };
  }
  return {
    source: '3 env var (FIREBASE_PROJECT_ID/CLIENT_EMAIL/PRIVATE_KEY)',
    projectId: process.env.FIREBASE_PROJECT_ID,
    clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
    privateKey: (process.env.FIREBASE_PRIVATE_KEY || '').replace(/\\n/g, '\n')
  };
}

// Ringkasan konfigurasi (tanpa rahasia) buat halaman /api/health.
export function describeAdminConfig() {
  try {
    const c = readCredentials();
    return {
      source: c.source,
      projectId: c.projectId || null,
      clientEmail: c.clientEmail || null,
      privateKeyFormat: /-----BEGIN PRIVATE KEY-----[\s\S]+-----END PRIVATE KEY-----/.test(c.privateKey || '') ? 'ok' : 'tidak valid / kosong'
    };
  } catch (e) {
    return { source: 'FIREBASE_SERVICE_ACCOUNT', error: 'JSON tidak bisa dibaca: ' + e.message };
  }
}

function getAdminApp() {
  if (adminApp || initError) return adminApp;

  let creds;
  try {
    creds = readCredentials();
  } catch (e) {
    initError = new Error('FIREBASE_SERVICE_ACCOUNT bukan JSON yang valid: ' + e.message);
    return null;
  }

  if (!creds.projectId || !creds.clientEmail || !creds.privateKey) {
    initError = new Error('Firebase Admin belum dikonfigurasi (isi env FIREBASE_SERVICE_ACCOUNT dengan file JSON service account)');
    return null;
  }

  try {
    adminApp = getApps().length
      ? getApps()[0]
      : initializeApp({ credential: cert({ projectId: creds.projectId, clientEmail: creds.clientEmail, privateKey: creds.privateKey }) });
    return adminApp;
  } catch (e) {
    initError = e;
    return null;
  }
}

/**
 * Terjemahkan error Firebase/Firestore jadi pesan yang jelas buat debugging.
 */
export function explainError(e) {
  const m = String((e && e.message) || e || 'unknown error');
  const code = e && e.code;
  if (code === 5 || /NOT_FOUND/.test(m)) {
    return 'Database Firestore tidak ditemukan di project ini. Pastikan sudah dibuat (Firebase Console -> Firestore Database -> Create database) dengan Database ID "(default)", atau set env FIRESTORE_DATABASE_ID sesuai ID database kamu. Detail: ' + m;
  }
  if (code === 7 || /PERMISSION_DENIED|has not been used|is disabled/i.test(m)) {
    return 'Akses Firestore ditolak atau API belum aktif. Pastikan Firestore sudah dibuat dan service account berasal dari project yang sama. Detail: ' + m;
  }
  if (/DECODER|PEM|private key|unsupported|asn1/i.test(m)) {
    return 'FIREBASE_PRIVATE_KEY tidak valid (format salah). Detail: ' + m;
  }
  if (/invalid_grant|UNAUTHENTICATED|Getting metadata|credential/i.test(m)) {
    return 'Kredensial service account ditolak Google (cek FIREBASE_CLIENT_EMAIL / FIREBASE_PRIVATE_KEY, dan jam server). Detail: ' + m;
  }
  return m;
}

// ---------- masa aktif role (roleExpiresAt, epoch ms) ----------
// 'owner' selalu permanen. 'premium' boleh dikasih masa aktif (field
// roleExpiresAt di dokumen users/{uid}); kalau sudah lewat, dianggap 'free'.
// Dipakai bareng oleh getRoleFromRequest (self-heal: nulis balik ke Firestore
// begitu kedaluwarsa kedeteksi) dan api/admin.js (tampilan read-only).
export function effectiveRoleData(data) {
  const rawRole = ['free', 'premium', 'owner'].includes(data.role) ? data.role : 'free';
  const expiresAt = typeof data.roleExpiresAt === 'number' ? data.roleExpiresAt : null;
  const expired = rawRole === 'premium' && expiresAt !== null && Date.now() > expiresAt;
  return {
    role: expired ? 'free' : rawRole,
    roleExpiresAt: expired ? null : (rawRole === 'premium' ? expiresAt : null),
    expired
  };
}

/**
 * Ambil role user dari Authorization header ("Bearer <idToken>").
 * Return { role, uid, provider, email, error?, dbError? }
 *  - token gagal diverifikasi / belum login / admin belum dikonfigurasi -> uid null (+ error)
 *  - token valid tapi Firestore gagal dibaca -> uid terisi, role 'free', dbError terisi
 * Fail-safe: TIDAK PERNAH fail-open ke premium/owner.
 * Kalau role premium sudah lewat masa aktifnya, otomatis ditulis balik jadi
 * 'free' di Firestore (self-heal) sebelum dikembalikan.
 */
export async function getRoleFromRequest(req, opts = {}) {
  const authHeader = req.headers['authorization'] || '';
  const match = authHeader.match(/^Bearer\s+(.+)$/i);
  if (!match) return { role: 'free', uid: null, provider: null };

  const app = getAdminApp();
  if (!app) return { role: 'free', uid: null, provider: null, error: initError?.message };

  let decoded;
  try {
    decoded = await getAuth(app).verifyIdToken(match[1]);
  } catch (e) {
    return { role: 'free', uid: null, provider: null, error: 'token ditolak: ' + e.message };
  }

  await prepareDb();

  const uid = decoded.uid;
  const provider = decoded.firebase?.sign_in_provider || null;
  const email = decoded.email || null;

  try {
    const ref = fsFor(app).collection('users').doc(uid);
    const snap = await ref.get();
    const data = snap.exists ? snap.data() : {};

    // Akun yang di-ban admin ditolak di SATU tempat ini, jadi otomatis berlaku
    // buat semua endpoint yang memakai getRoleFromRequest (profile, rch, amprem,
    // presetfinder, ttdl, igdl) tanpa perlu diubah satu-satu.
    if (data.banned === true) {
      return {
        role: 'free', uid: null, provider, email,
        error: 'akun ini sudah dibanned oleh admin' + (data.banReason ? (': ' + data.banReason) : '') + '.'
      };
    }

    // Gerbang OTP akun baru (Google ATAU email+password; akun password buatan api/otp.js register sudah otpVerified,
    // jadi yang kena cuma yang daftar langsung lewat API Firebase): login tanpa username & belum lolos verifikasi OTP
    // (akun lama yang sudah punya username otomatis lolos). Di SATU tempat ini, jadi semua
    // endpoint terkunci kecuali yang eksplisit pakai { allowPending: true } (profile & otp).
    const otpPending = (provider === 'google.com' || provider === 'password') && data.otpVerified !== true && !data.username;
    if (otpPending && !opts.allowPending) {
      return {
        role: 'free', uid: null, provider, email,
        error: 'verifikasi email (OTP) belum selesai. Selesaikan dulu di halaman login.'
      };
    }

    const eff = effectiveRoleData(data);
    if (eff.expired) {
      try { await ref.set({ role: 'free', roleExpiresAt: null }, { merge: true }); } catch { /* best-effort */ }
    }
    return { role: eff.role, uid, provider, email, roleExpiresAt: eff.roleExpiresAt, otpPending };
  } catch (e) {
    return { role: 'free', uid, provider, email, dbError: explainError(e) };
  }
}

/**
 * Dipakai api/admin.js: butuh akses tulis ke Firestore (lewat Admin SDK, bypass rules)
 * dan Auth (cari user dari email). Return null kalau Admin belum dikonfigurasi.
 */
export function getAdminServices() {
  const app = getAdminApp();
  if (!app) return null;
  return { auth: getAuth(app), db: fsFor(app) };
}

export function getAdminInitError() {
  return initError ? initError.message : null;
}

// ---------- limit harian per akun (disimpan di Firestore, hanya server yang bisa tulis) ----------
export const LIMITS = { free: 3, premium: 10 }; // owner = unlimited

// Tanggal hari ini dalam WIB (UTC+7) -> reset otomatis jam 00:00 WIB.
export function wibDate() {
  return new Date(Date.now() + 7 * 3600 * 1000).toISOString().slice(0, 10);
}

// `collection` dibedakan per fitur (mis. 'usage' buat ZeeReact, 'amprem_usage'
// buat AM Premium) supaya jatah harian masing-masing fitur gak nyampur.
export async function getUsage(uid, collection = 'usage') {
  const admin = getAdminServices();
  const snap = await admin.db.collection(collection).doc(uid).get();
  const today = wibDate();
  if (snap.exists && snap.data().date === today) return { date: today, count: snap.data().count || 0 };
  return { date: today, count: 0 };
}

// Reservasi 1 jatah secara atomik. ok=false kalau jatah hari ini sudah habis.
// Kalau jatah harian habis, otomatis pakai limit tambahan hasil beli di Store (wallets/{uid}.bonus_<collection>).
export async function reserveUsage(uid, limit, collection = 'usage') {
  const { db } = getAdminServices();
  const ref = db.collection(collection).doc(uid);
  const wref = db.collection('wallets').doc(uid);
  const field = 'bonus_' + collection;
  const today = wibDate();
  return db.runTransaction(async (t) => {
    const snap = await t.get(ref);
    const same = snap.exists && snap.data().date === today;
    const count = same ? (snap.data().count || 0) : 0;
    const bonusUsed = same ? (snap.data().bonusUsed || 0) : 0;
    if (count < limit) {
      t.set(ref, { date: today, count: count + 1, bonusUsed });
      return { ok: true, count: count + 1, limit };
    }
    const w = await t.get(wref);
    const bonus = w.exists ? (w.data()[field] || 0) : 0;
    if (bonus > 0) {
      t.set(wref, { [field]: bonus - 1 }, { merge: true });
      t.set(ref, { date: today, count, bonusUsed: bonusUsed + 1 });
      return { ok: true, count, limit, viaBonus: true, bonusLeft: bonus - 1 };
    }
    return { ok: false, count, limit };
  });
}

// Kembalikan jatah kalau API upstream gagal (user gak boleh rugi).
export async function refundUsage(uid, collection = 'usage') {
  const { db } = getAdminServices();
  const ref = db.collection(collection).doc(uid);
  const wref = db.collection('wallets').doc(uid);
  const field = 'bonus_' + collection;
  const today = wibDate();
  await db.runTransaction(async (t) => {
    const snap = await t.get(ref);
    if (!(snap.exists && snap.data().date === today)) return;
    const d = snap.data();
    const bonusUsed = d.bonusUsed || 0;
    if (bonusUsed > 0) {
      // Jatah yang dipakai tadi dari limit Store -> balikin ke limit Store.
      const w = await t.get(wref);
      t.set(wref, { [field]: (w.exists ? (w.data()[field] || 0) : 0) + 1 }, { merge: true });
      t.set(ref, { date: today, count: d.count || 0, bonusUsed: bonusUsed - 1 });
    } else if ((d.count || 0) > 0) {
      t.set(ref, { date: today, count: d.count - 1, bonusUsed: 0 });
    }
  });
}

// ---------- jatah mingguan Suntik Sosmed (collection 'smm_usage') ----------
// Beda dari getUsage/reserveUsage (reset harian WIB): ini reset per 7 hari
// ROLLING dari kapan terakhir di-reset (weekStart), bukan per kalender.
// 1 dokumen per uid: { weekStart: ISO date (WIB), count: number }.
const SMM_WEEK_MS = 7 * 24 * 60 * 60 * 1000;
const SMM_COLLECTION = 'smm_usage';

export async function getSmmUsage(uid) {
  const admin = getAdminServices();
  const snap = await admin.db.collection(SMM_COLLECTION).doc(uid).get();
  const today = wibDate();
  if (!snap.exists) return { weekStart: today, count: 0 };
  const data = snap.data();
  const started = new Date(data.weekStart + 'T00:00:00+07:00').getTime();
  if (Date.now() - started >= SMM_WEEK_MS) return { weekStart: today, count: 0 };
  return { weekStart: data.weekStart, count: data.count || 0 };
}

// Reservasi 1 jatah mingguan secara atomik. ok=false kalau jatah minggu ini sudah habis.
export async function reserveSmmUsage(uid, limit) {
  const { db } = getAdminServices();
  const ref = db.collection(SMM_COLLECTION).doc(uid);
  const wref = db.collection('wallets').doc(uid);
  const today = wibDate();
  return db.runTransaction(async (t) => {
    const snap = await t.get(ref);
    let weekStart = today;
    let count = 0;
    let bonusUsed = 0;
    if (snap.exists) {
      const data = snap.data();
      const started = new Date(data.weekStart + 'T00:00:00+07:00').getTime();
      if (Date.now() - started < SMM_WEEK_MS) {
        weekStart = data.weekStart;
        count = data.count || 0;
        bonusUsed = data.bonusUsed || 0;
      }
    }
    if (count < limit) {
      t.set(ref, { weekStart, count: count + 1, bonusUsed });
      return { ok: true, count: count + 1, limit, weekStart };
    }
    // Jatah mingguan habis -> pakai jatah tambahan hasil beli di Store.
    const w = await t.get(wref);
    const bonus = w.exists ? (w.data().bonus_smm || 0) : 0;
    if (bonus > 0) {
      t.set(wref, { bonus_smm: bonus - 1 }, { merge: true });
      t.set(ref, { weekStart, count, bonusUsed: bonusUsed + 1 });
      return { ok: true, count, limit, weekStart, viaBonus: true };
    }
    return { ok: false, count, limit, weekStart };
  });
}

// Kembalikan jatah kalau order ke FAYUPEDIA gagal (user gak boleh rugi).
export async function refundSmmUsage(uid, weekStart) {
  const { db } = getAdminServices();
  const ref = db.collection(SMM_COLLECTION).doc(uid);
  const wref = db.collection('wallets').doc(uid);
  await db.runTransaction(async (t) => {
    const snap = await t.get(ref);
    if (!(snap.exists && snap.data().weekStart === weekStart)) return;
    const d = snap.data();
    const bonusUsed = d.bonusUsed || 0;
    if (bonusUsed > 0) {
      const w = await t.get(wref);
      t.set(wref, { bonus_smm: (w.exists ? (w.data().bonus_smm || 0) : 0) + 1 }, { merge: true });
      t.set(ref, { weekStart, count: d.count || 0, bonusUsed: bonusUsed - 1 });
    } else if ((d.count || 0) > 0) {
      t.set(ref, { weekStart, count: d.count - 1, bonusUsed: 0 });
    }
  });
}

// ---------- riwayat download per akun (users/{uid}/download_history) ----------
// Ditulis & dibaca hanya lewat server (rules client dikunci total). Satu dokumen per
// item unik (id = type + hash key), jadi download ulang item yang sama cuma
// menaikkan item itu ke paling atas, bukan menumpuk duplikat. Maksimal 50 terbaru.
const HISTORY_COLLECTION = 'download_history';
const HISTORY_MAX = 50;
const HISTORY_TYPES = ['music', 'tiktok', 'instagram'];

function histCol(db, uid) {
  return db.collection('users').doc(uid).collection(HISTORY_COLLECTION);
}

function httpsOrEmpty(u, max = 500) {
  const s = String(u || '').trim();
  return /^https:\/\//i.test(s) && s.length <= max ? s : '';
}

// Best-effort: gagal nulis riwayat gak boleh bikin download utama gagal.
export async function logDownload(uid, { type, key, title, subtitle, thumbnail, ref }) {
  try {
    if (!uid || !HISTORY_TYPES.includes(type) || !key) return;
    const services = getAdminServices();
    if (!services) return;
    const { createHash } = await import('node:crypto');
    const id = type + '_' + createHash('sha1').update(String(key)).digest('hex').slice(0, 20);
    const col = histCol(services.db, uid);
    await col.doc(id).set({
      type,
      title: String(title || '').trim().slice(0, 200) || '(tanpa judul)',
      subtitle: String(subtitle || '').trim().slice(0, 120),
      thumbnail: httpsOrEmpty(thumbnail),
      ref: String(ref || key).slice(0, 500),
      createdAt: Date.now()
    });
    const extra = await col.orderBy('createdAt', 'desc').offset(HISTORY_MAX).limit(50).get();
    if (!extra.empty) {
      const batch = services.db.batch();
      extra.docs.forEach(d => batch.delete(d.ref));
      await batch.commit();
    }
  } catch { /* abaikan */ }
}

export async function listDownloads(uid) {
  const { db } = getAdminServices();
  const snap = await histCol(db, uid).orderBy('createdAt', 'desc').limit(HISTORY_MAX).get();
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

export async function deleteDownload(uid, id) {
  const { db } = getAdminServices();
  await histCol(db, uid).doc(id).delete();
}

export async function clearDownloads(uid) {
  const { db } = getAdminServices();
  const col = histCol(db, uid);
  for (;;) {
    const snap = await col.limit(200).get();
    if (snap.empty) break;
    const batch = db.batch();
    snap.docs.forEach(d => batch.delete(d.ref));
    await batch.commit();
    if (snap.size < 200) break;
  }
}


// ---------- statistik pemakaian fitur ----------
// Dicatat tiap ada request fitur yang lolos login (percobaan, bukan jaminan sukses):
//   stats/features        -> { total: { <fitur>: n, _all: n } }  (sepanjang waktu)
//   stats_daily/<tgl WIB> -> { features: { <fitur>: n, _all: n }, users: { <uid>: true } }
// Best-effort: gagal nyatet gak boleh bikin fitur utamanya error.
export async function logFeature(uid, feature) {
  try {
    const admin = getAdminServices();
    if (!admin || !uid) return;
    const f = String(feature || '').replace(/[^a-zA-Z0-9_]/g, '').slice(0, 40);
    if (!f) return;
    const day = wibDate();
    await Promise.all([
      admin.db.collection('stats').doc('features').set(
        { total: { [f]: FieldValue.increment(1), _all: FieldValue.increment(1) } }, { merge: true }),
      admin.db.collection('stats_daily').doc(day).set(
        { date: day, features: { [f]: FieldValue.increment(1), _all: FieldValue.increment(1) }, users: { [uid]: true } }, { merge: true })
    ]);
  } catch { /* best-effort */ }
}


// ---------- mode maintenance per fitur ----------
// Disimpan di Firestore config/maintenance -> { features: { <kunci>: { on: bool, message: string } }, updatedAt }.
// Diatur dari panel admin (action get-maintenance / set-maintenance), dibaca publik lewat /api/maintenance,
// dan dicek di server oleh tiap endpoint fitur lewat maintenanceBlock() (OWNER selalu lolos buat ngetes).
// Kalau Firestore gagal dibaca, fitur dibiarkan jalan (fail-open) supaya error DB tidak bikin web mati total.
export const MAINT_FEATURES = {
  zeereact: 'ZeeReact',
  vote: 'Vote Polling',
  amprem: 'AM Premium',
  presetfinder: 'Preset Finder',
  ttdl: 'TikTok Downloader',
  igdl: 'Instagram Downloader',
  musicdl: 'Music Downloader',
  fakelobyff: 'Fake Lobby FF & ML',
  iqc: 'IQC Maker',
  fakespotify: 'Fake Spotify',
  wamaker: 'WA Maker',
  imgurl: 'Gambar ke URL',
  anime: 'Nonton Anime',
  smm: 'Suntik Sosmed',
  wallet: 'Saldo & Store (deposit/belanja)',
  nokos: 'Nokos (Sewa Nomor OTP)'
};

const MAINT_TTL_MS = 10000;
let maintCache = { at: 0, features: {}, updatedAt: null };

export function resetMaintenanceCache() { maintCache = { at: 0, features: {}, updatedAt: null }; }

// Return { features: { key: { on, message } }, updatedAt } (hasil di-cache 10 detik per instance).
export async function getMaintenance(force = false) {
  if (!force && Date.now() - maintCache.at < MAINT_TTL_MS) return maintCache;
  try {
    try { await prepareDb(); } catch { /* getAdminServices yang menentukan */ }
    const admin = getAdminServices();
    if (!admin) return maintCache;
    const snap = await admin.db.collection('config').doc('maintenance').get();
    const data = snap.exists ? snap.data() : {};
    const features = {};
    const raw = (data && data.features) || {};
    for (const k of Object.keys(MAINT_FEATURES)) {
      const f = raw[k];
      if (f && f.on) features[k] = { on: true, message: String(f.message || '').slice(0, 200) };
    }
    maintCache = { at: Date.now(), features, updatedAt: data.updatedAt || null };
  } catch { /* fail-open: pakai cache terakhir */ }
  return maintCache;
}

// Dipanggil di endpoint fitur: return null kalau boleh lanjut, atau { error, maintenance, feature } (kirim dengan status 503).
export async function maintenanceBlock(feature, role) {
  if (role === 'owner') return null;
  const m = await getMaintenance();
  const f = m.features[feature];
  if (!f) return null;
  const label = MAINT_FEATURES[feature] || feature;
  return {
    error: f.message || (label + ' lagi maintenance. Coba lagi nanti ya.'),
    maintenance: true,
    feature
  };
}
