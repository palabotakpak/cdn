// Vercel Serverless Function - Nonton Anime (khusus PREMIUM & OWNER)
//
// POST /api/anime
//   body: { action: 'home' }
//   body: { action: 'ongoing',   page }
//   body: { action: 'completed', page }
//   body: { action: 'search',    query }
//   body: { action: 'detail',    id }              -> animeId
//   body: { action: 'episode',   id }               -> episodeId
//   body: { action: 'server',    id }               -> serverId, resolve jadi URL embed
//
// Data diambil dari API publik sankavollerei (gratis, tanpa API key), sumber
// aslinya dari source code kurenime.vercel.app sendiri (src/lib/animein.server.ts),
// jadi field & endpoint-nya dijamin cocok karena disalin langsung dari situ,
// bukan tebakan.
//
// GERBANG UTAMA fitur ini: wajib login DAN role premium/owner, dicek di server
// (bukan cuma UI) -- beda dari versi iframe sebelumnya yang cuma ngatur
// tampilan. User free yang coba manggil endpoint ini langsung ditolak 403,
// apa pun yang mereka lakukan di browser.

import { getRoleFromRequest, explainError, logFeature } from './_firebaseAdmin.js';
import { maintenanceBlock } from './_firebaseAdmin.js';

const SANKA_API_BASE = 'https://www.sankavollerei.web.id/anime';
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '';
const BOT_UA_RE = /(curl|wget|python-requests|python-urllib|scrapy|axios\/|node-fetch|go-http-client|libwww-perl|httpclient|aiohttp|okhttp|postman|insomnia|headlesschrome|phantomjs|puppeteer|playwright|bot|crawler|spider|scraper)/i;
const BROWSER_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

async function sanka(path) {
  const res = await fetch(`${SANKA_API_BASE}${path}`, {
    headers: { 'User-Agent': BROWSER_UA, 'Accept': 'application/json' }
  });
  const text = await res.text();
  let json;
  try { json = JSON.parse(text); } catch { throw new Error('Respons server anime tidak terbaca.'); }
  if (!res.ok) throw new Error(`API anime error ${res.status} di ${path}`);
  return json;
}

// ---------- normalisasi, niru persis logika animein.server.ts di kurenime ----------

function mapAnimeListItem(a, status) {
  return {
    id: a.animeId,
    title: a.title,
    poster: a.poster,
    episodeCount: a.episodes != null ? (typeof a.episodes === 'number' ? a.episodes : parseInt(String(a.episodes), 10) || null) : null,
    score: a.score ?? null,
    status,
    releaseDay: a.releaseDay ?? null,
    latestReleaseDate: a.latestReleaseDate ?? a.lastReleaseDate ?? null
  };
}

async function getHome() {
  const json = await sanka('/home');
  const ongoingRaw = json.data?.ongoing?.animeList ?? [];
  const completedRaw = json.data?.completed?.animeList ?? [];
  const ongoing = ongoingRaw.map(a => mapAnimeListItem(a, 'Ongoing'));
  const completed = completedRaw.map(a => mapAnimeListItem(a, 'Completed'));
  return { ongoing, completed };
}

async function getOngoing(page) {
  const json = await sanka(`/ongoing-anime?page=${page}`);
  return {
    items: (json.data?.animeList ?? []).map(a => mapAnimeListItem(a, 'Ongoing')),
    pagination: json.pagination || null
  };
}

async function getCompleted(page) {
  const json = await sanka(`/complete-anime?page=${page}`);
  return {
    items: (json.data?.animeList ?? []).map(a => mapAnimeListItem(a, 'Completed')),
    pagination: json.pagination || null
  };
}

async function doSearch(keyword) {
  const json = await sanka(`/search/${encodeURIComponent(keyword)}`);
  return {
    items: (json.data?.animeList ?? []).map(a => ({
      id: a.animeId,
      title: a.title,
      poster: a.poster,
      status: a.status ?? null,
      score: a.score ?? null,
      genres: (a.genreList ?? []).map(g => g.title)
    }))
  };
}

async function getDetail(id) {
  const json = await sanka(`/anime/${encodeURIComponent(id)}`);
  const d = json.data;
  return {
    id,
    title: d.title,
    poster: d.poster,
    japanese: d.japanese ?? null,
    score: d.score ?? null,
    status: d.status ?? 'Unknown',
    type: d.type ?? 'TV',
    totalEpisodes: d.episodes ?? null,
    duration: d.duration ?? null,
    aired: d.aired ?? null,
    studios: d.studios ?? null,
    synopsis: d.synopsis?.paragraphs?.join('\n\n') || null,
    genres: (d.genreList ?? []).map(g => g.title),
    episodes: (d.episodeList ?? []).map(ep => ({ id: ep.episodeId, number: ep.eps || 0, title: ep.title, releaseDate: ep.date ?? null })),
    recommended: (d.recommendedAnimeList ?? []).map(r => ({ id: r.animeId, title: r.title, poster: r.poster }))
  };
}

async function getEpisode(id) {
  const json = await sanka(`/episode/${encodeURIComponent(id)}`);
  const d = json.data;
  return {
    title: d.title,
    animeId: d.animeId,
    episodeId: id,
    defaultStreamingUrl: d.defaultStreamingUrl || null,
    hasPrevEpisode: !!d.hasPrevEpisode,
    prevEpisodeId: d.prevEpisode?.episodeId ?? null,
    hasNextEpisode: !!d.hasNextEpisode,
    nextEpisodeId: d.nextEpisode?.episodeId ?? null,
    qualities: (d.server?.qualities ?? []).map(q => ({
      quality: q.title,
      serverList: (q.serverList ?? []).map(s => ({ title: (s.title || '').trim(), serverId: s.serverId }))
    })),
    downloads: (d.downloadUrl?.qualities ?? []).map(q => ({
      quality: q.title,
      size: q.size ?? null,
      urls: (q.urls ?? []).map(u => ({ title: u.title, url: u.url }))
    })),
    episodeList: (d.info?.episodeList ?? []).map(ep => ({ id: ep.episodeId, number: ep.eps || 0, title: ep.title }))
  };
}

async function resolveServer(id) {
  const json = await sanka(`/server/${encodeURIComponent(id)}`);
  return { url: json.data?.url || '' };
}

export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const ua = req.headers['user-agent'] || '';
  if (!ua || BOT_UA_RE.test(ua)) {
    return res.status(403).json({ error: 'Akses ditolak' });
  }
  if (ALLOWED_ORIGIN) {
    const origin = req.headers['origin'] || req.headers['referer'] || '';
    if (!origin.startsWith(ALLOWED_ORIGIN)) {
      return res.status(403).json({ error: 'Akses ditolak' });
    }
  }

  const { role, uid, provider, error: authError, dbError } = await getRoleFromRequest(req);
  if (!uid) {
    return res.status(401).json({ error: authError ? 'Verifikasi login gagal: ' + authError : 'Login dulu.' });
  }
  if (dbError) return res.status(500).json({ error: dbError });
  if (provider !== 'google.com' && provider !== 'password') {
    return res.status(401).json({ error: 'Metode login tidak didukung.' });
  }

  { // mode maintenance (diatur dari panel admin; OWNER tetap bisa akses)
    const mb = await maintenanceBlock('anime', role);
    if (mb) return res.status(503).json(mb);
  }

  // Gerbang utama: fitur ini khusus premium/owner, dicek di server.
  if (role !== 'premium' && role !== 'owner') {
    return res.status(403).json({ error: 'Fitur Nonton Anime khusus PREMIUM/OWNER. Upgrade dulu lewat AM Premium.' });
  }

  const body = typeof req.body === 'string' ? safeParse(req.body) : (req.body || {});
  const action = String(body.action || '').toLowerCase();
  const page = Math.max(1, parseInt(body.page, 10) || 1);
  if (action === 'episode') await logFeature(uid, 'anime'); // hitung episode yang dibuka, bukan sekadar browsing

  try {
    let data;
    switch (action) {
      case 'home':
        data = await getHome();
        break;
      case 'ongoing':
        data = await getOngoing(page);
        break;
      case 'completed':
        data = await getCompleted(page);
        break;
      case 'search': {
        const q = String(body.query || '').trim();
        if (!q) return res.status(400).json({ error: 'Kata kunci pencarian kosong.' });
        data = await doSearch(q);
        break;
      }
      case 'detail': {
        const id = String(body.id || '').trim();
        if (!id) return res.status(400).json({ error: 'ID anime kosong.' });
        data = await getDetail(id);
        break;
      }
      case 'episode': {
        const id = String(body.id || '').trim();
        if (!id) return res.status(400).json({ error: 'ID episode kosong.' });
        data = await getEpisode(id);
        break;
      }
      case 'server': {
        const id = String(body.id || '').trim();
        if (!id) return res.status(400).json({ error: 'ID server kosong.' });
        data = await resolveServer(id);
        break;
      }
      default:
        return res.status(400).json({ error: 'action tidak dikenal.' });
    }
    return res.status(200).json({ success: true, ...data });
  } catch (e) {
    return res.status(502).json({ error: e.message || 'Gagal mengambil data anime.' });
  }
}

function safeParse(s) {
  try { return JSON.parse(s); } catch { return {}; }
}
