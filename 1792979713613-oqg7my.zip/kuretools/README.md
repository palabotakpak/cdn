# KureTools

Web app untuk react emoji ke postingan channel WhatsApp (via API nexadev), dengan login Firebase dan 3 tingkat akses: **FREE**, **PREMIUM**, **OWNER**.

## Struktur
```
kuretools/
├── api/
│   ├── rch.js             # serverless function utama, baca API key dari env
│   ├── admin.js           # klaim owner pakai kode + owner set role premium
│   ├── profile.js         # profil user + riwayat download (digabung, lihat vercel.json rewrite /api/history)
│   ├── musicdl.js         # cari judul lagu + download MP3
│   ├── profile.js         # profil user (role, username, sisa limit) + set username
│   ├── _captcha.js        # helper captcha (bukan function; diakses lewat /api/captcha -> rewrite ke otp.js)
│   └── _firebaseAdmin.js  # verifikasi ID token + baca role dari Firestore
├── public/
│   ├── login.html         # halaman login/daftar + pilih username (langkah pertama)
│   ├── index.html         # halaman react (info user: role + username), wajib login dulu
│   ├── admin.html         # halaman admin (owner)
│   └── robots.txt
├── firestore.rules        # security rules: client dikunci total, semua lewat server
├── package.json           # dependency firebase-admin
├── vercel.json
└── README.md
```

## Tingkat akses
| Role | Limit harian | Captcha | Cara dapet |
|---|---|---|---|
| **FREE** | 3x/hari (server-side, per akun) | Wajib | Default — tanpa login ATAU akun baru daftar |
| **PREMIUM** | 10x/hari (server-side, per akun) | Gak perlu | Di-set manual oleh pemilik project Firebase |
| **OWNER** | Unlimited | Gak perlu | Di-set manual oleh pemilik project Firebase |

**Penting soal role:** role tidak pernah dipercaya dari browser. Perubahan role hanya terjadi lewat server (`api/admin.js`, Firebase Admin SDK), atau manual oleh pemilik project Firebase di Console → Firestore Database → koleksi `users` → field `role`. `firestore.rules` mengunci supaya user gak bisa ubah field ini sendiri, dan server (`api/rch.js`) selalu cek ulang role ke Firestore lewat Firebase Admin SDK — bukan percaya klaim dari browser.

## Cek konfigurasi (`/api/health`)

Buka `https://domain-kamu/api/health` di browser. Hasilnya JSON yang nunjukin env mana yang masih kosong/salah, apakah kredensial service account terbaca, dan apakah Firestore + Auth bisa dihubungi. Gak ada nilai rahasia yang ditampilkan. Hapus `api/health.js` kalau semua sudah beres.

**Database ID Firestore:** server otomatis mencoba `(default)` lalu `default` (kalau database dibuat dengan ID tanpa kurung). Kalau ID database kamu beda, set env `FIRESTORE_DATABASE_ID`. `/api/health` menampilkan ID yang terdeteksi di baris `firestore_database_id`.

## Alur halaman

1. `/login.html`: login/daftar (email/password atau Google). Kalau akun belum punya username, muncul langkah **Pilih Username** (3-20 karakter huruf kecil/angka/underscore, unik, sekali set, contoh `udin123`).
2. `/` (halaman react): kalau belum login otomatis diarahkan ke `/login.html`. Di atas ada kartu info user: **Role** (FREE/PREMIUM/OWNER), **Username**, email, dan tombol keluar.
3. `/admin`: halaman admin, login pakai kode.

## Wajib login sebelum react

User harus login dulu, boleh pakai **email/password** atau **Google**. Dicek di dua tempat: UI menyembunyikan form kalau belum login, dan `api/rch.js` menolak (401) request tanpa ID token valid (provider `password` atau `google.com`). Aktifkan dua metode di Firebase Console -> Authentication -> Sign-in method: **Email/Password** dan **Google**. Pastikan domain Vercel kamu ada di Authentication -> Settings -> **Authorized domains**.

## Setup Firebase (sekali aja)

1. Buat project baru di https://console.firebase.google.com (gratis, paket Spark).
2. **Authentication** → Sign-in method → aktifkan **Email/Password** dan **Google**.
3. **Firestore Database** → Create database → mode production.
4. Deploy `firestore.rules` yang udah disiapin (rules sekarang mengunci client total; WAJIB di-publish ulang):
   - Cara gampang: buka Firestore → tab **Rules** → copy-paste isi `firestore.rules` → Publish.
   - Atau pakai CLI: `firebase deploy --only firestore:rules` (butuh `firebase-tools` & `firebase init` dulu).
5. **Project Settings** (ikon gerigi) → scroll ke "Your apps" → tambah **Web app** → copy config yang muncul (`apiKey`, `authDomain`, dst).
6. Buka `public/index.html`, cari blok `window.FIREBASE_CONFIG = {...}` di bagian atas, ganti semua `"GANTI_..."` dengan nilai asli dari langkah 5. Config ini aman ditaruh di frontend (bukan rahasia).
7. **Project Settings** → tab **Service Accounts** → **Generate new private key** → download file JSON-nya. Dari file itu, ambil 3 nilai buat env var di Vercel:
   - `FIREBASE_PROJECT_ID` → field `project_id`
   - `FIREBASE_CLIENT_EMAIL` → field `client_email`
   - `FIREBASE_PRIVATE_KEY` → field `private_key` (copy semuanya termasuk `-----BEGIN PRIVATE KEY-----` dan `\n`-nya, paste apa adanya ke Vercel)

## Deploy ke Vercel

1. Push folder ini ke repo GitHub, atau upload langsung lewat Vercel CLI:
   ```
   npm i -g vercel
   cd kuretools
   vercel
   ```
2. Di Vercel Dashboard → Project → Settings → Environment Variables, tambahkan:
   - `NEXADEV_KEY` — API key nexadev kamu
   - `ALLOWED_ORIGIN` (opsional) — domain production kamu, contoh `https://kuretools.vercel.app`
   - `IMGBB_API_KEY` (opsional) — API key gratis dari https://api.imgbb.com/ buat fitur Gambar ke URL
     lebih stabil & permanen (lihat bagian Fitur Gambar ke URL). Tanpa ini, fitur tetap jalan lewat host lain.
   - `CAPTCHA_SECRET` — string acak, contoh hasil `openssl rand -hex 32`
   - `FIREBASE_PROJECT_ID`, `FIREBASE_CLIENT_EMAIL`, `FIREBASE_PRIVATE_KEY` — dari langkah Setup Firebase di atas
3. Redeploy project supaya env var & dependency `firebase-admin` (dari `package.json`) kebaca.

## Halaman Admin (`/admin`)

Login admin pakai **kode saja** (tanpa email/Google). Buka `https://domain-kamu/admin`, masukkan kode, lalu:
- **Upgrade via email**: isi email user yang sudah daftar, pilih PREMIUM (atau FREE buat cabut), klik TERAPKAN ROLE.
- **Daftar user** (bisa dicari pakai email/username) dengan tombol UPGRADE dan CABUT per baris.

Setup: di Vercel -> Environment Variables, set `OWNER_CODE` (kode admin kamu), lalu redeploy. Kode dicek di server (`api/admin.js`) pada setiap request lewat header `X-Admin-Code`, tidak pernah ada di frontend/repo. Salah kode 8x dalam 15 menit -> IP diblokir sementara. Kode disimpan di sessionStorage tab itu saja, hilang kalau tab ditutup atau klik KELUAR.

## Fitur Instagram Downloader (`/api/igdl`)
Tool di Tools Hub: download video, reel, foto, dan carousel (multi-item) dari
Instagram, lewat API publik `api.siputzx.my.id` (gratis, tanpa API key).
- `POST /api/igdl` body `{ link }` (link postingan/reel Instagram, harus publik).
- Wajib login, sama seperti endpoint lain.
- Tanpa limit untuk semua role.
- ⚠️ **Catatan**: parsing respons API ini ditulis fleksibel karena belum bisa
  diverifikasi live dari lingkungan pembuatan kode (tanpa akses jaringan keluar).
  Kalau setelah deploy hasilnya error atau media tidak muncul, cek pesan error
  yang tampil — kemungkinan bentuk JSON dari API perlu disesuaikan sedikit di
  `extractMedia()` dalam `api/igdl.js`.

## Fitur TikTok Downloader (`/api/ttdl`)
Tool di Tools Hub: download video TikTok **tanpa watermark** (+ versi HD & musik
asli), lewat API publik `tikwm.com` (gratis, tanpa API key). Postingan foto/slideshow
juga didukung (hasilnya daftar link gambar, bukan video).
- `POST /api/ttdl` body `{ link }` (link video/postingan TikTok).
- Wajib login, sama seperti endpoint lain.
- Tanpa limit untuk semua role.

## Fitur Fake Lobby FF & ML (digabung ke `/api/ttdl`)
Tool di Tools Hub: bikin gambar lobby FF (solo/duo) dari nickname, dan lobby ML.
- Free Fire Solo: `POST /api/ttdl` body `{ action:'fakelobyff', game:'ff', nickname }` (maks 24 karakter), lewat
  `apii.nexadev.my.id/fakeff?usn=`.
- Free Fire Duo: `{ action:'fakelobyff', game:'ffduo', nickname, nickname2 }`, lewat
  `apii.nexadev.my.id/fakeffduo?nickname1=&nickname2=` (`buildLobbyDuoUrl()` di `api/_fakelobyff.js`).
- Varian Mobile Legends: `{ action:'fakelobyff', game:'ml', nickname, avatar }` (`avatar` = link gambar http(s), wajib),
  lewat `api.nexray.eu.cc/maker/fakelobyml` (`buildLobbyMlUrl()` di `api/_fakelobyff.js`). Logikanya ada di helper
  `api/_fakelobyff.js` (prefix underscore = bukan Serverless Function), jadi total function tetap 12.
- Respons upstream bisa gambar langsung atau JSON berisi URL gambar; keduanya ditangani
  (`findImageUrl()` di `api/_fakelobyff.js`). Kalau hasil tidak muncul setelah deploy, kirim
  pesan error / respons mentahnya biar parsing disesuaikan.
- Wajib login, tanpa limit untuk semua role.

## Fitur IQC Maker (digabung ke `/api/ttdl`)
Tool di Tools Hub: bikin gambar chat bubble dari teks, 5 gaya lewat `api-moondrowend.web.id/api/maker/`:
`iqc` (text), `iqc2` (text, time), `iqcpink` (text, time), `iqc3` (text, time, imgurl),
`igqc` (txt, imgUrl; nama parameter-nya beda, dipetakan lewat `map` di `api/_iqc.js`).
- `POST /api/ttdl` body `{ action:'iqc', style, text, time?, imgurl? }`. Validasi + pembuat URL ada di
  `api/_iqc.js` (bukan Serverless Function), fetch gambar pakai `fetchMakerImage()` di `api/_fakelobyff.js`.
- Teks maks 300 karakter, jam format `09:41`, `imgurl` wajib http(s) untuk gaya `iqc3` dan `igqc`.
- Wajib login, tanpa limit untuk semua role.

## Fitur Fake Spotify (digambar di browser)

Mockup tampilan Spotify Now Playing (1080x2344) dari `fakespotify.js` (Vamz Spectre), tapi dipindah ke
canvas browser di `public/index.html` (`fspDraw()`), jadi **tidak butuh** `skia-canvas`/`sharp` dan **tidak nambah
Serverless Function**. Cover dipilih dari galeri HP, warna latar otomatis dari warna dominan cover, font Poppins
dari Google Fonts.
- Input: cover, judul lagu, artis, judul playlist + teks atasnya, jam, baterai, waktu sekarang, durasi, teks
  pratinjau lirik, status play/pause, shuffle.
- `POST /api/ttdl` body `{ action:'fakespotify' }` cuma buat verifikasi login + catat statistik (`fakespotify`
  tampil di panel admin). Tanpa limit untuk semua role, sama seperti tool Tools Hub lainnya.
- Gambar tidak diupload ke mana-mana, langsung jadi PNG di HP user.

## Mode Maintenance fitur (panel admin)

Di `/admin` ada kartu **Mode Maintenance Fitur**: centang fitur yang mau ditahan, isi pesan (opsional), lalu
**SIMPAN MAINTENANCE**. Disimpan di Firestore `config/maintenance`.
- Fitur yang bisa dikunci: ZeeReact, Vote Polling, AM Premium, Preset Finder, TikTok/Instagram/Music Downloader,
  Fake Lobby, IQC, Fake Spotify, WA Maker, Gambar ke URL, Nonton Anime, Suntik Sosmed, Saldo & Store
  (daftar kunci ada di `MAINT_FEATURES`, `api/_firebaseAdmin.js`).
- **Dicek di server**: endpoint fitur balas `503 { maintenance:true, error:<pesan> }` lewat `maintenanceBlock()`,
  jadi tidak bisa ditembus lewat API langsung. Akun **OWNER selalu lolos** buat ngetes.
- Frontend baca `GET /api/maintenance` (publik, rewrite ke `api/system.js?action=maintenance`): kartu fitur
  dikasih tanda 🔧 MAINTENANCE dan klik-nya munculin popup pesan. Daftar di-refresh tiap 60 detik.
- Tombol Saldo: yang ditahan cuma `deposit` dan `buy`; `check`/`cancel` tetap jalan supaya deposit yang sudah
  dibayar tetap kekreditkan. Suntik Sosmed: order baru (POST) ditahan, lihat saldo/riwayat tetap bisa.
- Proxy download (`/api/ttdl` action `dl`) dan game offline (Blok Blast, Tetris, Geometry Dash) tidak ikut dikunci.
- Kalau Firestore gagal dibaca, fitur dibiarkan jalan (fail-open). Status di-cache 10 detik per instance server.
- Tidak nambah Serverless Function (limit 12 aman).

## Fitur Gambar ke URL (digabung ke `/api/ttdl`)
Tool di Tools Hub: upload gambar (JPG/PNG/WEBP/GIF), dapat link langsung. Gambar di-upload lewat server ke
beberapa host, dicoba berurutan sampai ada yang berhasil:
`imgbb` (permanen, hanya aktif kalau env `IMGBB_API_KEY` diset) -> `0x0.st` (30 hari-1 tahun) -> `uguu.se`
(3 jam) -> `tmpfiles.org` (1 jam) -> `catbox.moe` (permanen) -> `litterbox` (72 jam). Kalau semua gagal,
pesan error memuat alasan tiap host.
- **Kenapa catbox/litterbox di urutan belakang**: keduanya sering memblokir upload dari IP server/datacenter
  (termasuk Vercel) dan balas `200 OK` dengan teks `Invalid uploader` alih-alih error semestinya. Tetap
  dicoba (gratis, gagalnya cepat bukan nunggu timeout) buat jaga-jaga kalau suatu saat gak diblokir lagi.
- **ImgBB (opsional, direkomendasikan buat hasil paling stabil & permanen)**: daftar gratis di
  https://api.imgbb.com/ buat dapat API key, lalu set env `IMGBB_API_KEY` di Vercel dan redeploy. Kalau
  env ini tidak diset, host ini otomatis dilewati (tidak dihitung gagal), fallback lain tetap jalan.
- `POST /api/ttdl` body `{ action:'imgurl', mime, data }` (`data` = base64). Logika di `api/_imgurl.js`
  (bukan Serverless Function): cek tipe + magic bytes, maks 3 MB, lalu upload.
- Batas body Vercel 4.5MB, jadi frontend auto-kompres gambar di atas ~2.8 MB jadi JPG (GIF tidak dikompres).
- `api/ttdl.js` dikasih `maxDuration: 30` di `vercel.json` buat jaga-jaga upload lambat.
- Wajib login, tanpa limit untuk semua role.

## Download langsung di web (proxy `/api/ttdl` action `dl`)
Semua tombol download (TikTok, Instagram, Music, hasil Fake Lobby/IQC, riwayat musik) menyimpan file
langsung dari web ini, tanpa membuka tab/web lain.
- `POST /api/ttdl` body `{ action:'dl', url, filename }` -> server men-stream file dari sumbernya, browser
  menyimpannya lewat `dlSave()` / `dlBtn()` di `public/index.html`. Logika di `api/_dlproxy.js`
  (bukan Serverless Function, jadi total function tetap 12).
- Pengamanan: hanya https, anti-SSRF (IP privat/loopback ditolak, dicek di tiap redirect), hanya tipe
  media (image/video/audio/octet-stream), maks 100 MB. Wajib login.
- Opsional: env `DL_ALLOWED_HOSTS` (domain dipisah koma, contoh
  `tikwm.com,tiktokcdn.com,cdninstagram.com,fbcdn.net,catbox.moe`) buat membatasi sumber ke domain tertentu saja.
- `api/ttdl.js` diset `maxDuration: 60` di `vercel.json` (file besar butuh waktu).
- Hasil maker (Fake Lobby/IQC) yang berupa link gambar diambil server dulu jadi data URL.
- Tidak diubah: link "Link Download" di Nonton Anime dan "BUKA LINK" di Preset Finder, karena itu halaman
  host pihak ketiga (bukan file langsung) sehingga tidak bisa di-proxy.

## Fitur Music Downloader (`/api/musicdl`)
Tool di Tools Hub: ketik judul lagu, pilih hasilnya, download MP3. Tanpa API key.
- `POST /api/musicdl` body `{ action:'search', query }` -> daftar hasil (judul, artis,
  durasi, thumbnail) dari katalog Spotify. Gak makan limit.
- `POST /api/musicdl` body `{ action:'download', id }` (`id` = ID track Spotify dari hasil search)
  -> link MP3. Server membangun ulang URL track dari `id` yang divalidasi, bukan percaya URL dari client.
- Wajib login, sama seperti endpoint lain.
- Tanpa limit untuk semua role.
- Sumber: API nexray (`api.nexray.eu.cc`): `/search/spotify?q=` untuk cari, `/downloader/aio?url=`
  untuk link MP3 (`result.medias[]`). Daftar provider ada di `SEARCH_PROVIDERS` /
  `DOWNLOAD_PROVIDERS` di `api/musicdl.js`; provider dicoba berurutan, jadi gampang nambah cadangan.
- `vercel.json` menaikkan `maxDuration` function ini jadi 30 detik karena konversi MP3 bisa lama.

## Fitur Nonton Anime (`/api/anime`, khusus PREMIUM & OWNER)
Tool di Tools Hub: browser anime asli (Home → Detail → Player) di dalam
KureTools sendiri, bukan cuma iframe ke situs lain. Datanya diambil dari API
publik `sankavollerei.web.id/anime` (gratis, tanpa API key) — endpoint &
struktur datanya disalin langsung dari source code kurenime.vercel.app
(`src/lib/animein.server.ts`), jadi dijamin cocok, bukan tebakan.
- `POST /api/anime` dengan `action`: `home`, `ongoing`, `completed`, `search`,
  `detail`, `episode`, `server`.
- **Gerbang premium beneran di server**, bukan cuma UI: endpoint ini ngecek
  `role` dari Firestore (lewat `getRoleFromRequest`, sama seperti endpoint
  lain) — user `free` yang coba manggil `/api/anime` langsung dapat `403`,
  apa pun yang mereka lakukan di browser. Beda dari versi iframe sebelumnya
  yang gatingnya cuma tampilan.
- Nonton: pilih anime → pilih episode → player muncul dengan video utama
  (`defaultStreamingUrl`), tab kualitas (360p/480p/720p) & tombol ganti
  server per kualitas (manggil action `server` buat resolve URL embed baru),
  plus link download per kualitas kalau providernya nyediain.
- Tidak ada limit harian untuk fitur ini (karena sudah otomatis cuma bisa
  diakses premium/owner, yang di tempat lain juga unlimited).
- **Risiko**: fitur ini tergantung API `sankavollerei.web.id` tetap hidup.
  Kalau providernya mati/berubah struktur, perlu disesuaikan lagi di
  `api/anime.js` (hubungi lagi kalau itu terjadi).

## Riwayat Download (`/api/history`)
Tool di Tools Hub: daftar 50 download terakhir milik akun yang login (lagu, TikTok, Instagram).
- Dicatat otomatis oleh `/api/musicdl`, `/api/ttdl`, `/api/igdl` setelah download sukses
  (best-effort: gagal nulis riwayat tidak menggagalkan download).
- Disimpan di Firestore `users/{uid}/download_history/{type_hash}`. Item yang sama diunduh
  ulang cuma naik ke paling atas, tidak menumpuk duplikat. Lebih dari 50 item, yang paling lama dihapus.
- `POST /api/history` body `{ action:'list' }`, `{ action:'delete', id }`, atau `{ action:'clear' }`.
  Cuma bisa baca/hapus riwayat milik akun sendiri. Rules Firestore tetap dikunci total, tidak perlu diubah.
  Endpoint ini sekarang digabung ke dalam `api/profile.js` (lewat rewrite `vercel.json` yang
  menambahkan `?target=history`) supaya total Serverless Function tetap <= 12 di Vercel Hobby plan.
- Lagu: tombol **DOWNLOAD LAGI** mengambil link MP3 baru (link lama bisa kedaluwarsa).
  TikTok/Instagram: tombol **BUKA DI ...** mengisi link ke tool-nya, tinggal tekan DOWNLOAD.

## Fitur Preset Finder (`/api/presetfinder`)
Fitur ketiga di halaman yang sama (`/`): cari link preset Alight Motion dari
deskripsi/bio/komentar sebuah video TikTok, lewat scraper pihak ketiga
(`amfinder.web.id`, respons Server-Sent Events).
- `POST /api/presetfinder` body `{ link }` (link video TikTok).
- Wajib login, sama seperti endpoint lain.
- Tanpa limit untuk semua role.

## Lupa password & riwayat AM Premium
- **Lupa password**: di `/login.html` ada link "Lupa password?" — kirim email reset
  password asli lewat Firebase Auth (`sendPasswordResetEmail`). Pesan hasilnya sengaja
  sama baik email terdaftar maupun tidak, supaya gak bisa dipakai buat nebak-nebak
  email mana yang punya akun.
- **Riwayat AM Premium**: tab "RIWAYAT" di halaman AM Premium nampilin 20 aktivitas
  terakhir (magic link & apply) milik akun yang login — disimpan di
  `users/{uid}/amprem_history/{autoId}`, cuma bisa dibaca lewat `/api/amprem`
  (action `history`) oleh pemilik akun itu sendiri.

## Masa aktif premium (otomatis balik ke free)
Upgrade ke **PREMIUM** lewat `/admin` sekarang wajib isi **masa aktif (hari)**, bukan
permanen lagi (1-3650 hari, custom, diisi manual tiap upgrade). Begitu masa aktif
lewat, role otomatis balik ke `free` — dicek & dibenerin sendiri ke Firestore pas
user itu hit API mana pun (`/api/profile`, `/api/rch`, `/api/amprem`), jadi gak perlu
cron job terpisah. Tanggal berakhir ditampilkan di halaman admin (daftar user) dan
di halaman user (badge PREMIUM). Role **OWNER** tetap permanen, tidak kena expiry,
dan tetap cuma bisa di-set manual lewat Firebase Console (bukan dari `/admin`).

## Cara naikin user jadi premium/owner (manual lewat Console)

1. Minta user itu daftar/login dulu lewat app (role awal otomatis `free`).
2. Buka Firebase Console → Firestore Database → koleksi `users` → cari dokumen dengan UID user tersebut (bisa dicocokin dari field `email`).
3. Edit field `role`, ganti nilainya jadi `premium` atau `owner`.
4. Selesai — user itu otomatis dapet limit baru (premium: 10x/hari, owner: unlimited) begitu refresh/login ulang, gak perlu redeploy apa pun.

## Catatan
- Limit harian (free 3x, premium 10x) dihitung **di server per akun** (koleksi `usage` di Firestore, lewat Admin SDK), reset otomatis jam 00:00 WIB. Jatah dipesan sebelum memanggil API nexadev dan dikembalikan otomatis kalau API-nya gagal. Gak bisa direset lewat clear storage/incognito/ganti device.
- Role (premium/owner) **selalu** diverifikasi ulang di server lewat Firebase Admin SDK — client cuma mengirim ID token, bukan nama role, jadi gak bisa dipalsukan dari browser.
- Captcha & limit otomatis disembunyikan dari UI untuk user premium/owner yang sudah login.

## Anti-scraping
`api/rch.js` punya proteksi dasar:
- Menolak request dengan User-Agent yang terdeteksi sebagai bot/HTTP client umum (curl, python-requests, scrapy, headless browser, dll).
- Kalau env var `ALLOWED_ORIGIN` diset, request yang Origin/Referer-nya bukan dari domain itu ditolak.
- Rate limit kasar per IP (default 20 request/menit) yang disimpan di memori function.

Catatan: rate limit in-memory ini **best-effort**, bukan jaminan ketat, karena Vercel serverless function bisa cold-start kapan saja dan mereset memorinya. Untuk proteksi yang lebih kuat, pasang juga Vercel WAF/Rate Limiting di level project, atau simpan counter di database/KV eksternal.
`public/robots.txt` juga di-set `Disallow: /` dan halaman diberi meta `noindex, nofollow` supaya tidak diindeks mesin pencari.

## Fitur AM Premium (`/api/amprem`)
Fitur kedua di halaman yang sama (`/`): kirim magic link & apply Alight Motion
Premium lewat SATRIAM API publik (tidak butuh API key/env var tambahan).
- `POST /api/amprem` body `{ action:'magic', email }` atau `{ action:'apply', email, link }`.
- Wajib login (header `Authorization: Bearer <idToken>`), sama seperti `/api/rch`.
- Limit harian: **FREE 2x/hari**, **PREMIUM & OWNER unlimited**, dihitung di server
  (Firestore collection `amprem_usage`, terpisah dari limit ZeeReact di collection `usage`),
  reset otomatis jam 00:00 WIB.

## Captcha (buatan sendiri, gratis tanpa batas)
Gak pakai layanan pihak ketiga. `GET /api/captcha` bikin soal matematika acak + token HMAC (berlaku 5 menit, ditandatangani pakai `CAPTCHA_SECRET`). Saat kirim reaksi, token + jawaban dicek ulang di `api/rch.js` sebelum diteruskan ke API nexadev. Hanya dicek untuk role **free**.

## Catatan limit Tools Hub
Semua tool di Tools Hub (Preset Finder, TikTok DL, IG DL, Music DL) tanpa limit untuk semua role. Untuk mengaktifkan limit lagi: ubah `const unlimited = true` di `api/<tool>.js` dan `*_FREE_LIMIT` di `public/index.html`.

## Saldo & Store
- Deposit via QRIS lewat SairiPedia (min. Rp1.000); gateway tanpa webhook jadi status dicek polling.
- Env wajib: `SAIRIPEDIA_API_KEY` (opsional `SAIRIPEDIA_API_BASE`).
- Harga Premium & paket limit diatur di `api/_wallet.js` (`STORE_PREMIUM`, `STORE_LIMIT`).
- Data: `wallets/{uid}`, `deposits/{invoiceId}`, `purchases/*` (semua lewat server, client Firestore tetap terkunci).

## REST API publik (API key: premium 30/hari, free 10/hari dengan ACC admin)

- Kelola key & dokumentasi: `/apidocs` (halaman `public/api.html`, wajib login). Key hanya tampil sekali saat dibuat; yang disimpan di Firestore cuma hash-nya (`apikeys/{sha256}`).
- Endpoint: `GET /api/v1/rch?apikey=KEY&url=<link postingan saluran>&reaction=<emoji>` (atau header `x-api-key`). Di-rewrite ke `api/rch.js?tool=apirch`, logikanya di `api/_apikey.js` (helper, tidak menambah jumlah Serverless Function).
- Limit per akun (premium 30, free 10), reset 00:00 WIB (koleksi `api_usage`), jatah dikembalikan kalau upstream gagal. OWNER tanpa batas. Role dicek ulang tiap request, jadi premium yang kedaluwarsa otomatis ditolak.
- Kelola key lewat `POST /api/profile` `{apiKey:'generate'|'revoke'}`; `GET /api/profile` mengembalikan field `api` (prefix, terpakai, limit).
- Panel admin (`/admin`, kartu "API Key Publik"): lihat semua key (prefix, pemakaian hari ini), **HAPUS** (key dicabut) atau **BAN/UNBAN** (key diblokir + tidak bisa buat key baru). Action server: `apikey-list`, `apikey-delete`, `apikey-ban`, `apikey-unban` di `api/admin.js`. User yang diban lewat "Daftar User" juga otomatis tidak bisa pakai API.
- Tambah limit manual: di panel admin kartu Saldo/Limit, pilih tipe **REST API**, isi jumlah (minus = kurangi). Disimpan sebagai `wallets/{uid}.bonus_api_usage`; dipakai otomatis setelah jatah harian 20 habis (tidak ikut reset harian).
- Akses per role: **PREMIUM** otomatis (limit 30/hari), **OWNER** tanpa batas, **FREE** limit 10/hari dan harus mengajukan lewat `/apidocs` ("Ajukan akses API"), lalu di-ACC admin. Status disimpan di `users/{uid}.apiAccess` (`pending` / `approved` / `rejected`). Admin ACC/TOLAK/CABUT AKSES di kartu "API Key Publik" (action `apikey-access`); tolak/cabut akses ikut menghapus key. Kalau premium habis masa aktif dan belum di-ACC, API otomatis berhenti.
- Format API key: diawali `KR-` (contoh `KR-3f9a...`, total 43 karakter). Key lama berawalan `kt_` (kalau ada) tetap diterima sampai dibuat ulang.
- Anti-robot: **buat key / ajukan akses** wajib captcha gambar (sekali pakai, dari `/api/captcha?type=img`), ditambah honeypot tersembunyi, blok User-Agent bot, dan jeda 60 detik antar pembuatan key. **Pemakaian key**: maks 5 request / 10 detik per key + 60 request/menit per IP, selain limit harian.

## Keamanan tambahan
- Secret HMAC (captcha/OTP) tidak lagi punya fallback string tetap di source; kalau `CAPTCHA_SECRET`/`OTP_SECRET` kosong, diturunkan dari rahasia server lain (`api/_secrets.js`). Tetap isi kedua env itu.
- Captcha matematika sekarang sekali pakai (sebelumnya bisa dipakai ulang 5 menit).
- Penguncian tebak kode admin disimpan di Firestore (`admin_lock`), bukan cuma memori instance: 8 salah / 15 menit / IP.
- Log audit aksi admin (ubah role, ban, saldo/limit, API key, maintenance, pengumuman) ke koleksi `admin_audit` (waktu, IP, target).
- API key: limit 20 key salah / 10 menit / IP; key sebaiknya dikirim lewat header `x-api-key`.
- Header keamanan di semua halaman (HSTS, nosniff, X-Frame-Options, Referrer-Policy, Permissions-Policy).
