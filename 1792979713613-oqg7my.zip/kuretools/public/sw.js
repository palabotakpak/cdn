// Service worker KureTools: bikin app bisa di-install & punya halaman offline sederhana.
// Sengaja TIDAK nyimpen /api, login Firebase, atau request lintas domain, jadi data selalu live
// dan update deploy langsung kebaca (halaman diambil network-first).
const CACHE = 'kuretools-shell-v1';
const SHELL = ['/', '/login', '/icon-192.png', '/icon-512.png', '/manifest.webmanifest'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL).catch(() => {})).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  const url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== self.location.origin) return;
  if (url.pathname.startsWith('/api/') || url.pathname === '/admin') return;

  // Network-first; kalau offline baru ambil dari cache.
  e.respondWith(
    fetch(req).then((res) => {
      if (res && res.ok && (req.mode === 'navigate' || SHELL.includes(url.pathname))) {
        const copy = res.clone();
        caches.open(CACHE).then((c) => c.put(req, copy)).catch(() => {});
      }
      return res;
    }).catch(() => caches.match(req).then((hit) => hit || (req.mode === 'navigate' ? caches.match('/') : Response.error())))
  );
});
